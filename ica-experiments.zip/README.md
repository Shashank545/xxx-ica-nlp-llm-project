# README

## Setup

### Set up Python environment

- With `conda`:

    ```bash
    conda deactivate \
      && conda env create -f environment.yml --force \
      && conda activate ica_exp
    ```

- With `venv`:

    ```bash
    python -m venv ica_exp \
      && source ica_exp/bin/activate \
      && pip install -r requirements.txt
    ```

- Run `pre-commit install` to set up the git hook scripts.

    ```bash
    pre-commit install
    ```

### Set up spacy en model

    ```bash
    python -m spacy download en_core_web_sm    
    ```

Note that the following pre-commit hooks are set up:

1. flake8
1. isort
1. pydocstyle
1. mypy
