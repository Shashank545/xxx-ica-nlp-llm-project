"""Tokenizer class."""
from typing import List

import spacy  # type: ignore

NLP = spacy.load('en_core_web_sm')
NLP.max_length = 1300000  # fix for spacy value error E088; adjust max length as necessary
spacy_stopwords = list(spacy.lang.en.stop_words.STOP_WORDS)


class Tokenizer:
    """Tokenize input text.

    Args:
        text (str): Input text

    Returns:
        List[str]: List of tokens
    """

    def space_tokenizer(text) -> List[str]:
        """Tokenize input text with space delimiter."""
        return (str(text)).split(" ")  # fix mypy error: "tokenizers" has no attribute "split"

    def spacy_tokenizer(text) -> List[str]:
        """Tokenize input text with spacy."""
        doc = NLP(text)
        tokens = []
        for token in doc:
            lemma = (token.lemma_).lower()
            if (lemma.isalnum()) and (len(lemma) > 2) and (not lemma.isdigit()):  # remove puncs, digits, and 1-2 chars
                if (lemma != "-pron-"):
                    token = lemma
                else:
                    token = (token.text).lower()
                if token not in spacy_stopwords:
                    tokens.append(token)
        return tokens
