"""Generate fake dataset.

This stand-alone script used to generate fake datasets for the ICA project
using Wikipedia content. Content is retrieved using an official WIKIPEDIA_API.

Usage:

python src/create_fake_dataset.py -n 4 -o interim
"""
import argparse
import datetime
import json
import random
import re
import string
import time
from pathlib import Path
from typing import Dict, List

import requests
from tqdm import tqdm

WIKIPEDIA_API = "https://en.wikipedia.org/w/api.php"
OUT_KEYS = ["audit", "audit_related", "tax", "renewal"]


def process_args() -> argparse:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-n", "--num-articles",
        dest="num_articles",
        default=200,
        type=int,
        help="Number of Wikipedia articles to retrieve. Defaults to 200",
    )
    parser.add_argument(
        "-o", "--out-path",
        default="interim",
        dest="out_path",
        help="Full path to folder to which generated fake dataset is stored"
    )
    return parser.parse_args()


def retr_rand_titles(num_titles: int) -> List[str]:
    """Retrieve random Wikipedia titles.

    Args:
        num_titles (int): Number of titles to be retrieved

    Returns:
        List[str]: Retrieved titles
    """
    print(f"Info: Retrieving {num_titles} random Wikipedia titles")
    random_params = {
        "action": "query",
        "format": "json",
        "list": "random",
        "rnlimit": f"{num_titles}",
        "rnnamespace": "0"
    }
    resp = requests.get(
        url=WIKIPEDIA_API,
        params=random_params
    )
    resp.raise_for_status()
    rand_titles = [
        _resp["title"]
        for _resp in resp.json()["query"]["random"]
    ]
    assert len(rand_titles) == num_titles
    return rand_titles


def retr_articles(trg_titles: List[str]) -> Dict[str, str]:
    """Retrieve Wikipedia articles based on their titles.

    Args:
        trg_titles (List[str]): Target titles

    Returns:
        Dict[str,str]: {title:article}
    """
    articles = {}
    for title in tqdm(trg_titles):
        params = {
            "action": "parse",
            "page": title,
            "format": "json"
        }
        resp = requests.get(
            url=WIKIPEDIA_API,
            params=params
        )
        resp.raise_for_status()
        article = resp.json()
        html_text = article["parse"]["text"]["*"]
        lines = re.sub('<[^<]+?>', '', html_text).splitlines()
        lines = [
            line.strip()
            for line in lines
            if line.strip()
            and not line.startswith(".mw-")
        ]
        articles[title] = " ".join(lines)
        time.sleep(0.75)
    return articles


def gen_rand_fnames(num_chars: int) -> str:
    """Generate a random string of num_chars length.

    Args:
        num_chars (int): Length of the random string

    Returns:
        str: Random string
    """
    return ''.join(
        random
        .SystemRandom()
        .choice(string.ascii_uppercase + string.digits)
        for _ in range(num_chars)
    )


def gen_output_dataset(lst_text: List[str]) -> dict:
    """Generate the output dataset.

    Args:
        lst_text (List[str]): Random articles

    Returns:
        dict: Output dataset
    """
    out = {}
    for n_article, article in enumerate(lst_text):
        _fname = f"{gen_rand_fnames(9)}.docx"
        out[_fname] = {"text": article}
        for key in OUT_KEYS:
            if n_article < len(lst_text) / 2:
                out[_fname][key] = 0
            else:
                out[_fname][key] = 1
    return out


def to_json(out_dataset: Dict[str, dict], out_path: str):
    """Write content to disk (JSON).

    Args:
        out_dataset (Dict[str, dict]): Dataset to be stored in disk
        out_path (str): Full path to folder to which 'out_dataset' is stored
    """
    out_fname = Path(out_path).joinpath(
        f"{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}.json"
    )
    with open(out_fname, mode="w", encoding="utf-8") as fout:
        fout.write(
            json.dumps(out_dataset, indent=4, sort_keys=True)
        )
    print(f"Info: Generated dataset is stored into {out_fname}")


def main():
    """Orchastrate the process."""
    args = process_args()

    # Retrieve random Wiki titles
    rand_titles = retr_rand_titles(args.num_articles)

    # Retrieve articles of random titles
    articles = retr_articles(rand_titles)
    lst_articles = [
        f"{title} {article}"
        for title, article in articles.items()
    ]

    # Split retrieved data for OUT_KEYS
    out_dataset = gen_output_dataset(lst_articles)

    # Store the dataset to disk
    to_json(out_dataset, args.out_path)


if __name__ == '__main__':
    main()
