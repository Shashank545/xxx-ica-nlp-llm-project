"""Experiment with a fake dataset.

Uses a whitespace tokenizer and off-the-shelf Logistic Regression model.

Usage:

python src/binclassify_with_logreg.py -i interim/20211221223104.json -t "spacy_tokenizer" -k audit
"""
import argparse
import json
import warnings
from typing import Callable, Dict, List, Tuple

import matplotlib.pyplot as plt  # type: ignore
import numpy as np  # type: ignore
import pandas as pd  # type: ignore
import seaborn as sns  # type: ignore
from sklearn import metrics
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from tokenizers import Tokenizer

warnings.filterwarnings('ignore')  # to turn off sklearn warnings
TRG_KEYS = ["audit", "audit_related", "tax", "renewal"]


def process_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-i", "--input",
        required=True,
        dest="inp_fname",
        help="Full path to folder to which generated fake dataset is stored"
    )
    parser.add_argument(
        "-t", "--tokenizer",
        default="spacy_tokenizer",
        dest="tokenizer_key",
        help="Key on which tokenizer to use: space_tokenizer or spacy_tokenizer"
    )
    parser.add_argument(
        "-k", "--key",
        default="audit",
        dest="trg_key",
        help="Key on which prediction is to be carried out"
    )
    return parser.parse_args()


def load_dataset(fname: str) -> Dict[str, dict]:
    """Load input dataset from disk.

    Args:
        fname (str): [description]

    Returns:
        Dict[str, dict]: [description]
    """
    with open(fname, mode="r", encoding="utf-8") as fin:
        dataset = json.load(fin)
    return dataset


def reshape_dataset(raw_dataset: Dict[str, dict], trg_key: str) -> List[dict]:
    """Reshape raw dataset into [{text, label}] format.

    Args:
        raw_dataset (Dict[str, dict]): Raw dataset
        trg_key (str): Key of the raw dataset that represents the 'label'.
            trg_key must be in TRG_KEYS.

    Returns:
        List[dict]: Reshaped dataset
    """
    assert trg_key in TRG_KEYS
    out_dataset: List[dict] = []
    for fname, fdetails in raw_dataset.items():
        out_dataset.append(
            {
                "fname": fname,
                "text": fdetails["text"],
                "label": fdetails[trg_key]
            }
        )
    return out_dataset


def init_vectorizer(tokenizer: Callable):
    """Set up text vectorizer."""
    return CountVectorizer(
        tokenizer=tokenizer,
        ngram_range=(1, 1)
    )


def init_classifier():
    """Set up Logistic Regression model."""
    return LogisticRegression(
        penalty='l2',
        dual=False,
        tol=0.0001,
        C=1.0,
        fit_intercept=True,
        intercept_scaling=1,
        class_weight=None,
        random_state=None,
        solver='lbfgs',
        max_iter=100,
        multi_class='auto',
        verbose=0,
        warm_start=False,
        n_jobs=None,
        l1_ratio=None
    )


def choose_tr_ts_examples(
    dataset: List[dict]
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Generate training and test sets from input collection.

    Input collection is assumed to comprise [{text, label}].

    Args:
        dataset (List[dict]): Input collection

    Returns:
        Tuple: x_train, x_test, y_train, y_test
    """
    x_all = np.asarray([record["text"] for record in dataset])
    y_all = np.asarray([record["label"] for record in dataset])
    return train_test_split(
        x_all, y_all,
        random_state=42,
        test_size=0.2,
        shuffle=True
    )


def get_important_features(_pipeline):
    """Visualize important features of the logistic regression model.

    Args:
        _pipeline: sklearn logistic regression pipeline
    """
    feature_names = _pipeline.named_steps["vectorizer"].get_feature_names()
    coefs = _pipeline.named_steps["classifier"].coef_.flatten()
    zipped = zip(feature_names, coefs)
    df = pd.DataFrame(zipped, columns=["feature", "value"])
    df["abs_value"] = df["value"].apply(lambda x: abs(x))
    df["colors"] = df["value"].apply(lambda x: "green" if x > 0 else "red")
    df = df.sort_values("abs_value", ascending=False)
    df = df.head(10)  # top 10 features
    _, ax = plt.subplots(1, 1, figsize=(15, 8))
    sns.barplot(x="value",
                y="feature",
                data=df,
                palette=df["colors"])
    ax.set_yticklabels(ax.get_yticklabels(), fontsize=20)
    ax.set_title("Top 10 Features", fontsize=25)
    ax.set_ylabel("Features", fontsize=22)
    ax.set_xlabel("Coefs", fontsize=22)
    plt.savefig('output/features.jpg', bbox_inches='tight')
    plt.close()


def report_performance(y_test: np.ndarray, predicted: np.ndarray):
    """Report on performance.

    Args:
        y_test (np.ndarray): True labels
        predicted (np.ndarray): Predicted labels
    """
    print(f"accuracy: {metrics.accuracy_score(y_test, predicted):.3f}")
    print(f"precision: {metrics.precision_score(y_test, predicted):.3f}")
    print(f"recall: {metrics.recall_score(y_test, predicted):.3f}")
    pred_matrix = metrics.confusion_matrix(y_test, predicted, labels=[0, 1])
    print(pred_matrix)


def main():
    """Orchastrate the process."""
    args = process_args()

    # Read raw dataset from disk
    raw_dataset = load_dataset(args.inp_fname)

    # Reorganize the raw dataset into {(fname, text, label)}
    # label in TRG_KEYS
    dataset = reshape_dataset(raw_dataset, args.trg_key)

    # Generate training and test sets
    x_train, x_test, y_train, y_test = choose_tr_ts_examples(dataset)

    # Initialize vectorizer
    _vectorizer = init_vectorizer(getattr(Tokenizer, args.tokenizer_key))

    # Initialize classifier
    _classifier = init_classifier()

    # Initialize pipeline
    _pipeline = Pipeline([
        ('vectorizer', _vectorizer),
        ('classifier', _classifier)
    ])

    # Train the whole pipeline
    _pipeline.fit(x_train, y_train)

    # visualize important features: see output folder
    get_important_features(_pipeline)

    # Run inference on the test set
    y_pred = _pipeline.predict(x_test)

    # Report on performance
    report_performance(y_test, y_pred)


if __name__ == '__main__':
    main()
