"""Convert WORD or RTF files to PDF and extract text from a PDF file."""
import os
import shlex

import pikepdf
from pdfminer.converter import PDFPageAggregator
from pdfminer.layout import LAParams, LTTextBox, LTTextLine
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfparser import PDFParser


def word_rtf_to_pdf_converstion(word_file_path: str, output_dir: str):
    """
    Convert a file with extension doc or docx to a PDF file. It requires lifreoffice installed.

    Args:
        word_file_path (str): path to a WORD or RTF file.
        output_dir (str): the directory in which the PDF file will be
                          saved with the same name, but extension changed.

    """
    os.system(f"soffice --headless --convert-to pdf --outdir {shlex.quote(output_dir)} {shlex.quote(word_file_path)}")


def text_extraction_from_pdf(pdf_file_path: str, tmp_pdf_file: str) -> str:
    """
    Extract text from a PDF file.

    Args:
        pdf_file_path (str): path to a PDF file.
        tmp_dir (str): a path of a temporary (decrypted) PDF intermediate file.
    Returns:
        str: the text extracted from the PDF file
    """
    # This step may be necessary for encrypted PDF files
    with pikepdf.Pdf.open(pdf_file_path) as pdf:
        pdf.save(tmp_pdf_file)

    extracted_txt = ""

    pdf_file_obj = open(tmp_pdf_file, 'rb')
    parser = PDFParser(pdf_file_obj)
    document = PDFDocument(parser, "")
    if not document.is_extractable:
        return extracted_txt

    manager = PDFResourceManager()
    params = LAParams()

    device = PDFPageAggregator(manager, laparams=params)
    interpreter = PDFPageInterpreter(manager, device)

    for page in PDFPage.create_pages(document):
        interpreter.process_page(page)
        for obj in device.get_result():
            if isinstance(obj, (LTTextBox, LTTextLine)):
                extracted_txt += obj.get_text()

    return extracted_txt
