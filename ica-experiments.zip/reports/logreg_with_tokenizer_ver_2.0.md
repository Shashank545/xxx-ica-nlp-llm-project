## Executive summary

A baseline logistic model with a space delimiter tokenizer seems to be capable of classifying tax, audit, and audit_related files (from interim/check_item1_data.json). Also, with the use of spacy preprocessing (stopwords removal and lemmatization), model performance generally improved. Performance are recorded below.

## Results

- With space_tokenizer (space delimiter):

| Target | Accuracy | Precision | Recall | Confusion Matrix |
|---|---|---|---|---|
| audit | 0.877 | 0.882 | 0.750 |  [[35  2] [ 5 15]] |
| audit_related | 0.895 | 0.727 | 0.727 | [[43  3] [ 3  8]] |
| tax | 0.965 | 1.000 | 0.857 | [[43  0] [ 2 12]] |

- With spacy_tokenizer (with lemmatization and stopwords removal):

| Target | Accuracy | Precision | Recall | Confusion Matrix |
|---|---|---|---|---|
| audit | 0.930 | 0.944 | 0.850 | [[36  1] [ 3 17]] |
| audit_related | 0.860 | 0.615 | 0.727 | [[41  5] [ 3  8]] |
| tax | 0.982 | 1.000 | 0.929 | [[43  0] [ 1 13]] |

## How to reproduce the results

1. Download check_item1_data.json from teams.
2. Place file in interim folder.
3. Run with both space_tokenizer and spacy_tokenizer on all target classes.
```bash
python src/binclassify_with_logreg.py -i interim/check_item1_data.json -t "space_tokenizer" -k audit
python src/binclassify_with_logreg.py -i interim/check_item1_data.json -t "space_tokenizer" -k audit_related
python src/binclassify_with_logreg.py -i interim/check_item1_data.json -t "space_tokenizer" -k tax
python src/binclassify_with_logreg.py -i interim/check_item1_data.json -t "spacy_tokenizer" -k audit
python src/binclassify_with_logreg.py -i interim/check_item1_data.json -t "spacy_tokenizer" -k audit_related
python src/binclassify_with_logreg.py -i interim/check_item1_data.json -t "spacy_tokenizer" -k tax
```
4. For reference, relevant features are also visualized in output/features.jpg for each run. Check if results coincide with this report. 
