# Data Translation Script
# Code to change data structure of ICA QA dataset to the format required by contract-NLI

import json
import re

# Load ICA QA dataset 
nli_qa_data =  json.load(open('data/raw/qa_data.json', 'r'))

# Normalize whitespace
def normalize_whitespace(sentence):
    sentence = sentence.strip()
    sentence = re.sub(r'\n\s*\n', '\n', sentence)
    sentence = re.sub(r'[^\S\r\n]+', ' ', sentence)
    return sentence


# Collect dictionary of fixed questions for each NDA contract for NLI
all_ques_collector = []

for record in nli_qa_data:
    single_ques_collection = []
    for ques in range(len(record["q&a"])):
        single_ques_collection.append(record["q&a"][ques]["question"])
    all_ques_collector.append(single_ques_collection)

all_qalist = [element for nestedlist in all_ques_collector for element in nestedlist]
all_ques_dict = {str(i) : ele for i, ele in enumerate(sorted(list(set(all_qalist))))}
all_ques_list = list(all_ques_dict.values())


# Mapping and converting contract and annotation texts in contract NLI dataset
documents_lod = []
cn = 1

for id, value in enumerate(nli_qa_data):

    fill_dict = {}
    annotation_dict = {}
    nds_dict = {}
    doc_spans_lol = []
    doc_spans_index_lol = []
    doc_spans_list = []

    fill_dict["id"] = id+1
    fill_dict["file_name"] = f"some_random_filename_{id}.pdf"
    fill_dict["text"] = normalize_whitespace(value["text"])
    span_index = 0
    known_indexes = []
    not_known_indexes = []
    contract_ques_list = []
    contract_ans_list = []
    contract_evid_list = []
    all_ans_map_dict = {}
    all_evid_map_dict = {}
    span_index = 0
    evidence_span_list = []
    
    for y, z in enumerate(value["q&a"]):
        contract_ques_list.append(z["question"])
        contract_ans_list.append(z["answer"])
        contract_evid_list.append(z["evidence"])


    # Prepare and map all answer and evidence dictionaries with fixed set
    for p, (qid, q) in enumerate(all_ques_dict.items()):

        for qa, ans, evid in zip(contract_ques_list, contract_ans_list, contract_evid_list):
            if qa.lower() == q.lower():
                all_ans_map_dict[qid]=ans
                all_evid_map_dict[qid]=evid
                break
            else:
                all_ans_map_dict[qid]="Not known"
                all_evid_map_dict[qid]=[]


    # Re-structing the data to adapt contactNLI format
    for j, k in enumerate(all_ques_list):
        span_ans_dict = {}
        span_ans_dict["count"] = cn
        cn = cn + 1
        span_ans_dict["choice"] = all_ans_map_dict[str(j)]
        # print(all_evid_map_dict[str(j)])
        if len(all_evid_map_dict[str(j)])==0:
            span_ans_dict["spans"] = []
        else:
            idx_list = [(idx+span_index) for idx in range(len(all_evid_map_dict[str(j)]))]
            span_ans_dict["spans"] = idx_list
            span_index = idx_list[-1] + 1
            doc_spans_index_lol.append(idx_list)
        doc_spans_lol.append(all_evid_map_dict[str(j)])
        nds_dict[f"nda-{j}"] = span_ans_dict

    annotation_dict["annotations"] = nds_dict
    documents_lod.append(fill_dict)
    doc_spans_list = [evid for single_span in doc_spans_lol for evid in single_span]
    doc_spans_index_list = [evid for single_span in doc_spans_index_lol for evid in single_span]
    fill_dict["spans"] = doc_spans_list
    fill_dict["annotation_sets"] = [annotation_dict]



# Mapping and converting question labels in contract NLI dataset
nda_label_dict = {}
for i,j in all_ques_dict.items():
    qa_dict = {}
    qa_dict["question"] = j
    nda_label_dict[f"nda-{i}"] = qa_dict

# Saving full versions for final train and test dataset to JSON
contractnli_train_data = {}
contractnli_dev_data = {}
contractnli_test_data = {}
contractnli_train_data["documents"] = documents_lod[:400]
contractnli_train_data["labels"] = nda_label_dict
contractnli_dev_data["documents"] = documents_lod[400:500]
contractnli_dev_data["labels"] = nda_label_dict
contractnli_test_data["documents"] = documents_lod[500:]
contractnli_test_data["labels"] = nda_label_dict

with open('data/converted/spannli_train_data.json', 'w') as tr_out_file:
    json.dump(contractnli_train_data, tr_out_file, indent=4, ensure_ascii=False)
with open('data/converted/spannli_dev_data.json', 'w') as te_out_file:
    json.dump(contractnli_dev_data, te_out_file, indent=4, ensure_ascii=False)
with open('data/converted/spannli_test_data.json', 'w') as de_out_file:
    json.dump(contractnli_test_data, de_out_file, indent=4, ensure_ascii=False)

# Saving smaller versions for final train and test dataset to JSON
contractnli_subset_train_data = {}
contractnli_subset_dev_data = {}
contractnli_subset_test_data = {}

contractnli_subset_train_data["documents"] = documents_lod[:100]
contractnli_subset_train_data["labels"] = nda_label_dict
contractnli_subset_dev_data["documents"] = documents_lod[100:150]
contractnli_subset_dev_data["labels"] = nda_label_dict
contractnli_subset_test_data["documents"] = documents_lod[150:200]
contractnli_subset_test_data["labels"] = nda_label_dict

with open('data/converted/spannli_sm_train_data.json', 'w') as tr_out_file:
    json.dump(contractnli_subset_train_data, tr_out_file, indent=4, ensure_ascii=False)
with open('data/converted/spannli_sm_dev_data.json', 'w') as te_out_file:
    json.dump(contractnli_subset_dev_data, te_out_file, indent=4, ensure_ascii=False)
with open('data/converted/spannli_sm_test_data.json', 'w') as de_out_file:
    json.dump(contractnli_subset_test_data, de_out_file, indent=4, ensure_ascii=False)