# README

## Objective

To adapt the BERT backend architecture of span-NLI research paper and apply it to QA dataset where all contract tokens and questions tokens are concatenated with a special [SEP] token
and fed into a Transformer-based model. 


## Experiment approach
For evidence identification,  a randomly initialized multi-layer perceptron (MLP) on top of each [SPAN] token followed by sigmoid activation to predict a span probability to assign `1` or `0` for each span. 

Likewise for NLI, a randomly initialized MLP on top of the [CLS] token followed by a softmax layer to
predict `YES`, `NO` and `NOT_KNOWN`.


### Experiment setup
#### Local Machine

- With `conda`:

    ```bash
    conda deactivate \
      && conda env create -f environment.yml --force \
      && conda activate ica_exp
    ```

- With `venv`:

    ```bash
    python -m venv ica_exp \
      && source ica_exp/bin/activate \
      && pip install -r requirements.txt
    ```

- Run `pre-commit install` to set up the git hook scripts.

    ```bash
    pre-commit install
    ```
- Clone the git repo `https://github.com/stanfordnlp/contract-nli-bert`
- Place the raw `qa_data.json` at `./data/raw/` folder location
- Run `python data_translation.py` to convert raw data to converted fomat for spanNLI Bert model.
- Check to see if translated data is being populated at `./data/converted/` folder location.
- Run `python train.py ./data/conf_base.yml ./models`
- It will train the BERT model and save the generated model artifacts at `./models` folder.
- For inference, we need to first load the saved model from `./models` folder.
- Run `python test.py ./data/spannli_sm_dev_data.json ./models ./data/spannli_sm_test_data.json ./reports`

#### Modern Data Platform- MDP

- Log in to MDP with shared credentials 
- Browse to the notebook at the below locations
   1. `Training Notebook` -
    ```bash
    python -m spacy download en_core_web_sm    
    ```https://adb-3107913535185950.10.azuredatabricks.net/?o=3107913535185950#notebook/3809281890337253/command/540562750450556
    ```
    or copy and import the notebook place at below location to MDP workspace :
    `./mdp_notebooks/spanNLI_BERT_Train.ipynb`.

    2. `Testing Notebook` -
    ```bash
    python -m spacy download en_core_web_sm    
    ```https://adb-3107913535185950.10.azuredatabricks.net/?o=3107913535185950#notebook/4177658557842604/command/4177658557842605
    ```
    or copy and import the notebook place at below location to MDP workspace :
    `./mdp_notebooks/spanNLI_BERT_Test.ipynb`.

#### Evaluation Metrics from Model

1. `metrics['micro_label_micro_doc']`
    ```code
    {'class_binary': 
       {'accuracy': 0.8213333333333334,
        'precision_yes': 0.8954545454545455,
        'recall_yes': 0.8174273858921162,
        'f1_yes': 0.8546637744034707,
        'precision_no': 0.7161290322580646,
        'recall_no': 0.8283582089552238,
        'f1_no': 0.7681660899653979,
        'precision_mean': 0.8057917888563051,
        'precision_hmean': 0.7958147575288873,
        'recall_mean': 0.8228927974236699,
        'recall_hmean': 0.8228564977704189,
        'f1_mean': 0.8114149321844344,
        'f1_hmean': 0.8091097461703545}}
    ```

2. `metrics['micro_label_micro_doc']`
    ```code
    {'class_binary': 
       {'accuracy': 0.7877784420570549,
        'precision_yes': 0.622745119792419,
        'recall_yes': 0.5933460498536983,
        'f1_yes': 0.6024447026229948,
        'precision_no': 0.45725187510901794,
        'recall_no': 0.5628372172667694,
        'f1_no': 0.4974872512407572,
        'precision_mean': 0.5399984974507185,
        'precision_hmean': 0.2824302801388619,
        'recall_mean': 0.5780916335602339,
        'recall_hmean': 0.2883053450126892,
        'f1_mean': 0.549965976931876,
        'f1_hmean': 0.28522129207156466}}
    ```

#### Eexperiment References

1. [Research Paper](https://aclanthology.org/2021.findings-emnlp.164.pdf)
2. [Contract NLI Datset](https://stanfordnlp.github.io/contract-nli/)