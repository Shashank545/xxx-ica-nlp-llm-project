# ICA inference

## Introduction

Microservice to run ML inference for Independence Check Automation(ICA)

---

## Build Environment

- Create .env file for passing your PAT for when building the container. Add `MP_AUTO_RELOAD=true` as well for local changes detection for local testing.

    ```shell
      MP_AZURE_DEVOPS_PERSONAL_ACCESS_TOKEN=<PAT>
      MP_AUTO_RELOAD=true
    ```


---
## Build Poetry Environment
- Configure Poetry for `kit-pypi` and `msp artifacts`.
 ```shell
    poetry config http-basic.azure <PAT>
    poetry config http-basic.azure_msp <PAT>
 ```
- Install requirements
  ```shell
    poetry install
  ```

### Build & Run container

- Initial Setup
    ```shell
      az login --tenant e009942d-3130-4196-8091-8c4d4c8e44a1
      az account set --subscription KIT-MICROSERVICES-DEV-japaneast-20210129
      AZURE_CLI_DISABLE_CONNECTION_VERIFICATION=1 az acr login -n kitmicroservices.azurecr.io 
      AZURE_CLI_DISABLE_CONNECTION_VERIFICATION=1 az acr login -n kitmicroservicessand.azurecr.io
    ```
- Build docker images
    ```shell
      docker compose -f microservices/docker-compose.yaml --env-file .env build --progress=plain --pull
    ```
## Run ICA ML services locally

- Start ICA Ml service container
    ```shell
      docker compose -f microservices/docker-compose.yaml --env-file .env up
    ```

- Access Swagger UI at for local testing http://localhost:8000/docs

- The framework will detect that you are running on local and you can try out changes easily.

## Getting async job result.
### Nowait in getting result form async job.

`Nowait` is false by default.
Setting it to true will keep the connection alive for:
`LONG_POLLING_TIMEOUT_IN_SECONDS` and will retry every
`POLLING_INTERVAL_IN_SECONDS` until returning result and closing the connection.

At the moment these values are hard-coded to:
`POLLING_INTERVAL_IN_SECONDS`: 5
`LONG_POLLING_TIMEOUT_IN_SECONDS`: 30

---

### Tip about x-verbosity-level
To test these levels above, simple raise an exception
that's not caught in `AsyncJobWorker` method.

### x-verbosity-level: 0
- Just worker failed in result.

### x-verbosity-level: 1
- Worker failed.
- Traceback of exception.

### x-verbosity-level: 2
- Worker failed.
- Traceback of exception.
- Job history.
