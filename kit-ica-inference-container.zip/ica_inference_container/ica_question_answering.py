from __future__ import annotations

import io
from logging import getLogger
from typing import Callable

from azure.identity.aio import DefaultAzureCredential, get_bearer_token_provider
from kitmicroservices.framework.config import rt
from ica_inference.question_answering import answer_with_evidence
from openai import AsyncAzureOpenAI

logger = getLogger(__name__)


def get_openai_client() -> AsyncAzureOpenAI:
    """
    Get Azure OpenAI Async Client.

    Returns:
       AsyncAzureOpenAI: Azure OpenAI Async Client

    """
    azure_endpoint = rt.settings.get(
        "azure_open_ai__azure_endpoint",
        "https://msp-openai-japaneast.openai.azure.com",
    )
    api_version = rt.settings.get(
        "azure_open_ai__api_version", "2023-07-01-preview"
    )
    logger.info(f"Using Azure OpenAI Endpoint: {azure_endpoint}")

    token_provider = get_bearer_token_provider(
        DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default"
    )

    openai_client = AsyncAzureOpenAI(
        api_version=api_version,
        azure_endpoint=azure_endpoint,
        azure_ad_token_provider=token_provider,
    )
    return openai_client


async def get_answers_and_evidences(
    pdf_file: io.BytesIO,
    check_items: list,
    search_config_dict: dict,
    qa_config_dict: dict,
    tokenizer_config_dict: dict,
    min_sent_length: int = 15,
    min_semantic_score: float = 0.85,
    openai_client: Callable = get_openai_client,
    openai_completion_type_config: dict | None = None,
    return_token_usage: bool = False,
) -> dict:
    """
    Function to answer questions relative to a document.

    Args:
        pdf_file: Engagement letter pdf file.
        check_items: It's a list of dictionaries with information relative to
            the questions.
        tokenizer_config_dict: Config dict.
        qa_config_dict: Config dict.
        search_config_dict: Config dict.
        min_sent_length: Minimum length of a sentence to be used
            for semantic search.
        min_semantic_score: minimum semantic score that a passage needs to
            have with a question to be admitted as prompt.
        openai_client(Callable): Azure OpenAI client function which create Azure
            OpenAI Async client on call.
        openai_completion_type_config (dict): Config to map GPT model to chat
                completion or completion.
        return_token_usage(bool): If output should also have token usages for
                Azure OpenAI models.
    Returns:
        dict: Answers of the questions with bounding boxes of the words
        from the document that support the answer and token usages for
        Azure OpenAI.

    """

    output: dict = await answer_with_evidence(
        pdf_file=pdf_file,
        check_items=check_items,
        search_config_dict=search_config_dict,
        qa_config_dict=qa_config_dict,
        tokenizer_config_dict=tokenizer_config_dict,
        min_sent_length=min_sent_length,
        min_semantic_score=min_semantic_score,
        openai_client=openai_client,
        openai_completion_type_config=openai_completion_type_config,
        return_token_usage=return_token_usage,
    )

    return output
