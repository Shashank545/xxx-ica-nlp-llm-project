from ica_inference import set_utils_logger_log_level
from kitmicroservices.framework import startup_config

# Set underlying kit-ica-ml-pipelines loggers to same level as service.
set_utils_logger_log_level(startup_config.get_log_level())
