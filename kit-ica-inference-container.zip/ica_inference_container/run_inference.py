import io
import json
from logging import getLogger

from fastapi import UploadFile
from ica_inference.model_call import load_models_for_inference_service
from ica_inference.model_config import CudaUnavailableException, ModelsConfig
from kitmicroservices.framework import RunAtInit, Runner
from kitmicroservices.framework.jobcontext import AsyncJobContext
from kitmicroservices.framework.microservice import (
    CustomEndpointException,
    Microservice,
)

Service = Microservice(
    title="Independence Check Automation",
    description="Microservice for Independence Check Automation",
)

MODEL_CONFIG_YAML = "/opt/app/model_configs.yaml"

logger = getLogger(__name__)

config = ModelsConfig.load_config_from_yaml(MODEL_CONFIG_YAML)


class IcaQAworkerException(Exception):
    pass


@RunAtInit([Runner.WORKER])
def load_at_init():
    try:
        load_models_for_inference_service(config)
    except CudaUnavailableException:
        logger.exception("Cuda is unavailable - Will exit")
        exit(1)


@Service.AsyncJobSubmission(name="ica_qa_async")
async def ica_qa(
    async_job_context: AsyncJobContext,
    pdf_file: UploadFile,
    check_items: UploadFile,
):
    data = {"pdf_file": pdf_file, "check_items": check_items}

    __validate_inputs(data)

    await async_job_context.save_job_submission_input(data)
    async_job_context.set_job_timeout_in_minutes(
        AsyncJobContext.TimeoutInMinutes.LONG
    )


@Service.AsyncJobResult(name="ica_qa_async")
async def ica_qa_async_results(async_job_context: AsyncJobContext) -> dict:
    data: dict = await async_job_context.load_worker_job_result()
    return data


@Service.AsyncJobWorker(name="ica_qa_async")
async def ica_qa_worker(async_job_context: AsyncJobContext) -> None:
    try:
        from .ica_question_answering import get_answers_and_evidences

        parameters = await async_job_context.load_job_submission_input()
        pdf_file = parameters.get("pdf_file", None)
        check_items = parameters.get("check_items", None)

        pdf_file = await pdf_file.read()
        pdf_file = io.BytesIO(pdf_file)

        check_items = await check_items.read()
        check_items = json.loads(check_items)
        tokenizer_config_dict = config.get_tokenizer_config()
        search_config_dict = config.get_search_config_dict()
        qa_config_dict = config.get_qa_config_dict()
        openai_completion_type_config = config.completion_type_config

        output = await get_answers_and_evidences(
            pdf_file=pdf_file,
            check_items=check_items,
            search_config_dict=search_config_dict,
            qa_config_dict=qa_config_dict,
            tokenizer_config_dict=tokenizer_config_dict,
            min_semantic_score=search_config_dict["min_semantic_score"],
            openai_completion_type_config=openai_completion_type_config,
        )
    except Exception as e:
        raise IcaQAworkerException(
            f"ICA QA worker failed due to error: {str(e)}"
        )
    else:
        async_job_context.append_workload_info(
            {"unit_id": "ica_qa", "unit_total": 1}
        )
        await async_job_context.save_worker_job_result(output)


def __validate_inputs(inputs: dict):
    """
    Function to validate the inputs to inference job

    Args:
        inputs (dict): Dict with inputs to inference job i.e. pdf_file and
        check_items

    Raises:
        CustomEndpointException: Raises exception if any of the input is not of
            correct type.
    """

    if not inputs["pdf_file"].content_type == "application/pdf":
        raise CustomEndpointException(
            {"error": "pdf_file input is not of correct type"}, status_code=400
        )

    if not inputs["check_items"].content_type == "application/json":
        raise CustomEndpointException(
            {"error": "check_items input is not of correct type"},
            status_code=400,
        )
