import io

import flask
from docgcn_server import inference_caller
from flask import Flask
from PIL import Image

app = Flask(__name__)


@app.route("/", methods=["GET"])
def home():
    return "Hello World! Basic check works!!"


@app.route("/predict", methods=["POST"])
def predict():
    data = {"success": False}
    if flask.request.files.get("image"):
        image = flask.request.files["image"].read()
        image = Image.open(io.BytesIO(image))
        image_path = flask.request.files["image_path"].read()

        result = inference_caller(image, image_path)

        data["response"] = result
        data["success"] = True
    return flask.jsonify(data)


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True, port=8001)
