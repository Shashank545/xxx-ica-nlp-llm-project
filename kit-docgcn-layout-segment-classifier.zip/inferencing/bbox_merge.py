import argparse
import json

import cv2
from PIL import Image, ImageDraw

# Get arg parse values
parser = argparse.ArgumentParser()
parser.add_argument(
    "--img", type=str, help="Insert test sample image path for inferencing with DocGCN"
)

args = vars(parser.parse_args())
print(args["img"])

# img_path = sys.argv[1]
image_path = args["img"]

# image_path = "inferencing/2.tar_1401.0812.gz_NewversionArXiv_26_ori.jpg"
img = cv2.imread(image_path)

# img = Image.open(image_path)
print("\n\n")
json_suffix = "_pred_new.json"
overlay_suffix = "_cv2_merged.jpg"

json_path = (
    image_path.split("/")[0]
    + "/res_data/"
    + image_path.split("/")[1][:-4]
    + json_suffix
)
postprocessed_overlay_path = (
    image_path.split("/")[0]
    + "/res_data/"
    + image_path.split("/")[1][:-4]
    + overlay_suffix
)

with open(json_path, "r") as fb:
    ocr_data = json.load(fb)

ocr_bbox = [ocr["bbox"] for ocr in ocr_data]
labels = [ocr["text_predictions"] for ocr in ocr_data]

# print(ocr_bbox)
# print("\n\n")
# print(labels)

x_pixel_value = 7
y_pixel_value = 15

bboxes_list = ocr_bbox  # your bounding boxes list
rects_used = []

for i in bboxes_list:
    rects_used.append(False)

end_bboxes_list = {}
end_bboxes_list["merge_boxes"] = []
end_bboxes_list["merge_labels"] = []

for enum, (i, k) in enumerate(zip(bboxes_list, labels)):
    if rects_used[enum] == True:
        continue
    xmin = i[0]
    xmax = i[2]
    ymin = i[1]
    ymax = i[3]
    # print(k)

    for enum1, (j, m) in enumerate(
        zip(bboxes_list[(enum + 1) :], labels[(enum + 1) :]), start=(enum + 1)
    ):
        i_xmin = j[0]
        i_xmax = j[2]
        i_ymin = j[1]
        i_ymax = j[3]
        # print(k,m)

        if rects_used[enum1] == False:
            if abs(ymin - i_ymin) < x_pixel_value:
                if (
                    abs(xmin - i_xmax) < y_pixel_value
                    or abs(xmax - i_xmin) < y_pixel_value
                ):
                    if k == m:
                        rects_used[enum1] = True
                        xmin = min(xmin, i_xmin)
                        xmax = max(xmax, i_xmax)
                        ymin = min(ymin, i_ymin)
                        ymax = max(ymax, i_ymax)
    final_box = [xmin, ymin, xmax, ymax]
    end_bboxes_list["merge_boxes"].append(final_box)
    end_bboxes_list["merge_labels"].append(k)


for bb, ll in zip(end_bboxes_list["merge_boxes"], end_bboxes_list["merge_labels"]):
    img = cv2.rectangle(
        img, (bb[0], bb[1]), (bb[2], bb[3]), color=[0, 255, 0], thickness=2
    )
    cv2.putText(
        img, ll, (bb[0], bb[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 12, 12), 2
    )

print("<Image Results successfully overlayed after postprocessing!!!>")
cv2.imwrite(postprocessed_overlay_path, img)
cv2.imshow("Image", img)
cv2.waitKey(10000)
cv2.destroyAllWindows()
