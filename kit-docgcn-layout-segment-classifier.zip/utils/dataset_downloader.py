import argparse
import logging
import os
import subprocess
import urllib
from urllib.error import HTTPError

import rarfile

logging.basicConfig( 
        filename = 'app.log', 
        level = logging.DEBUG, 
        format = '%(levelname)s:%(asctime)s:%(message)s')


# Instantiate the parser
parser = argparse.ArgumentParser(description='Parser to download Datasets for FUNSD and Docbank')
# Required positional argument
parser.add_argument('--dataset_type', type=str, dest="dataset_type",
                    help='A flag to indentify the selected dataset to download')

args = parser.parse_args()

os.system(f"""git clone 'https://github.com/airsplay/py-bottom-up-attention.git'""")

if args.dataset_type == "funsd":
    try:
        logging.debug("Downloading ..... FUNSD dataset")
        os.system(f"""wget 'https://guillaumejaume.github.io/FUNSD/dataset.zip'""")
        os.system(f"""unzip dataset.zip && mv dataset funsd_dataset && rm -rf dataset.zip __MACOSX""")
    except Exception as e:
        print(e)

elif args.dataset_type == "docbank":
    try:
        logging.debug("Downloading ..... DOCBANK dataset")
        os.system(f"""wget 'https://layoutlm.blob.core.windows.net/docbank/dataset/DocBank_500K_txt.zip'""")
        os.system(f"""wget 'https://layoutlm.blob.core.windows.net/docbank/dataset/DocBank_500K_ori_img.zip.001'""")
        os.system(f"""wget 'https://layoutlm.blob.core.windows.net/docbank/dataset/DocBank_500K_ori_img.zip.002'""")
        os.system(f"""wget 'https://layoutlm.blob.core.windows.net/docbank/dataset/DocBank_500K_ori_img.zip.003'""")
        os.system(f"""wget 'https://layoutlm.blob.core.windows.net/docbank/dataset/DocBank_500K_ori_img.zip.004'""")
        os.system(f"""wget 'https://layoutlm.blob.core.windows.net/docbank/dataset/DocBank_500K_ori_img.zip.005'""")
        subprocess.run(f"""wget 'https://layoutlm.blob.core.windows.net/docbank/dataset/DocBank_500K_ori_img.zip.001'""")
        # need to work on extraction of RAR file after PublicAccessNotPermitted error is lifted 
        # rf = rarfile.RarFile("../DocBank_500K_txt.zip")
        # rf.extractall("..,dataset/")
    except Exception as err:
        print(f'{err} is the error')
    

else:
    raise ValueError('Oops! wrong dataset name given. Try with correct one')

# Command to run
# python utils/dataset_downloader.py --dataset_type docbank