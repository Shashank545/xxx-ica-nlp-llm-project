import os

from transformers import AutoModel, AutoTokenizer, BertTokenizer

os.environ["CURL_CA_BUNDLE"] = ""

bert_base_tokenizer = BertTokenizer.from_pretrained(
    "bert-base-uncased", cache_dir="../models/bert-base-tokenizer"
)
bert_base_tokenizer.save_pretrained("../models/bert-base-tokenizer")
bert_large_tokenizer = BertTokenizer.from_pretrained(
    "bert-large-uncased", cache_dir="../models/bert-large-tokenizer"
)
bert_large_tokenizer.save_pretrained("../models/bert-large-tokenizer")
bert_base_uncased = AutoModel.from_pretrained(
    "bert-base-uncased", cache_dir="../models/bert-base-uncased"
)
bert_base_uncased.save_pretrained("../models/bert-base-uncased")
bert_large_uncased = AutoModel.from_pretrained(
    "bert-large-uncased", cache_dir="../models/bert-large-uncased"
)
bert_large_uncased.save_pretrained("../models/bert-large-uncased")
