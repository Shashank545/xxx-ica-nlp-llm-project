from PIL import Image
import os
import json
import nltk
# import benepar
import pickle
import spacy
# from benepar.spacy_plugin import BeneparComponent
# import benepar
# benepar.download('benepar_en3')

nltk.download('punkt')

nlp = spacy.load('en_core_web_sm')

# if spacy.__version__.startswith('2'):
#         nlp.add_pipe(benepar.BeneparComponent("benepar_en3"))
# else:
#     nlp.add_pipe("benepar", config={"model": "benepar_en3"})

def funsd_scene_graph_generator(input_path, type):

    # There are two types scene graphs one is position based global scene graph
    # Another one is document components structural relationship based binary scene graph
    # Type 1 means global relationship which will return reletively globally positional relationship 
    # Type 2 will return binary structure or logical relationship between components

    json_path = input_path+'/annotations/'
    img_path = input_path+'/images'
    img_list = os.listdir(img_path)
    # for training dataset bbox_id = 0 setting this to order all trainind and validation dataset
    # bbox_id = 7412 
    bbox_id = 0
    relation_id = 0
    bi_relation = 8473
    scene_graph = {}
    for index in range(len(img_list)):
        print(index)
        name = img_list[index][:-4]
        print(name)
        image = Image.open(img_path+'/'+name+'.png')
        info_path = json_path+name+'.json'
        with open(info_path) as f:
            info_list = json.load(f)
        info_list = info_list['form']
        scene_graph[name] = {}
        scene_graph[name]['file_name'] = name
        scene_graph[name]['width'] = image.size[0]
        scene_graph[name]['height'] = image.size[1]
        scene_graph[name]['objects'] = {}
        for i in range(len(info_list)):
            scene_graph[name]['objects'][str(i)] = {}
            scene_graph[name]['objects'][str(i)]['id'] = bbox_id
            bbox_id += 1
            scene_graph[name]['objects'][str(i)]['box'] = info_list[i]['box']
            scene_graph[name]['objects'][str(i)]['category'] = info_list[i]['label']
            scene_graph[name]['objects'][str(i)]['text'] = info_list[i]['text']
            scene_graph[name]['objects'][str(i)]['relations'] = {}

        # returning scene graph is position based global scene graph
        if type == 1:
            for i in scene_graph[name]['objects']:
                current_box = scene_graph[name]['objects'][i]
                box1 = current_box['box']
                c_relation = 0
                for j in scene_graph[name]['objects']:
                    if i != j:
                        box2 = scene_graph[name]['objects'][j]['box']
                        current_box['relations'][str(c_relation)] = {}
                        current_box['relations'][str(c_relation)]['id'] = relation_id
                        current_box['relations'][str(c_relation)]['object'] = scene_graph[name]['objects'][j]['id']
                        # be cautious of ignoring this
                        # current_box['relations'][str(c_relation)]['name'] = relative_position(box1,box2)
                        relation_id += 1
                        c_relation += 1


        # type 0 will return binary relationships between bounding box
        # for funsd dataset, it will represent the question and corresponding answer relationships
        # if current node is a question, the relation will be annotated as 'answer' to its answer
        # if current node is a answer, the relation will be annotated as 'question' 
        elif type == 0:
            for i in scene_graph[name]['objects']:
                current_box = scene_graph[name]['objects'][i]
                k = int(i)
                if len(info_list[k]['linking']) != 0:
                    for n in range(len(info_list[k]['linking'])):
                        linking_node = info_list[k]['linking'][n]
                        current_box['relations'][str(n)] = {}
                        node1 = linking_node[0]
                        node2 = linking_node[1]
                        if node1 == k:
                            current_box['relations'][str(n)]['name'] = info_list[node2]['label']
                            current_box['relations'][str(n)]['id'] = bi_relation
                            current_box['relations'][str(n)]['object'] = scene_graph[name]['objects'][str(node2)]['id']
                            bi_relation += 1
                        elif node2 == k:
                            current_box['relations'][str(n)]['name'] = info_list[node1]['label']
                            current_box['relations'][str(n)]['id'] = bi_relation
                            current_box['relations'][str(n)]['object'] = scene_graph[name]['objects'][str(node1)]['id']
                            bi_relation += 1

    if type == 1:
        return scene_graph
    if type == 0:
        print(bbox_id,bi_relation)
        return scene_graph
    

# number of characters / bounding box size
def char_density(obj):
    text = obj['text']
    x1,y1,x2,y2 = obj['box']
    size = abs(x2-x1)*abs(y2-y1)
    density = len(text)/size
    obj['char_density'] = density

# number of characters
def char_number(obj):
    text = obj['text']
    char_num = len(text)
    obj['char_number'] = char_num


# number of tokens / bounding box size
def token_density(obj):
    text = obj['text']
    x1,y1,x2,y2 = obj['box']
    tokenized_text = nltk.word_tokenize(text)
    size = abs(x2-x1)*abs(y2-y1)
    density = len(tokenized_text)/size
    obj['text_density'] = density


# number of tokens
def token_number(obj):
    text = obj['text']
    tokenized_text = nltk.word_tokenize(text)
    token_num = len(tokenized_text)
    obj['text_number'] = token_num


# define a function to calculate bounding box manhattan distance
# Manhattan distance
def manhanttan_distance(bbox1, bbox2):
    x1, y1, x12, y12 = bbox1
    x2, y2, x22, y22 = bbox2
    w1 = abs(x12-x1)
    h1 = abs(y12-y1)
    w2 = abs(x22-x2)
    h2 = abs(y22-y2)
    dist = abs(x2-x1) + abs(y2-y1)
    if x2>x1 and abs(x2-x1)>w1:
        dist = dist-w1
    elif x2<x1 and abs(x2-x1)>w2:
        dist = dist-w2
    elif y1>y2 and abs(y1-y2)>h2:
        dist = dist-h2
    elif y2>y1 and abs(y1-y2)>h1:
        dist = dist-h1
    return dist

# directly return the gap distance bewteen bounding boxes
def gap_distance(bbox1, bbox2):
    x1, y1, x12, y12 = bbox1
    x2, y2, x22, y22 = bbox2
    w1 = abs(x12-x1)
    h1 = abs(y12-y1)
    w2 = abs(x22-x2)
    h2 = abs(y22-y2)
    dist = 0
    if x2>x1 and abs(x2-x1)>w1:
        dist = abs(x2-x1)-w1
    elif x2<x1 and abs(x2-x1)>w2:
        dist = abs(x2-x1)-w2
    elif y1>y2 and abs(y1-y2)>h2:
        dist = abs(y2-y1)-h2
    elif y2>y1 and abs(y1-y2)>h1:
        dist = abs(y2-y1)-h1
    return dist



train_scenegraph_binary = funsd_scene_graph_generator('../data/training_data', 0)
with open("../features/funsd_full_feature_sg_train_binary_0.json", "w") as fp:
    json.dump(train_scenegraph_binary , fp)

test_scenegraph_binary = funsd_scene_graph_generator('../data/testing_data', 0)
with open("../features/funsd_full_feature_sg_test_binary_0.json", "w") as fp:
    json.dump(test_scenegraph_binary , fp)

train_scenegraph_positional = funsd_scene_graph_generator('../data/training_data', 1)
with open("../features/funsd_full_feature_sg_train_positional_1.json", "w") as fp:
    json.dump(train_scenegraph_positional , fp)

test_scenegraph_positional = funsd_scene_graph_generator('../data/testing_data', 1)
with open("../features/funsd_full_feature_sg_test_positional_1.json", "w") as fp:
    json.dump(test_scenegraph_positional , fp)


train_list_dict = train_scenegraph_positional
eval_list_dict = test_scenegraph_positional

for l in train_list_dict:
    obj = train_list_dict[l]['objects']
    for obj1 in obj:
        obj[obj1]['gap'] = {}
        for obj2 in obj:
            if obj1 != obj2:
                dist = gap_distance(obj[obj1]['box'],obj[obj2]['box'])
                obj[obj1]['gap'][obj2] = dist


for l in eval_list_dict:
    obj = eval_list_dict[l]['objects']
    for obj1 in obj:
        obj[obj1]['gap'] = {}
        for obj2 in obj:
            if obj1 != obj2:
                dist = gap_distance(obj[obj1]['box'],obj[obj2]['box'])
                obj[obj1]['gap'][obj2] = dist


for l in train_list_dict:
    for obj in train_list_dict[l]['objects']:
        token_density(train_list_dict[l]['objects'][obj])
        token_number(train_list_dict[l]['objects'][obj])
        char_density(train_list_dict[l]['objects'][obj])
        char_number(train_list_dict[l]['objects'][obj])

for l in eval_list_dict:
    for obj in eval_list_dict[l]['objects']:
        token_density(eval_list_dict[l]['objects'][obj])
        token_number(eval_list_dict[l]['objects'][obj])
        char_density(eval_list_dict[l]['objects'][obj])
        char_number(eval_list_dict[l]['objects'][obj])


for img in train_list_dict:
    print(img)
    if img not in ['92314414']:
        for i in train_list_dict[img]['objects']:
            box = train_list_dict[img]['objects'][i]
            text = box['text']
            doc = nlp(text)
            try:
                sent = list(doc.sents)[0]
                parse = sent._.parse_string
                _,level1,level2 = constituency_parsing_extractor(parse)
                box['parsing_level1'] = level1
                box['parsing_level2'] = level2
            except:
                box['parsing_level1'] = []
                box['parsing_level2'] = []
    else:
        for x in train_list_dict[img]['objects']:
            box = train_list_dict[img]['objects'][x]
            box['parsing_level1'] = []
            box['parsing_level2'] = []

for img in eval_list_dict:
    print(img)
    for i in eval_list_dict[img]['objects']:
        box = eval_list_dict[img]['objects'][i]
        text = box['text']
        doc = nlp(text)
        try:
            sent = list(doc.sents)[0]
            parse = sent._.parse_string
            _,level1,level2 = constituency_parsing_extractor(parse)
            box['parsing_level1'] = level1
            box['parsing_level2'] = level2
        except:
            box['parsing_level1'] = []
            box['parsing_level2'] = []


with open("../features/funsd_full_feature_sg_train_v4.json", "w") as fp:
    json.dump(train_list_dict , fp) 
 
with open("../features/funsd_full_feature_sg_test_v4.json", "w") as fp:
    json.dump(eval_list_dict , fp)


with open("/features/textual_features/funsd_train_bert_cls_emb.pkl", "rb") as fp:
    train_text_vectors = pickle.load(fp) 
 
with open("/features/textual_features/funsd_test_bert_cls_emb.pkl", "rb") as fp:
    test_text_vectors = pickle.load(fp)


for l in train_scenegraph_positional:
    for i, obj in enumerate(train_scenegraph_positional[l]['objects']):
        train_scenegraph_positional[l]['objects'][obj]['bert_large_emb'] = train_text_vectors[i]

for l in test_scenegraph_positional:
    for i, obj in enumerate(test_scenegraph_positional[l]['objects']):
        test_scenegraph_positional[l]['objects'][obj]['bert_large_emb'] = test_text_vectors[i]


with open("../features/funsd_full_feature_sg_train_positional_1_edited.json", "w") as fp:
    json.dump(train_scenegraph_positional, fp)
    
with open("../features/funsd_full_feature_sg_test_positional_1_edited.json", "w") as fp:
    json.dump(test_scenegraph_positional, fp)