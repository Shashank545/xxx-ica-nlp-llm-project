from __future__ import division, print_function

import argparse
import itertools
import json
import logging
import math
import os
import pickle
import warnings

# Settings the warnings to be ignored
warnings.filterwarnings("ignore")

import numpy as np
import scipy.sparse as sp
import tensorflow.compat.v1 as tf
import torch
from pandas import DataFrame
from sklearn.preprocessing import LabelEncoder
from tqdm import tqdm

logging.basicConfig(
    filename="training/app.log",
    level=logging.DEBUG,
    format="%(levelname)s:%(asctime)s:%(message)s",
)


# global unique layer ID dictionary for layer name assignment
_LAYER_UIDS = {}

# # Set random seed
# seed = random.randint(1, 200)
# np.random.seed(seed)
# tf.set_random_seed(seed)


# Settings
os.environ["CUDA_VISIBLE_DEVICES"] = "1,2"

flags = tf.app.flags
FLAGS = flags.FLAGS
for name in list(flags.FLAGS):
    delattr(flags.FLAGS, name)
flags.DEFINE_string("f", "", "kernel")
flags.DEFINE_string("dataset", "sencegraph", "Dataset string.")
# 'gcn', 'gcn_cheby', 'dense'
flags.DEFINE_string("model", "gcn", "Model string.")
flags.DEFINE_float("learning_rate", 0.00001, "Initial learning rate.")
flags.DEFINE_integer("epochs", 100, "Number of epochs to train.")
flags.DEFINE_integer("hidden1", 1024, "Number of units in hidden layer 1.")
flags.DEFINE_float("dropout", 0.5, "Dropout rate (1 - keep probability).")
flags.DEFINE_float("weight_decay", 0, "Weight for L2 loss on embedding matrix.")  # 5e-4
flags.DEFINE_integer(
    "early_stopping", 20, "Tolerance for early stopping (# of epochs)."
)
flags.DEFINE_integer("max_degree", 3, "Maximum Chebyshev polynomial degree.")
flags.DEFINE_string("dataset_type", "docbank", "Docbank dataset")
flags.DEFINE_string("dataset_path", "./datastore", "Docbank dataset")

# Instantiate the parser
parser = argparse.ArgumentParser(
    description="Parser to generate distance based GCN graphs for FUNSD and Docbank"
)
# Required positional argument
parser.add_argument(
    "--dataset_type",
    type=str,
    dest="dataset_type",
    help="A flag to indentify the selected dataset to PREPROCESS",
)

parser.add_argument(
    "--dataset_path",
    type=str,
    dest="dataset_path",
    help="root path to dataset being used for preprocessing",
)

args = parser.parse_args()
print("Dataset path :", args.dataset_path)
print("Dataset type :", args.dataset_type)
root_data_dir = args.dataset_path
# root_data_dir = "./datastore"

with open(
    root_data_dir
    + "/pipe_placeholder/docbank_full_feature_sg_train_positional_1_edited.json",
    "r",
) as fp:
    train_list_dict = json.load(fp)

with open(
    root_data_dir
    + "/pipe_placeholder/docbank_full_feature_sg_test_positional_1_edited.json",
    "r",
) as fp:
    test_list_dict = json.load(fp)

print("\nTraining Files\n")
print(train_list_dict.keys())
print("\n \n")
print("\nTesting Files\n")
print(test_list_dict.keys())
print("\n \n")


# according to id to search object id in a document
def globalid_to_localid(list_dict, id):
    for l in list_dict:
        for obj in list_dict[l]["objects"]:
            if id == list_dict[l]["objects"][obj]["id"]:
                return obj


# Define model evaluation function
def evaluate(sess, model, features, support, labels, mask, placeholders):
    print(model.labels)
    feed_dict_val = construct_feed_dict(features, support, labels, mask, placeholders)
    outs_val = sess.run(
        [
            model.loss,
            model.accuracy,
            model.pred,
            model.labels,
            model.layers[0].embedding,
            model.layers[1].embedding,
        ],
        feed_dict=feed_dict_val,
    )
    return outs_val[0], outs_val[1], outs_val[2], outs_val[3], outs_val[4], outs_val[5]


def construct_feed_dict(features, support, labels, labels_mask, placeholders):
    """Construct feed dictionary."""
    feed_dict = dict()
    feed_dict.update({placeholders["labels"]: labels})
    feed_dict.update({placeholders["labels_mask"]: labels_mask})
    feed_dict.update({placeholders["features"]: features})
    feed_dict.update(
        {placeholders["support"][i]: support[i] for i in range(len(support))}
    )
    feed_dict.update({placeholders["num_features_nonzero"]: features[1].shape})
    return feed_dict


def sparse_to_tuple(sparse_mx):
    """Convert sparse matrix to tuple representation."""

    def to_tuple(mx):
        if not sp.isspmatrix_coo(mx):
            mx = mx.tocoo()
        coords = np.vstack((mx.row, mx.col)).transpose()
        values = mx.data
        shape = mx.shape
        return coords, values, shape

    if isinstance(sparse_mx, list):
        for i in range(len(sparse_mx)):
            sparse_mx[i] = to_tuple(sparse_mx[i])
    else:
        sparse_mx = to_tuple(sparse_mx)
    return sparse_mx


def preprocess_features(features):
    """Row-normalize feature matrix and convert to tuple representation"""
    rowsum = np.array(features.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.0
    r_mat_inv = sp.diags(r_inv)
    features = r_mat_inv.dot(features)
    return sparse_to_tuple(features)


# one dimensional feature embedding
def positionalencoding1d(d_model, feature_list):
    """
    :param d_model: dimension of the model
    :param feature_list: length of positions
    :return: length*d_model position matrix
    """
    if d_model % 2 != 0:
        raise ValueError(
            "Cannot use sin/cos positional encoding with "
            "odd dim (got dim={:d})".format(d_model)
        )
    pe = torch.zeros(len(feature_list), d_model)
    feats = torch.tensor(feature_list).unsqueeze(1)
    div_term = torch.exp(
        (
            torch.arange(0, d_model, 2, dtype=torch.float)
            * -(math.log(10000.0) / d_model)
        )
    )
    pe[:, 0::2] = torch.sin(feats.float() * div_term)
    pe[:, 1::2] = torch.cos(feats.float() * div_term)
    pe = pe.tolist()
    return pe


def normalize_adj(adj):
    """Symmetrically normalize adjacency matrix."""
    adj = sp.coo_matrix(adj)
    rowsum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.0
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).tocoo()


def preprocess_adj(adj):
    """Preprocessing of adjacency matrix for simple GCN model and conversion to tuple representation."""
    adj_normalized = normalize_adj(adj + sp.eye(adj.shape[0]))
    return sparse_to_tuple(adj_normalized)


def base_feature_extraction(train_list_dict, test_list_dict):
    # Generate local graph based training dataset objects and relations list
    new_train_list_dict = {}
    for l in tqdm(train_list_dict, desc="Training relationships"):
        tem_dic = {}
        tem_dic["objects"] = []
        tem_dic["relationships"] = []

        for obj in train_list_dict[l]["objects"]:
            tem_dic["objects"].append(obj)
            for rel in train_list_dict[l]["objects"][obj]["relations"]:
                # print(rel)
                tem_rel = [obj]
                obj2_id = rel[0]
                tem_rel.append(obj2_id)
                name = rel[0]
                tem_rel.append(name)
                tem_dic["relationships"].append(tem_rel)
        new_train_list_dict[l] = tem_dic

    new_test_list_dict = {}
    for l in tqdm(test_list_dict, desc="Testing relationships"):
        tem_dic = {}
        tem_dic["objects"] = []
        tem_dic["relationships"] = []

        for obj in test_list_dict[l]["objects"]:
            tem_dic["objects"].append(obj)
            for rel in test_list_dict[l]["objects"][obj]["relations"]:
                # print(rel)
                tem_rel = [obj]
                obj2_id = rel[0]
                tem_rel.append(obj2_id)
                name = rel[0]
                tem_rel.append(name)
                tem_dic["relationships"].append(tem_rel)
        new_test_list_dict[l] = tem_dic

    # Using for searching real node size
    num_obj_dict = {}
    for l in new_train_list_dict:
        num_obj_dict[l] = len(new_train_list_dict[l]["objects"])
    for l in new_test_list_dict:
        num_obj_dict[l] = len(new_test_list_dict[l]["objects"])

    # useless code only rename
    list_dict_train = {}
    for l in new_train_list_dict:
        list_dict_train[l] = new_train_list_dict[l]
    list_dict_test = {}
    for l in new_test_list_dict:
        list_dict_test[l] = new_test_list_dict[l]

    # generate the training and labeling information for each image
    # this information can be used to transfer object id to corresponding visual, text density or other kinds of features.
    density_list_train = []
    label_list_train = []
    img_list_train = []
    label_dict_train = {}
    for l in train_list_dict:
        label_dict_train[l] = []
        for obj in train_list_dict[l]["objects"]:
            density_list_train.append(obj)
            label_list_train.append(train_list_dict[l]["objects"][obj]["category"])
            img_list_train.append(l)
            label_dict_train[l].append(train_list_dict[l]["objects"][obj]["category"])
        for obj in range(num_obj_dict[l], 1173):
            density_list_train.append(str(obj))
            label_list_train.append(str(-1))
            img_list_train.append(l)
            label_dict_train[l].append(str(-1))

    # generating evalutaion labeling informaiton dictionary
    density_list_test = []
    label_list_test = []
    label_dict_test = {}
    img_list_test = []
    for l in test_list_dict:
        label_dict_test[l] = []
        for obj in test_list_dict[l]["objects"]:
            density_list_test.append(obj)
            label_list_test.append(test_list_dict[l]["objects"][obj]["category"])
            img_list_test.append(l)
            label_dict_test[l].append(test_list_dict[l]["objects"][obj]["category"])
        for obj in range(num_obj_dict[l], 1173):
            density_list_test.append(str(obj))
            label_list_test.append(str(-1))
            img_list_test.append(l)
            label_dict_test[l].append(str(-1))

    df_train = DataFrame(density_list_train, columns=["density"])
    df_train["label"] = label_list_train
    df_train["image"] = img_list_train

    df_test = DataFrame(density_list_test, columns=["density"])
    df_test["label"] = label_list_test
    df_test["image"] = img_list_test

    logging.debug(f"DF Train shape : {df_train.shape}")
    logging.debug(f"DF Test shape : {df_test.shape}")

    label_list_train = df_train["label"].fillna("other").tolist()
    label_list_test = df_test["label"].fillna("other").tolist()

    logging.debug(len(label_list_train) / 1173)

    df_train_clean = df_train[df_train["label"].notnull()][
        ["density", "label", "image"]
    ]
    df_test_clean = df_test[df_test["label"].notnull()][["density", "label", "image"]]

    label_list_train = df_train_clean["label"].to_list()
    label_list_test = df_test_clean["label"].to_list()

    id_list_train = df_train_clean["density"].to_list()
    id_list_test = df_test_clean["density"].to_list()

    img_list_train = df_train_clean["image"].to_list()
    img_list_test = df_test_clean["image"].to_list()

    obj_list_train = []
    for i in range(len(id_list_train)):
        tem = []
        tem = [id_list_train[i], img_list_train[i]]
        obj_list_train.append(tem)

    obj_list_test = []
    for i in range(len(id_list_test)):
        tem = []
        tem = [id_list_test[i], img_list_test[i]]
        obj_list_test.append(tem)

    logging.debug(f"Train Checkpoint 1 : {len(obj_list_train)}")
    logging.debug(f"Test Checkpoint 1 : {len(obj_list_test)}")

    # convert label into one-hot
    num_class = len(list(set(label_list_train)))
    logging.debug(f"num_class : {num_class}")
    lEnc = LabelEncoder()
    lEnc.fit(np.unique(list(set(label_list_train))))
    labels_one_hot_train = {}
    for f in label_dict_train:
        num_labels = lEnc.transform(label_dict_train[f])
        labels_one_hot_train[f] = []
        for l in num_labels:
            to_add = [0] * num_class
            to_add[l] = 1
            labels_one_hot_train[f].append(to_add)

    labels_one_hot_test = {}
    for f in label_dict_test:
        lEnc = LabelEncoder()
        lEnc.fit(np.unique(label_dict_test[f]))
        num_labels = lEnc.transform(label_dict_test[f])
        labels_one_hot_test[f] = []
        for l in num_labels:
            to_add = [0] * num_class
            to_add[l] = 1
            labels_one_hot_test[f].append(to_add)

    logging.debug(f"Train One-Hot Labels : {len(labels_one_hot_train)}")
    logging.debug(f"Test One-Hot Labels : {len(labels_one_hot_test)}")

    return (
        new_train_list_dict,
        new_test_list_dict,
        list_dict_train,
        list_dict_test,
        num_obj_dict,
        labels_one_hot_train,
        labels_one_hot_test,
    )


def build_gcn_graphs(
    new_train_list_dict, new_test_list_dict, list_dict_train, list_dict_test
):
    # Build Graphs
    node_lists_train = {}
    for l in new_train_list_dict:
        node_lists_train[l] = []
        for obj in new_train_list_dict[l]["objects"]:
            node_lists_train[l].append(obj)

    node_lists_test = {}
    for l in new_test_list_dict:
        node_lists_test[l] = []
        for obj in new_test_list_dict[l]["objects"]:
            node_lists_test[l].append(obj)

    # build local graph for train
    object_graph_dict_train = {}
    for l in new_train_list_dict:
        object_graph_dict_train[l] = {}
        for obj in new_train_list_dict[l]["objects"]:
            object_graph_dict_train[l][obj] = {}
            object_graph_dict_train[l][obj]["obj2"] = []

    # build local graph for test
    object_graph_dict_test = {}
    for l in new_test_list_dict:
        object_graph_dict_test[l] = {}
        for obj in new_test_list_dict[l]["objects"]:
            object_graph_dict_test[l][obj] = {}
            object_graph_dict_test[l][obj]["obj2"] = []

    # fill the empty graph train
    for sg in list_dict_train:
        obj_list = list_dict_train[sg]["objects"]
        for rel_item in list_dict_train[sg]["relationships"]:
            obj1 = str(rel_item[0])
            obj2 = str(rel_item[1])
            object_graph_dict_train[sg][rel_item[0]]["obj2"].append(obj2)

    # fill the empty graph test
    for sg in list_dict_test:
        obj_list = list_dict_test[sg]["objects"]
        for rel_item in list_dict_test[sg]["relationships"]:
            obj1 = str(rel_item[0])
            obj2 = str(rel_item[1])
            object_graph_dict_test[sg][rel_item[0]]["obj2"].append(obj2)

    node_size_train = []
    for f in object_graph_dict_train:
        l = object_graph_dict_train[f].keys()
        node_size_train.append(len(l))

    node_size_test = []
    for f in object_graph_dict_test:
        l = object_graph_dict_test[f].keys()
        node_size_test.append(len(l))

    logging.debug(
        f"Maximum dimension or size among all train nodes : {max(node_size_train)}"
    )
    logging.debug(
        f"Maximum dimension or size among all test nodes : {max(node_size_test)}"
    )
    max_train_node_size = max(node_size_train)
    # max_test_node_size = max(node_size_test)
    max_test_node_size = max(node_size_train)

    return (
        object_graph_dict_train,
        object_graph_dict_test,
        node_lists_train,
        node_lists_test,
        max_train_node_size,
        max_test_node_size,
    )


def build_gcn_model(
    object_graph_dict_train,
    object_graph_dict_test,
    max_train_node_size,
    max_test_node_size,
    num_obj_dict,
    labels_one_hot_train,
    labels_one_hot_test,
):
    # max_len = max_train_node_size
    # padding methods
    # weight for padding is -1
    # node id if for padding nodes is -1
    max_len = max_train_node_size
    col_train = {}
    row_train = {}
    weight_train = {}
    for f in object_graph_dict_train:
        col_train[f] = []
        row_train[f] = []
        weight_train[f] = []
        for obj in object_graph_dict_train[f]:
            obj_rel_list = object_graph_dict_train[f][obj]["obj2"]
            for obj2 in object_graph_dict_train[f]:
                if obj2 in obj_rel_list:
                    weight_train[f].append(1.0)
                else:
                    weight_train[f].append(0.0)
                row_train[f].append(obj)
                col_train[f].append(obj2)

    # padding methods
    # weight for padding is -1
    # node id if for padding nodes is -1
    max_len = max_test_node_size
    col_test = {}
    row_test = {}
    weight_test = {}
    for f in object_graph_dict_test:
        col_test[f] = []
        row_test[f] = []
        weight_test[f] = []
        for obj in object_graph_dict_test[f]:
            obj_rel_list = object_graph_dict_test[f][obj]["obj2"]
            for obj2 in object_graph_dict_test[f]:
                if obj2 in obj_rel_list:
                    weight_test[f].append(1.0)
                else:
                    weight_test[f].append(0.0)
                row_test[f].append(obj)
                col_test[f].append(obj2)

    # Train adjacency matrix creation
    adj_train = {}
    for f in weight_train:
        adj_train[f] = sp.csr_matrix(
            (weight_train[f], (row_train[f], col_train[f])),
            shape=(max_train_node_size, max_train_node_size),
        )
    # Test adjacency matrix creation
    adj_test = {}
    for f in weight_test:
        adj_test[f] = sp.csr_matrix(
            (weight_test[f], (row_test[f], col_test[f])),
            shape=(max_test_node_size, max_test_node_size),
        )

    # feature train
    features_train = {}
    for l in node_lists_train:
        features_train[l] = []
        for node in node_lists_train[l]:
            feature = np.array([0.0] * 768)
            feature += id_bert_dict[l][str(node)]
            features_train[l].append(feature)
        for i in range(len(node_lists_train[l]), max_train_node_size):
            feature = np.array([0.0] * 768)
            features_train[l].append(feature)
        features_train[l] = sp.csr_matrix(features_train[l])

    features_test = {}
    for l in node_lists_test:
        features_test[l] = []
        for node in node_lists_test[l]:
            feature = np.array([0.0] * 768)
            feature += id_bert_dict[l][str(node)]
            features_test[l].append(feature)
        for i in range(len(node_lists_test[l]), max_test_node_size):
            feature = np.array([0.0] * 768)
            features_test[l].append(feature)
        features_test[l] = sp.csr_matrix(features_test[l])

    i = 0
    id_density_dict = {}
    for l in train_list_dict:
        id_density_dict[l] = {}
        for obj in train_list_dict[l]["objects"]:
            id_density_dict[l][obj] = train_list_dict[l]["objects"][obj]["id"]
            i += 1
    # this dictionary used to transfer object id to text_density/text_number/char_density/char_number/visual_embedding/
    i = 0
    for l in test_list_dict:
        id_density_dict[l] = {}
        for obj in test_list_dict[l]["objects"]:
            id_density_dict[l][obj] = test_list_dict[l]["objects"][obj]["id"]
            i += 1

    features_train = {}
    for l in node_lists_train:
        features_train[l] = []
        for node in node_lists_train[l]:
            feature = np.array([0.0] * 1024)
            feature += np.array((id_density_dict[l][str(node)]))
            features_train[l].append(feature)
        for i in range(len(node_lists_train[l]), 1173):
            feature = np.array([0.0] * 1024)
            features_train[l].append(feature)
        features_train[l] = sp.csr_matrix(features_train[l])

    features_test = {}
    for l in node_lists_test:
        features_test[l] = []
        for node in node_lists_test[l]:
            feature = np.array([0.0] * 1024)
            feature += np.array((id_density_dict[l][str(node)]))
            features_test[l].append(feature)
        for i in range(len(node_lists_test[l]), 1173):
            feature = np.array([0.0] * 1024)
            features_test[l].append(feature)
        features_test[l] = sp.csr_matrix(features_test[l])

    # preprocess features
    for l in features_train:
        features_train[l] = preprocess_features(features_train[l])

    for l in features_test:
        features_test[l] = preprocess_features(features_test[l])

    num_class = 13
    y_train = {}
    train_mask = {}
    for f in new_train_list_dict:
        y_train[f] = np.array([[0] * num_class] * adj_train[f].shape[0])
        y_train[f] = np.array(labels_one_hot_train[f])
        train_mask[f] = [False] * adj_train[f].shape[0]
        train_mask[f][: num_obj_dict[f]] = [True] * num_obj_dict[f]

    y_val = {}
    val_mask = {}
    for f in new_test_list_dict:
        y_val[f] = np.array([[0] * num_class] * adj_test[f].shape[0])
        y_val[f] = np.array(labels_one_hot_test[f])
        val_mask[f] = [False] * adj_test[f].shape[0]
        val_mask[f][: num_obj_dict[f]] = [True] * num_obj_dict[f]

    # preprocess adjacency
    support_train = {}
    for f in adj_train:
        support_train[f] = [preprocess_adj(adj_train[f])]
    support_test = {}
    for f in adj_test:
        support_test[f] = [preprocess_adj(adj_test[f])]

    # just change the number of support gpu
    num_supports = 1
    tf.compat.v1.disable_eager_execution()
    # Define placeholders
    placeholders = {
        "support": [tf.sparse_placeholder(tf.float32) for _ in range(num_supports)],
        "features": tf.sparse_placeholder(tf.float32, shape=(13, 512)),
        "labels": tf.placeholder(tf.float32, shape=(None, 13)),
        "labels_mask": tf.placeholder(tf.int32),
        "dropout": tf.placeholder_with_default(0.5, shape=()),
        # helper variable for sparse dropout
        "num_features_nonzero": tf.placeholder(tf.int32),
    }

    # define input dimension which is same as node feature size
    model = GCN(placeholders, input_dim=1024, logging=True)

    logging.debug(model)

    # Initialize session
    session_conf = tf.ConfigProto(gpu_options=tf.GPUOptions(allow_growth=True))
    sess = tf.Session(config=session_conf)

    # Init variables
    sess.run(tf.global_variables_initializer())

    # Train model
    print("parent Child GCN training !!")
    for epoch in range(FLAGS.epochs):
        # Construct feed dictionary
        if epoch == FLAGS.epochs - 1:
            output_dic_train = {}
            output_dic_test = {}
            output_dic_train_level2 = {}
            output_dic_test_level2 = {}
        loss = 0
        output_dic_train = {}
        for f in features_train:
            feed_dict = construct_feed_dict(
                features_train[f],
                support_train[f],
                y_train[f],
                train_mask[f],
                placeholders,
            )
            feed_dict.update({placeholders["dropout"]: FLAGS.dropout})
            # print(feed_dict)

            # Training step
            outs = sess.run(
                [
                    model.opt_op,
                    model.loss,
                    model.accuracy,
                    model.layers[0].embedding,
                    model.layers[1].embedding,
                ],
                feed_dict=feed_dict,
            )
            loss += outs[1]
            # output_dic_train[str(f)] = outs[3]
        print(f"Training Loss : {loss}")
        logging.debug(f"Training Loss : {loss}")

    print("Optimization Finished!")

    model.save(sess)

    # Validation
    for f in features_train:
        cost, acc, pred, labels, emb1, emb2 = evaluate(
            sess,
            model,
            features_train[f],
            support_train[f],
            y_train[f],
            train_mask[f],
            placeholders,
        )
        print(emb1.shape)
        print(f"Train accuracy : {acc}")
        output_dic_train[f] = emb1
        output_dic_train_level2[f] = emb2

    for f in features_test:
        cost, acc, pred, labels, emb1, emb2 = evaluate(
            sess,
            model,
            features_test[f],
            support_test[f],
            y_val[f],
            val_mask[f],
            placeholders,
        )
        print(emb1.shape)
        print(f"Val accuracy : {acc}")
        output_dic_test[f] = emb1
        output_dic_test_level2[f] = emb2

    return (
        output_dic_train,
        output_dic_test,
        output_dic_train_level2,
        output_dic_test_level2,
    )


def glorot(shape, name=None):
    """Glorot & Bengio (AISTATS 2010) init."""
    init_range = np.sqrt(6.0 / (shape[0] + shape[1]))
    initial = tf.random_uniform(
        shape, minval=-init_range, maxval=init_range, dtype=tf.float32
    )
    return tf.Variable(initial, name=name)


def get_layer_uid(layer_name=""):
    """Helper function, assigns unique layer IDs."""
    if layer_name not in _LAYER_UIDS:
        _LAYER_UIDS[layer_name] = 1
        return 1
    else:
        _LAYER_UIDS[layer_name] += 1
        return _LAYER_UIDS[layer_name]


def sparse_dropout(x, keep_prob, noise_shape):
    """Dropout for sparse tensors."""
    random_tensor = keep_prob
    random_tensor += tf.random_uniform(noise_shape)
    dropout_mask = tf.cast(tf.floor(random_tensor), dtype=tf.bool)
    pre_out = tf.sparse_retain(x, dropout_mask)
    return pre_out * (1.0 / keep_prob)


def dot(x, y, sparse=False):
    """Wrapper for tf.matmul (sparse vs dense)."""
    if sparse:
        res = tf.sparse_tensor_dense_matmul(x, y)
    else:
        res = tf.matmul(x, y)
    return res


def masked_softmax_cross_entropy(preds, labels, mask):
    """Softmax cross-entropy loss with masking."""
    print(preds)
    print(labels)
    loss = tf.nn.softmax_cross_entropy_with_logits(logits=preds, labels=labels)
    mask = tf.cast(mask, dtype=tf.float32)
    mask /= tf.reduce_mean(mask)
    loss *= mask
    return tf.reduce_mean(loss)


def masked_accuracy(preds, labels, mask):
    """Accuracy with masking."""
    correct_prediction = tf.equal(tf.argmax(preds, 1), tf.argmax(labels, 1))

    accuracy_all = tf.cast(correct_prediction, tf.float32)
    mask = tf.cast(mask, dtype=tf.float32)
    mask /= tf.reduce_mean(mask)
    accuracy_all *= mask
    return tf.reduce_mean(accuracy_all)


class Layer(object):
    """Base layer class. Defines basic API for all layer objects.
    Implementation inspired by keras (http://keras.io).

    # Properties
        name: String, defines the variable scope of the layer.
        logging: Boolean, switches Tensorflow histogram logging on/off

    # Methods
        _call(inputs): Defines computation graph of layer
            (i.e. takes input, returns output)
        __call__(inputs): Wrapper for _call()
        _log_vars(): Log all variables
    """

    def __init__(self, **kwargs):
        allowed_kwargs = {"name", "logging"}
        for kwarg in kwargs.keys():
            assert kwarg in allowed_kwargs, "Invalid keyword argument: " + kwarg
        name = kwargs.get("name")
        if not name:
            layer = self.__class__.__name__.lower()
            name = layer + "_" + str(get_layer_uid(layer))
        self.name = name
        self.vars = {}
        logging = kwargs.get("logging", False)
        self.logging = logging
        self.sparse_inputs = False

    def _call(self, inputs):
        return inputs

    def __call__(self, inputs):
        with tf.name_scope(self.name):
            if self.logging and not self.sparse_inputs:
                tf.summary.histogram(self.name + "/inputs", inputs)
            outputs = self._call(inputs)
            if self.logging:
                tf.summary.histogram(self.name + "/outputs", outputs)
            return outputs

    def _log_vars(self):
        for var in self.vars:
            tf.summary.histogram(self.name + "/vars/" + var, self.vars[var])


class GraphConvolution(Layer):
    """Graph convolution layer."""

    def __init__(
        self,
        input_dim,
        output_dim,
        placeholders,
        dropout=0.0,
        sparse_inputs=False,
        act=tf.nn.relu,
        bias=False,
        featureless=False,
        **kwargs,
    ):
        super(GraphConvolution, self).__init__(**kwargs)

        if dropout:
            self.dropout = placeholders["dropout"]
        else:
            self.dropout = 0.0

        self.act = act
        self.support = placeholders["support"]
        self.sparse_inputs = sparse_inputs
        self.featureless = featureless
        self.bias = bias

        # helper variable for sparse dropout
        self.num_features_nonzero = placeholders["num_features_nonzero"]

        with tf.variable_scope(self.name + "_vars"):
            for i in range(len(self.support)):
                self.vars["weights_" + str(i)] = glorot(
                    [input_dim, output_dim], name="weights_" + str(i)
                )
            if self.bias:
                self.vars["bias"] = zeros([output_dim], name="bias")

        if self.logging:
            self._log_vars()

    def _call(self, inputs):
        x = inputs

        # dropout
        if self.sparse_inputs:
            x = sparse_dropout(x, 1 - self.dropout, self.num_features_nonzero)
        else:
            x = tf.nn.dropout(x, 1 - self.dropout)

        # convolve
        supports = list()
        for i in range(len(self.support)):
            if not self.featureless:
                pre_sup = dot(
                    x, self.vars["weights_" + str(i)], sparse=self.sparse_inputs
                )
            else:
                pre_sup = self.vars["weights_" + str(i)]
            support = dot(self.support[i], pre_sup, sparse=True)
            supports.append(support)
        output = tf.add_n(supports)

        # bias
        if self.bias:
            output += self.vars["bias"]

        self.embedding = output  # output
        return self.act(output)


class Model(object):
    def __init__(self, **kwargs):
        allowed_kwargs = {"name", "logging"}
        for kwarg in kwargs.keys():
            assert kwarg in allowed_kwargs, "Invalid keyword argument: " + kwarg
        name = kwargs.get("name")
        if not name:
            name = self.__class__.__name__.lower()
        self.name = name

        logging = kwargs.get("logging", False)
        self.logging = logging

        self.vars = {}
        self.placeholders = {}

        self.layers = []
        self.activations = []

        self.inputs = None
        self.outputs = None

        self.loss = 0
        self.accuracy = 0
        self.optimizer = None
        self.opt_op = None

    def _build(self):
        raise NotImplementedError

    def build(self):
        """Wrapper for _build()"""
        with tf.variable_scope(self.name):
            self._build()

        # Build sequential layer model
        self.activations.append(self.inputs)
        for layer in self.layers:
            hidden = layer(self.activations[-1])
            self.activations.append(hidden)
        self.outputs = self.activations[-1]

        # Store model variables for easy access
        variables = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=self.name)
        self.vars = {var.name: var for var in variables}

        # Build metrics
        self._loss()
        self._accuracy()

        self.opt_op = self.optimizer.minimize(self.loss)

    def predict(self):
        pass

    def _loss(self):
        raise NotImplementedError

    def _accuracy(self):
        raise NotImplementedError

    def save(self, sess=None):
        if not sess:
            raise AttributeError("TensorFlow session not provided.")
        saver = tf.train.Saver(self.vars)
        save_path = saver.save(sess, "models/saved_pc_model/%s.ckpt" % self.name)
        print("Model saved in file: %s" % save_path)

    def load(self, sess=None):
        if not sess:
            raise AttributeError("TensorFlow session not provided.")
        saver = tf.train.Saver(self.vars)
        save_path = "models/saved_pc_model/%s.ckpt" % self.name
        saver.restore(sess, save_path)
        print("Model restored from file: %s" % save_path)


class GCN(Model):
    def __init__(self, placeholders, input_dim, **kwargs):
        super(GCN, self).__init__(**kwargs)

        self.inputs = placeholders["features"]
        self.input_dim = input_dim
        # self.input_dim = self.inputs.get_shape().as_list()[1]  # To be supported in future Tensorflow versions
        self.output_dim = placeholders["labels"].get_shape().as_list()[1]
        self.placeholders = placeholders

        self.optimizer = tf.train.AdamOptimizer(learning_rate=FLAGS.learning_rate)

        self.build()

    def _loss(self):
        # Weight decay loss
        for var in self.layers[0].vars.values():
            self.loss += FLAGS.weight_decay * tf.nn.l2_loss(var)

        # Cross entropy error
        self.loss += masked_softmax_cross_entropy(
            self.outputs, self.placeholders["labels"], self.placeholders["labels_mask"]
        )

    def _accuracy(self):
        self.accuracy = masked_accuracy(
            self.outputs, self.placeholders["labels"], self.placeholders["labels_mask"]
        )
        self.pred = tf.argmax(self.outputs, 1)
        self.labels = tf.argmax(self.placeholders["labels"], 1)

    def _build(self):
        self.layers.append(
            GraphConvolution(
                input_dim=self.input_dim,
                output_dim=FLAGS.hidden1,
                placeholders=self.placeholders,
                act=tf.nn.relu,
                dropout=True,
                featureless=False,
                sparse_inputs=True,
                logging=self.logging,
            )
        )

        self.layers.append(
            GraphConvolution(
                input_dim=FLAGS.hidden1,
                output_dim=self.output_dim,
                placeholders=self.placeholders,
                act=lambda x: x,  #
                dropout=True,
                logging=self.logging,
            )
        )

    def predict(self):
        return tf.nn.softmax(self.outputs)


if __name__ == "__main__":
    # this dictionary used to transfer object id to text_density/text_number/char_density/char_number/visual_embedding/
    id_bert_dict = {}

    for l in train_list_dict:
        id_bert_dict[l] = {}
        for obj in train_list_dict[l]["objects"]:
            id_bert_dict[l][obj] = train_list_dict[l]["objects"][obj]["bert_large_emb"]

    for l in test_list_dict:
        id_bert_dict[l] = {}
        for obj in test_list_dict[l]["objects"]:
            id_bert_dict[l][obj] = test_list_dict[l]["objects"][obj]["bert_large_emb"]

    (
        new_train_list_dict,
        new_test_list_dict,
        list_dict_train,
        list_dict_test,
        num_obj_dict,
        labels_one_hot_train,
        labels_one_hot_test,
    ) = base_feature_extraction(train_list_dict, test_list_dict)
    (
        object_graph_dict_train,
        object_graph_dict_test,
        node_lists_train,
        node_lists_test,
        max_train_node_size,
        max_test_node_size,
    ) = build_gcn_graphs(
        new_train_list_dict, new_test_list_dict, list_dict_train, list_dict_test
    )

    (
        output_dic_train,
        output_dic_test,
        output_dic_train_level2,
        output_dic_test_level2,
    ) = build_gcn_model(
        object_graph_dict_train,
        object_graph_dict_test,
        max_train_node_size,
        max_test_node_size,
        num_obj_dict,
        labels_one_hot_train,
        labels_one_hot_test,
    )
    logging.debug(output_dic_train.keys())
    logging.debug(
        output_dic_train[
            "1.tar_1401.0001.gz_infoingames_without_metric_arxiv_0_ori"
        ].shape
    )
    logging.debug(output_dic_test.keys())
    # logging.debug(output_dic_test["195.tar_1610.03346.gz_hj_19_ori"].shape)
    output_dic_train_bert = output_dic_train
    output_dic_test_bert = output_dic_test

    for img in output_dic_train_bert:
        for i in tqdm(
            range(len(train_list_dict[img]["objects"].keys())),
            desc="Saving train distance features",
        ):
            logging.debug(len(output_dic_train_bert[img][i]))
            # logging.debug(output_dic_train_bert[img][i])
            train_list_dict[img]["objects"][str(i)][
                "parsing_level1"
            ] = output_dic_train_bert[img][i]

    for img in output_dic_test_bert:
        for i in tqdm(
            range(len(test_list_dict[img]["objects"].keys())),
            desc="Saving test distance features",
        ):
            logging.debug(len(output_dic_test_bert[img][i]))
            # logging.debug(output_dic_test_bert[img][i])
            test_list_dict[img]["objects"][str(i)][
                "parsing_level1"
            ] = output_dic_test_bert[img][i]

    for img in output_dic_train_level2:
        for i in tqdm(
            range(len(train_list_dict[img]["objects"].keys())),
            desc="Saving train distance features",
        ):
            logging.debug(len(output_dic_train_level2[img][i]))
            # logging.debug(output_dic_train_bert[img][i])
            train_list_dict[img]["objects"][str(i)][
                "parsing_level2"
            ] = output_dic_train_level2[img][i]

    for img in output_dic_test_level2:
        for i in tqdm(
            range(len(test_list_dict[img]["objects"].keys())),
            desc="Saving test distance features",
        ):
            logging.debug(len(output_dic_test_level2[img][i]))
            # logging.debug(output_dic_test_bert[img][i])
            test_list_dict[img]["objects"][str(i)][
                "parsing_level2"
            ] = output_dic_test_level2[img][i]

    with open(
        root_data_dir + "/pipe_placeholder/docbank_training_parent_child_features.pkl",
        "wb",
    ) as fp:
        pickle.dump(train_list_dict, fp)

    with open(
        root_data_dir + "/pipe_placeholder/docbank_testing_parent_child_features.pkl",
        "wb",
    ) as fp:
        pickle.dump(test_list_dict, fp)
