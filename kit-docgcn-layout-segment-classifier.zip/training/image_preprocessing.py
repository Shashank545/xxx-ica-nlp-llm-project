# IMPORTING Bottom-up Attention with Detectron2 - PYTORCH
import argparse
import json
import logging
import os

import cv2
import detectron2

# import some common libraries
import numpy as np
import pandas as pd
import torch
from detectron2.config import get_cfg

# import some common detectron2 utilities
from detectron2.engine import DefaultPredictor
from detectron2.structures.boxes import Boxes
from detectron2.structures.instances import Instances
from torch import nn
from tqdm import tqdm

logging.basicConfig(
    filename="training/app.log",
    level=logging.DEBUG,
    format="%(levelname)s:%(asctime)s:%(message)s",
)


TORCH_VERSION = ".".join(torch.__version__.split(".")[:2])
CUDA_VERSION = torch.__version__.split("+")[-1]
CV2_VERSION = cv2.__version__

logging.debug("Image Preprocessing pipeline running !!")
print("Torch version: ", TORCH_VERSION, "; CUDA version: ", CUDA_VERSION)
logging.debug(f"Torch version:  {TORCH_VERSION}, CUDA version: {CUDA_VERSION}")
print("Facebook's Detectron2 version:", detectron2.__version__)
logging.debug(f"Facebook's Detectron2 version: {detectron2.__version__}")
print("OpenCV2 version:", CV2_VERSION)
logging.debug(f"OpenCV2 version: {CV2_VERSION}")
# print(os.listdir(os.getcwd()))


cfg = get_cfg()
cfg.MODEL.RPN.POST_NMS_TOPK_TEST = 300
cfg.MODEL.ROI_HEADS.NMS_THRESH_TEST = 0.6
cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.2
cfg.MODEL.PROPOSAL_GENERATOR.HID_CHANNELS = -1
cfg.MODEL.ROI_BOX_HEAD.RES5HALVE = True
cfg.merge_from_file(
    "py-bottom-up-attention/configs/VG-Detection/faster_rcnn_R_101_C4_caffe.yaml"
)
cfg.MODEL.WEIGHTS = "http://nlp.cs.unc.edu/models/faster_rcnn_from_caffe.pkl"
cfg.MODEL.DEVICE = "cpu"
predictor = DefaultPredictor(cfg)


# Instantiate the parser
parser = argparse.ArgumentParser(
    description="Parser for command line arguments for image preprocessing"
)
# Required positional argument
parser.add_argument(
    "--dataset_type",
    type=str,
    dest="dataset_type",
    help="A flag to indentify type of selected dataset to PREPROCESS",
)

parser.add_argument(
    "--dataset_path",
    type=str,
    dest="dataset_path",
    help="root path to dataset being used for preprocessing",
)

parser.add_argument(
    "--train_size_limit",
    type=int,
    dest="tr_size_limit",
    help="number of train samples to consider",
)

parser.add_argument(
    "--test_size_limit",
    type=int,
    dest="te_size_limit",
    help="number of test samples to consider",
)

args = parser.parse_args()

print("Dataset path :", args.dataset_path)
print("Dataset type :", args.dataset_type)

root_data_dir = args.dataset_path
tr_size_limit = args.tr_size_limit if args.tr_size_limit else None
te_size_limit = args.te_size_limit if args.te_size_limit else None
txt_data_dir = root_data_dir + "/DocBank_500K_txt/"
json_data_dir = root_data_dir + "/DocBank_100K_json/"


# Converts txt formats of annotated files in Docbank to corresponding JSONs
def text_to_json():
    docbank_texts = sorted(os.listdir(txt_data_dir))
    print(len(docbank_texts))
    bbox_cols = ["x0", "y0", "x1", "y1"]

    for i, _file in tqdm(enumerate(docbank_texts), position=0, leave=True):
        # print(i, _file)
        sample_df = pd.read_csv(
            txt_data_dir + _file,
            sep="\t",
            on_bad_lines="skip",
            engine="python",
            names=["text", "x0", "y0", "x1", "y1", "r", "g", "b", "font_name", "label"],
        )

        sample_df["box"] = sample_df[bbox_cols].values.tolist()
        sample_dict = sample_df.to_dict(orient="records")
        with open(json_data_dir + _file[:-4] + ".json", "w") as foo:
            json.dump(sample_dict, foo, ensure_ascii=False, indent=2)


# Function to run image inferencing with pre-trained detectron2 RCNN model
def run_detectron(raw_image, raw_boxes):
    # Process Boxes
    raw_boxes = Boxes(torch.from_numpy(raw_boxes))
    # when using CUDA with Nvidia GPU
    # raw_boxes = Boxes(torch.from_numpy(raw_boxes).cuda())

    with torch.no_grad():
        raw_height, raw_width = raw_image.shape[:2]
        # print("Original image size: ", (raw_height, raw_width))
        logging.debug("Original image size: %r", (raw_height, raw_width))

        # Preprocessing image
        # image = predictor.transform_gen.get_transform(raw_image).apply_image(raw_image)
        image = predictor.aug.get_transform(raw_image).apply_image(raw_image)
        # print("Transformed image size: ", image.shape[:2])
        logging.debug("Transformed image size: %r", image.shape[:2])

        # Scale the box
        new_height, new_width = image.shape[:2]
        scale_x = 1.0 * new_width / raw_width
        scale_y = 1.0 * new_height / raw_height
        # print(scale_x, scale_y)
        boxes = raw_boxes.clone()
        boxes.scale(scale_x=scale_x, scale_y=scale_y)

        # ----
        image = torch.as_tensor(image.astype("float16").transpose(2, 0, 1))
        # when using CUDA with Nvidia GPU
        # image = torch.as_tensor(image.astype("float16").transpose(2, 0, 1)).cuda()
        inputs = [{"image": image, "height": raw_height, "width": raw_width}]
        images = predictor.model.preprocess_image(inputs)

        # Run Backbone Res1-Res4
        features = predictor.model.backbone(images.tensor)

        # Run RoI head for each proposal (RoI Pooling + Res5)
        proposal_boxes = [boxes]
        features = [features[f] for f in predictor.model.roi_heads.in_features]
        box_features = predictor.model.roi_heads._shared_roi_transform(
            features, proposal_boxes
        )
        feature_pooled = box_features.mean(dim=[2, 3])  # pooled to 1x1
        # print('Pooled features size:', feature_pooled.shape)
        logging.debug("Pooled features size: %r", feature_pooled.shape)

        # Predict classes and boxes for each proposal.
        (
            pred_class_logits,
            pred_proposal_deltas,
        ) = predictor.model.roi_heads.box_predictor(feature_pooled)
        # print(pred_class_logits.shape)
        logging.debug(pred_class_logits.shape)
        pred_class_prob = nn.functional.softmax(pred_class_logits, -1)
        pred_scores, pred_classes = pred_class_prob[..., :-1].max(-1)

        # Detectron2 Formatting (for visualization only)
        roi_features = feature_pooled
        instances = Instances(
            image_size=(raw_height, raw_width),
            pred_boxes=raw_boxes,
            scores=pred_scores,
            pred_classes=pred_classes,
        )
        return instances, roi_features


# Extracts image features based tensors using detectron2
def get_visual_features(root_data_dir):
    train_json_path = root_data_dir + "/docbank_training_data/annotations/"
    train_json_ls = sorted(os.listdir(train_json_path))
    train_image_path = root_data_dir + "/docbank_training_data/images/"
    train_image_ls = sorted(os.listdir(train_image_path))
    print(
        "# Training Annotations",
        len(train_json_ls),
        "\n# Training Images",
        len(train_image_ls),
    )
    logging.debug(
        f"# Training Annotations - {len(train_json_ls)}, # Training Images - {len(train_image_ls)}"
    )
    test_json_path = root_data_dir + "/docbank_testing_data/annotations/"
    test_json_ls = sorted(os.listdir(test_json_path))
    test_image_path = root_data_dir + "/docbank_testing_data/images/"
    test_image_ls = sorted(os.listdir(test_image_path))
    print(
        "# Testing Annotations",
        len(test_json_ls),
        "\n# Testing Images",
        len(test_image_ls),
    )
    logging.debug(
        f"# Testing Annotations - {len(test_json_ls)}, # Testing Images - {len(test_image_ls)}"
    )

    # get train image bounding boxes
    tr_img_bbox_list = {}
    te_img_bbox_list = {}
    for i, name in tqdm(
        enumerate(train_json_ls[:tr_size_limit]), desc="Train Bbox Iterations"
    ):
        tr_img_bbox_list[name[:-5]] = []
        path = train_json_path + name
        with open(path) as f:
            json_list = json.load(f)
        # json_list = json_list['form']
        for j in range(len(json_list)):
            tr_img_bbox_list[name[:-5]].append(json_list[j]["box"])
    # print(tr_img_bbox_list.keys())

    # get test image bounding boxes
    for i, name in tqdm(
        enumerate(test_json_ls[:te_size_limit]), desc="Test Bbox Iterations"
    ):
        te_img_bbox_list[name[:-5]] = []
        path = test_json_path + name
        with open(path) as f:
            json_list = json.load(f)
        # json_list = json_list['form']
        for j in range(len(json_list)):
            te_img_bbox_list[name[:-5]].append(json_list[j]["box"])
    # print(te_img_bbox_list.keys())

    if not os.path.isdir(root_data_dir + "/visual_features/object_train_pipe"):
        os.makedirs(root_data_dir + "/visual_features/object_train_pipe")

    if not os.path.isdir(root_data_dir + "/visual_features/object_test_pipe"):
        os.makedirs(root_data_dir + "/visual_features/object_test_pipe")

    # run detectron2 on train
    file_name_list = {}
    file_name_list["train"] = []
    print("\n\n")
    for i in tqdm(
        range(len(train_image_ls[:tr_size_limit])),
        position=0,
        leave=True,
        desc="Train Detectron Iterations",
    ):
        path = train_image_path + train_image_ls[i]
        im = cv2.imread(path)
        instances, features = run_detectron(
            im, np.array(tr_img_bbox_list[train_image_ls[i][:-8]])
        )
        visual_features = features.tolist()
        file_name = train_image_ls[i][:-4]
        file_name_list["train"].append(file_name)
        path = (
            root_data_dir + "/visual_features/object_train_pipe/" + file_name + ".json"
        )
        with open(path, "w") as file_object:
            json.dump(visual_features, file_object)

    print("\n\n")
    # run detectron2 on test
    file_name_list["test"] = []
    for i in tqdm(
        range(len(test_image_ls[:te_size_limit])),
        position=0,
        leave=True,
        desc="Test Detectron Iterations",
    ):
        path = test_image_path + test_image_ls[i]
        im = cv2.imread(path)
        instances, features = run_detectron(
            im, np.array(te_img_bbox_list[test_image_ls[i][:-8]])
        )
        visual_features = features.tolist()
        file_name = test_image_ls[i][:-4]
        file_name_list["test"].append(file_name)
        path = (
            root_data_dir + "/visual_features/object_test_pipe/" + file_name + ".json"
        )
        with open(path, "w") as file_object:
            json.dump(visual_features, file_object)


if __name__ == "__main__":
    # run only once for first time to convert data formats (DO NOT NEED TO RUN NOW)
    # text_to_json(args.dataset_path)

    # call to image preprocessing functions
    get_visual_features(root_data_dir)
