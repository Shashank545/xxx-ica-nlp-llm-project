import argparse
import json
import logging
import os
import pickle

import nltk
from PIL import Image
from tqdm import tqdm

nltk.download("punkt")

logging.basicConfig(
    filename="training/app.log",
    level=logging.DEBUG,
    format="%(levelname)s:%(asctime)s:%(message)s",
)

print(f"NLTK VERSION : {nltk.__version__}")
# Instantiate the parser
parser = argparse.ArgumentParser(
    description="Parser to generate scene relational graphs for FUNSD and Docbank"
)
# Required positional argument
parser.add_argument(
    "--dataset_type",
    type=str,
    dest="dataset_type",
    help="A flag to indentify the selected dataset to PREPROCESS",
)

parser.add_argument(
    "--dataset_path",
    type=str,
    dest="dataset_path",
    help="root path to dataset being used for scene graph preprocessing",
)

parser.add_argument(
    "--train_size_limit",
    type=int,
    dest="tr_size_limit",
    help="number of train samples to consider",
)

parser.add_argument(
    "--test_size_limit",
    type=int,
    dest="te_size_limit",
    help="number of test samples to consider",
)

args = parser.parse_args()
print("Dataset path :", args.dataset_path)
print("Dataset type :", args.dataset_type)

root_data_dir = args.dataset_path
tr_size_limit = args.tr_size_limit if args.tr_size_limit else None
te_size_limit = args.te_size_limit if args.te_size_limit else None


# number of characters / bounding box size
def char_density(obj):
    text = obj["text"]
    x1, y1, x2, y2 = obj["box"]
    size = abs(x2 - x1) * abs(y2 - y1)
    if size > 0:
        density = len(text) / size
    else:
        density = 0
    obj["char_density"] = density


# number of characters
def char_number(obj):
    text = obj["text"]
    char_num = len(text)
    obj["char_number"] = char_num


# number of tokens / bounding box size
def token_density(obj):
    text = obj["text"]
    # print(obj['box'])
    x1, y1, x2, y2 = obj["box"]
    tokenized_text = nltk.word_tokenize(text)
    size = abs(x2 - x1) * abs(y2 - y1)
    if size > 0:
        density = len(tokenized_text) / size
    else:
        density = 0
    obj["text_density"] = density


# number of tokens
def token_number(obj):
    text = obj["text"]
    tokenized_text = nltk.word_tokenize(text)
    token_num = len(tokenized_text)
    obj["text_number"] = token_num


# Manhattan distance
def manhanttan_distance(bbox1, bbox2):
    x1, y1, x12, y12 = bbox1
    x2, y2, x22, y22 = bbox2
    w1 = abs(x12 - x1)
    h1 = abs(y12 - y1)
    w2 = abs(x22 - x2)
    h2 = abs(y22 - y2)
    dist = abs(x2 - x1) + abs(y2 - y1)
    if x2 > x1 and abs(x2 - x1) > w1:
        dist = dist - w1
    elif x2 < x1 and abs(x2 - x1) > w2:
        dist = dist - w2
    elif y1 > y2 and abs(y1 - y2) > h2:
        dist = dist - h2
    elif y2 > y1 and abs(y1 - y2) > h1:
        dist = dist - h1
    return dist


# directly return the gap distance bewteen bounding boxes
def gap_distance(bbox1, bbox2):
    x1, y1, x12, y12 = bbox1
    x2, y2, x22, y22 = bbox2
    w1 = abs(x12 - x1)
    h1 = abs(y12 - y1)
    w2 = abs(x22 - x2)
    h2 = abs(y22 - y2)
    dist = 0
    if x2 > x1 and abs(x2 - x1) > w1:
        dist = abs(x2 - x1) - w1
    elif x2 < x1 and abs(x2 - x1) > w2:
        dist = abs(x2 - x1) - w2
    elif y1 > y2 and abs(y1 - y2) > h2:
        dist = abs(y2 - y1) - h2
    elif y2 > y1 and abs(y1 - y2) > h1:
        dist = abs(y2 - y1) - h1
    return dist


def enhance_features(train_list_dict, test_list_dict):
    for l in tqdm(train_list_dict, desc="Train Layout Gaps"):
        obj = train_list_dict[l]["objects"]
        for obj1 in obj:
            obj[obj1]["gap"] = {}
            for obj2 in obj:
                if obj1 != obj2:
                    dist = gap_distance(obj[obj1]["box"], obj[obj2]["box"])
                    obj[obj1]["gap"][obj2] = dist

    for l in tqdm(test_list_dict, desc="Test Layout Gaps"):
        obj = test_list_dict[l]["objects"]
        for obj1 in obj:
            obj[obj1]["gap"] = {}
            for obj2 in obj:
                if obj1 != obj2:
                    dist = gap_distance(obj[obj1]["box"], obj[obj2]["box"])
                    obj[obj1]["gap"][obj2] = dist

    for l in tqdm(train_list_dict, desc="Train Enhanced Features"):
        for obj in train_list_dict[l]["objects"]:
            # print(type(obj))
            if type(train_list_dict[l]["objects"][obj]["text"]) == str:
                token_density(train_list_dict[l]["objects"][obj])
                token_number(train_list_dict[l]["objects"][obj])
                char_density(train_list_dict[l]["objects"][obj])
                char_number(train_list_dict[l]["objects"][obj])

    for l in tqdm(test_list_dict, desc="Test Enhanced Features"):
        for obj in test_list_dict[l]["objects"]:
            if type(test_list_dict[l]["objects"][obj]["text"]) == str:
                token_density(test_list_dict[l]["objects"][obj])
                token_number(test_list_dict[l]["objects"][obj])
                char_density(test_list_dict[l]["objects"][obj])
                char_number(test_list_dict[l]["objects"][obj])

    return train_list_dict, test_list_dict


def docbank_scene_graph_generator(input_path, type, size_limit):
    # There are two types scene graphs one is position based global scene graph
    # Another one is document components structural relationship based binary scene graph
    # Type 1 means global relationship which will return reletively globally positional relationship
    # Type 2 will return binary structure or logical relationship between components

    json_path = input_path + "/annotations/"
    img_path = input_path + "/images"
    img_list = sorted(os.listdir(img_path))
    # for training dataset bbox_id = 0 setting this to order all trainind and validation dataset
    # bbox_id = 7412
    bbox_id = 0
    relation_id = 0
    bi_relation = 8473
    scene_graph = {}

    for index in tqdm(
        range(len(img_list[:size_limit])), desc="Scene Graph relation generation"
    ):
        # print(index, name)
        name = img_list[index][:-4]
        image = Image.open(img_path + "/" + name + ".jpg")
        info_path = json_path + name[:-4] + ".json"
        with open(info_path) as f:
            info_list = json.load(f)
            # info_list = info_list['form']
        scene_graph[name] = {}
        scene_graph[name]["file_name"] = name
        scene_graph[name]["width"] = image.size[0]
        scene_graph[name]["height"] = image.size[1]
        scene_graph[name]["objects"] = {}
        for i in tqdm(range(len(info_list))):
            scene_graph[name]["objects"][str(i)] = {}
            scene_graph[name]["objects"][str(i)]["id"] = bbox_id
            bbox_id += 1
            scene_graph[name]["objects"][str(i)]["box"] = info_list[i]["box"]
            scene_graph[name]["objects"][str(i)]["category"] = info_list[i]["label"]
            scene_graph[name]["objects"][str(i)]["text"] = info_list[i]["text"]
            scene_graph[name]["objects"][str(i)]["relations"] = {}

        # returning scene graph is position based global scene graph
        if type == 1:
            for i in scene_graph[name]["objects"]:
                current_box = scene_graph[name]["objects"][i]
                box1 = current_box["box"]
                c_relation = 0
                for j in scene_graph[name]["objects"]:
                    if i != j:
                        box2 = scene_graph[name]["objects"][j]["box"]
                        current_box["relations"][str(c_relation)] = {}
                        current_box["relations"][str(c_relation)]["id"] = relation_id
                        current_box["relations"][str(c_relation)][
                            "object"
                        ] = scene_graph[name]["objects"][j]["id"]
                        # be cautious of ignoring this
                        # current_box['relations'][str(c_relation)]['name'] = relative_position(box1,box2)
                        relation_id += 1
                        c_relation += 1

        # type 0 will return binary relationships between bounding box
        # for funsd dataset, it will represent the question and corresponding answer relationships
        # if current node is a question, the relation will be annotated as 'answer' to its answer
        # if current node is a answer, the relation will be annotated as 'question'
        elif type == 0:
            for i in scene_graph[name]["objects"]:
                current_box = scene_graph[name]["objects"][i]
                k = int(i)
                if len(info_list[k]["linking"]) != 0:
                    for n in range(len(info_list[k]["linking"])):
                        linking_node = info_list[k]["linking"][n]
                        current_box["relations"][str(n)] = {}
                        node1 = linking_node[0]
                        node2 = linking_node[1]
                        if node1 == k:
                            current_box["relations"][str(n)]["name"] = info_list[node2][
                                "label"
                            ]
                            current_box["relations"][str(n)]["id"] = bi_relation
                            current_box["relations"][str(n)]["object"] = scene_graph[
                                name
                            ]["objects"][str(node2)]["id"]
                            bi_relation += 1
                        elif node2 == k:
                            current_box["relations"][str(n)]["name"] = info_list[node1][
                                "label"
                            ]
                            current_box["relations"][str(n)]["id"] = bi_relation
                            current_box["relations"][str(n)]["object"] = scene_graph[
                                name
                            ]["objects"][str(node1)]["id"]
                            bi_relation += 1

    if type == 1:
        return scene_graph
    if type == 0:
        print(bbox_id, bi_relation)
        return scene_graph


if __name__ == "__main__":
    logging.debug("Docbank scene graph generation started....")

    if not os.path.isdir(root_data_dir + "/pipe_placeholder"):
        os.makedirs(root_data_dir + "/pipe_placeholder")

    train_scenegraph_positional = docbank_scene_graph_generator(
        root_data_dir + "/docbank_training_data", 1, tr_size_limit
    )
    with open(
        root_data_dir
        + "/pipe_placeholder/docbank_full_feature_sg_train_positional_1.json",
        "w",
    ) as fp:
        json.dump(train_scenegraph_positional, fp, ensure_ascii=False, indent=2)

    test_scenegraph_positional = docbank_scene_graph_generator(
        root_data_dir + "/docbank_testing_data", 1, te_size_limit
    )
    with open(
        root_data_dir
        + "/pipe_placeholder/docbank_full_feature_sg_test_positional_1.json",
        "w",
    ) as fp:
        json.dump(test_scenegraph_positional, fp, ensure_ascii=False, indent=2)
    logging.debug("Docbank scene graph generation completed !!!")

    train_list_dict, test_list_dict = enhance_features(
        train_scenegraph_positional, test_scenegraph_positional
    )

    with open(
        root_data_dir + "/pipe_placeholder/docbank_full_feature_sg_train_v4.json", "w"
    ) as fp:
        json.dump(train_list_dict, fp, ensure_ascii=False, indent=2)

    with open(
        root_data_dir + "/pipe_placeholder/docbank_full_feature_sg_test_v4.json", "w"
    ) as fp:
        json.dump(test_list_dict, fp, ensure_ascii=False, indent=2)

    with open(
        root_data_dir + "/textual_features/docbank_train_bert_cls_emb_v2.pkl", "rb"
    ) as f:
        train_features = pickle.load(f)

    with open(
        root_data_dir + "/textual_features/docbank_test_bert_cls_emb_v2.pkl", "rb"
    ) as f:
        test_features = pickle.load(f)

    for l in train_scenegraph_positional:
        for i, obj in enumerate(train_scenegraph_positional[l]["objects"]):
            train_scenegraph_positional[l]["objects"][obj][
                "bert_large_emb"
            ] = train_features[i]

    for l in test_scenegraph_positional:
        for i, obj in enumerate(test_scenegraph_positional[l]["objects"]):
            test_scenegraph_positional[l]["objects"][obj][
                "bert_large_emb"
            ] = test_features[i]

    with open(
        root_data_dir
        + "/pipe_placeholder/docbank_full_feature_sg_train_positional_1_edited.json",
        "w",
    ) as fp:
        json.dump(train_scenegraph_positional, fp, ensure_ascii=False, indent=2)

    with open(
        root_data_dir
        + "/pipe_placeholder/docbank_full_feature_sg_test_positional_1_edited.json",
        "w",
    ) as fp:
        json.dump(test_scenegraph_positional, fp, ensure_ascii=False, indent=2)
