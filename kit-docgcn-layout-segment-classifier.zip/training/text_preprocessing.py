# Importing the BERT based libraries for textual feature extraction
import argparse
import json
import logging
import os
import pickle

import pandas as pd
import torch
from sklearn.preprocessing import LabelEncoder
from torch import cuda
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm
from transformers import AutoModel, BertTokenizer

logging.basicConfig(
    filename="training/app.log",
    level=logging.DEBUG,
    format="%(levelname)s:%(asctime)s:%(message)s",
)
logging.debug("Text Preprocessing pipeline running !!")


os.environ["CURL_CA_BUNDLE"] = ""

device = "cuda" if cuda.is_available() else "cpu"
print(device)

# Defining some key variables that will be used later on in the training
MAX_LEN = 100
TRAIN_BATCH_SIZE = 16
VALID_BATCH_SIZE = TRAIN_BATCH_SIZE * 2
# EPOCHS = 1
LEARNING_RATE = 2e-05
# Change the pre-trained bert model
tokenizer = BertTokenizer.from_pretrained("./models/bert-base-tokenizer")
# tokenizer = BertTokenizer.from_pretrained('roberta-base') #Cased


# Instantiate the parser
parser = argparse.ArgumentParser(
    description="Parser for command line arguments for text preprocessing"
)
# Required positional argument
parser.add_argument(
    "--dataset_type",
    type=str,
    dest="dataset_type",
    help="A flag to indentify type of  selected dataset to PREPROCESS",
)

parser.add_argument(
    "--dataset_path",
    type=str,
    dest="dataset_path",
    help="root path to dataset being used for preprocessing",
)

parser.add_argument(
    "--train_size_limit",
    type=int,
    dest="tr_size_limit",
    help="number of train samples to consider",
)

parser.add_argument(
    "--test_size_limit",
    type=int,
    dest="te_size_limit",
    help="number of test samples to consider",
)

args = parser.parse_args()
print("Dataset path :", args.dataset_path)
print("Dataset type :", args.dataset_type)

root_data_dir = args.dataset_path
tr_size_limit = args.tr_size_limit if args.tr_size_limit else None
te_size_limit = args.te_size_limit if args.te_size_limit else None


class SentimentData(Dataset):
    def __init__(self, dataframe, tokenizer, max_len):
        self.tokenizer = tokenizer
        self.data = dataframe
        self.text = dataframe.text
        self.targets = self.data.label
        self.max_len = max_len

    def __len__(self):
        return len(self.text)

    def __getitem__(self, index):
        text = str(self.text[index])
        text = " ".join(text.split())

        inputs = self.tokenizer.encode_plus(
            text,
            None,
            add_special_tokens=True,
            max_length=self.max_len,
            pad_to_max_length=True,
            return_token_type_ids=True,
            truncation=True,
        )
        ids = inputs["input_ids"]
        mask = inputs["attention_mask"]
        token_type_ids = inputs["token_type_ids"]

        return {
            "ids": torch.tensor(ids, dtype=torch.long),
            "mask": torch.tensor(mask, dtype=torch.long),
            "token_type_ids": torch.tensor(token_type_ids, dtype=torch.long),
            "targets": torch.tensor(self.targets[index], dtype=torch.float),
        }


class Feature_Extractor(torch.nn.Module):
    def __init__(self):
        super(Feature_Extractor, self).__init__()
        # bert-base-cased - 768 Dimensions
        # bert-large-cased bert-large-uncased - 1024 Dimensions
        # roberta-base-cased - 768 Dimensions
        # biobert
        # BERT large

        self.l1 = AutoModel.from_pretrained("./models/bert-base-uncased")
        self.pre_classifier = torch.nn.Linear(768, 768)

    def forward(self, input_ids, attention_mask, token_type_ids):
        output_1 = self.l1(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )
        hidden_state = output_1[0]
        pooler = hidden_state[:, 0]

        return pooler


def text_preprocessing(root_data_dir):
    train_file_path = root_data_dir + "/docbank_training_data/annotations/"
    test_file_path = root_data_dir + "/docbank_testing_data/annotations/"
    train_file_list = sorted(os.listdir(train_file_path))
    test_file_list = sorted(os.listdir(test_file_path))
    print(len(train_file_list), len(test_file_list))
    training_list, test_list = ([], [])

    for i in tqdm(train_file_list[:tr_size_limit], desc="Train Annotations"):
        path = train_file_path + i
        with open(path) as f:
            d = json.load(f)
            for x in d:
                training_list.append(x)
    print(f"Training items total : {len(training_list)}")

    for j in tqdm(test_file_list[:te_size_limit], desc="Test Annotations"):
        path = test_file_path + j
        with open(path) as f:
            d = json.load(f)
            for x in d:
                test_list.append(x)
    print(f"Testing items total: {len(test_list)}")

    df_train = pd.DataFrame(training_list)
    logging.debug("Train label value counts: %s", df_train.label.value_counts())
    logging.debug(f"Train shape: {df_train.shape}")
    df_test = pd.DataFrame(test_list)
    logging.debug("Test label value counts: %s", df_test.label.value_counts())
    logging.debug(f"Test shape: {df_test.shape}")
    labelencoder = LabelEncoder()
    df_train["label"] = labelencoder.fit_transform(df_train["label"])
    df_test["label"] = labelencoder.fit_transform(df_test["label"])

    train_size = 1
    train_data = df_train.sample(frac=train_size, random_state=200)
    train_data = train_data.reset_index(drop=True)

    test_size = 1
    test_data = df_test.sample(frac=test_size, random_state=200)
    test_data = test_data.reset_index(drop=True)

    print("FULL Dataset: {}".format(pd.concat([df_train, df_test], axis=0).shape))
    print("TRAIN Dataset: {}".format(train_data.shape))
    print("TEST Dataset: {}".format(test_data.shape))

    training_set = SentimentData(train_data, tokenizer, MAX_LEN)
    test_set = SentimentData(test_data, tokenizer, MAX_LEN)

    train_params = {"batch_size": TRAIN_BATCH_SIZE, "shuffle": False, "num_workers": 0}
    training_loader = DataLoader(training_set, **train_params)
    test_params = {"batch_size": VALID_BATCH_SIZE, "shuffle": False, "num_workers": 0}
    testing_loader = DataLoader(test_set, **test_params)
    model = Feature_Extractor()
    model.to(device)  #
    print(f"Train DLA Components in batched dataloaders : {len(training_loader)}")
    logging.debug(
        f"Train DLA Components in batched dataloaders : {len(training_loader)}"
    )
    print(f"Test DLA Components in batched dataloaders : {len(testing_loader)}")
    logging.debug(f"Test DLA Components in batched dataloaders : {len(testing_loader)}")
    train_features = get_textual_features(
        model, training_loader, "Train set embeddings with Pre-trained BERT Encoders :"
    )
    test_features = get_textual_features(
        model, testing_loader, "Test set embeddings with Pre-trained BERT Encoders :"
    )

    if not os.path.isdir(root_data_dir + "/textual_features"):
        os.makedirs(root_data_dir + "/textual_features")

    with open(
        root_data_dir + "/textual_features/docbank_train_bert_cls_emb_v2.pkl", "wb"
    ) as f:
        pickle.dump(train_features, f)

    with open(
        root_data_dir + "/textual_features/docbank_test_bert_cls_emb_v2.pkl", "wb"
    ) as f:
        pickle.dump(test_features, f)

    logging.debug(f"Torch version : {torch.__version__}")
    torch.save(model, "./models/docbank_bert_text_embedder_v0.pt")
    torch.save(
        model.state_dict(), "./models/docbank_bert_text_embedder_state_dict_v0.pt"
    )


def get_textual_features(model, data_loader, mode):
    output = []
    model.eval()
    for _, data in tqdm(enumerate(data_loader, 0), desc=mode):
        ids = data["ids"].to(device, dtype=torch.long)
        mask = data["mask"].to(device, dtype=torch.long)
        token_type_ids = data["token_type_ids"].to(device, dtype=torch.long)
        targets = data["targets"].to(device, dtype=torch.long)
        outputs = model(ids, mask, token_type_ids)
        output.extend(outputs.tolist())
    return output


if __name__ == "__main__":
    # call to text preprocessing functions
    text_preprocessing(root_data_dir)
