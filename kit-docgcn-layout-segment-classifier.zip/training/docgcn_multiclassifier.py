# Importing the libraries needed
import argparse
import itertools
import json

# from transformers.configuration_bert import BertConfig
import logging
import os
import pickle

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# import seaborn as sns
import torch
from pandas import DataFrame
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
from torch import cuda
from torch.utils.data import DataLoader, Dataset
from torch.utils.tensorboard import SummaryWriter

# from torcheval.metrics.functional import multiclass_f1_score
from tqdm import tqdm
from transformers import AutoModel, BertTokenizer

logging.basicConfig(
    filename="training/app.log",
    level=logging.DEBUG,
    format="%(levelname)s:%(asctime)s:%(message)s",
)

# Instantiate the parser
parser = argparse.ArgumentParser(
    description="Parser to generate distance based GCN graphs for FUNSD and Docbank"
)
# Required positional argument
parser.add_argument(
    "--dataset_type",
    type=str,
    dest="dataset_type",
    help="A flag to indentify the selected dataset to PREPROCESS",
)

parser.add_argument(
    "--dataset_path",
    type=str,
    dest="dataset_path",
    help="root path to dataset being used for preprocessing",
)

parser.add_argument(
    "--train_size_limit",
    type=int,
    dest="tr_size_limit",
    help="number of train samples to consider",
)

parser.add_argument(
    "--test_size_limit",
    type=int,
    dest="te_size_limit",
    help="number of test samples to consider",
)

integer_mapping = {}
cols_left, cols_right = ([], [])

args = parser.parse_args()
print("Dataset path :", args.dataset_path)
print("Dataset type :", args.dataset_type)
root_data_dir = args.dataset_path
tr_size_limit = args.tr_size_limit if args.tr_size_limit else None
te_size_limit = args.te_size_limit if args.te_size_limit else None
model_reports_path = "./models/docgcn_reports"


# root_data_dir = "../kit-docgcn-dla-service/docbank_data"
device = "cuda" if cuda.is_available() else "cpu"
logging.debug(device)

# tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
tokenizer = BertTokenizer.from_pretrained(
    "models/bert-base-tokenizer", local_files_only=True
)
# Defining some key variables that will be used later on in the training
MAX_LEN = 100
TRAIN_BATCH_SIZE = 1
VALID_BATCH_SIZE = 1
TEST_BATCH_SIZE = 1
EPOCHS = 5
LEARNING_RATE = 2e-05
# Change the pre-trained bert model
# tokenizer = BertTokenizer.from_pretrained('roberta-base') #Cased


class SentimentData(Dataset):
    def __init__(self, dataframe, tokenizer, max_len):
        self.tokenizer = tokenizer
        self.data = dataframe
        self.text = dataframe.text
        self.targets = self.data.label
        self.gcn_visual_feature = dataframe.near_visual_feature
        self.visual_feature = dataframe.visual_feature
        self.gcn_bert_base = dataframe.gcn_bert_predicted
        self.parsing1 = dataframe.level1_parse_emb
        self.parsing2 = dataframe.level2_parse_emb
        self.char_density = dataframe.gcn_near_char_density
        self.char_number = dataframe.gcn_near_char_number
        self.density = dataframe.density
        self.max_len = max_len

    def __len__(self):
        return len(self.text)

    def __getitem__(self, index):
        text = str(self.text[index])
        text = " ".join(text.split())

        inputs = self.tokenizer.encode_plus(
            text,
            None,
            add_special_tokens=True,
            max_length=self.max_len,
            pad_to_max_length=True,
            return_token_type_ids=True,
        )
        ids = inputs["input_ids"]
        mask = inputs["attention_mask"]
        token_type_ids = inputs["token_type_ids"]

        return {
            "ids": torch.tensor(ids, dtype=torch.long),
            "mask": torch.tensor(mask, dtype=torch.long),
            "token_type_ids": torch.tensor(token_type_ids, dtype=torch.long),
            "targets": torch.tensor(self.targets[index], dtype=torch.float),
            "density": torch.tensor(self.density[index], dtype=torch.float),
            "gcn_bert_base": torch.tensor(self.gcn_bert_base[index], dtype=torch.float),
            "char_density": torch.tensor(self.char_density[index], dtype=torch.float),
            "char_number": torch.tensor(self.char_number[index], dtype=torch.float),
            "visual_feature": torch.tensor(
                self.visual_feature[index], dtype=torch.float
            ),
            "parsing1": torch.tensor(self.parsing1[index], dtype=torch.float),
            "parsing2": torch.tensor(self.parsing2[index], dtype=torch.float),
            "gcn_visual_feature": torch.tensor(
                self.gcn_visual_feature[index], dtype=torch.float
            ),
        }


class RobertaClass(torch.nn.Module):
    def __init__(self):
        super(RobertaClass, self).__init__()
        # bert-base-cased 768
        # bert-large-cased bert-large-uncased 1024
        # roberta-base-cased 768
        # biobert

        self.l1 = AutoModel.from_pretrained("bert-base-uncased")  # BERT large
        self.pre_classifier = torch.nn.Linear(768, 768)
        self.dropout = torch.nn.Dropout(0.1)
        self.hidden_cls = torch.nn.Linear(768, 768)
        self.hidden_parsing = torch.nn.Linear(1024, 768)
        self.hidden_den = torch.nn.Linear(768, 768)
        self.hidden_vis = torch.nn.Linear(768, 768)
        self.hidden_vis_pro = torch.nn.Linear(2048, 768)
        self.hidden_all = torch.nn.Linear(2304, 768 * 2)
        self.before_classifier = torch.nn.Linear(768 * 2, 128)
        self.pooling = torch.nn.MaxPool2d((2, 1), stride=None)
        self.classifier = torch.nn.Linear(128, 13)

    def forward(
        self,
        input_ids,
        attention_mask,
        token_type_ids,
        char_density,
        char_number,
        visual_feature,
        bert_cls,
        parsing1,
        parsing2,
        visual,
    ):
        output_1 = self.l1(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )
        hidden_state = output_1[0]
        pooler = hidden_state[:, 0]

        # BERT 768 BERT / large 1024

        # set different hidden layer, number of hidden units, regularization methods including bn and dropout

        pooler = self.pre_classifier(pooler)
        pooler = torch.nn.Tanh()(pooler)
        pooler = self.dropout(pooler)

        # density = torch.cat((char_density.unsqueeze(1),char_number.unsqueeze(1)),1)
        # density = self.pooling(density).squeeze(1)
        # density = self.hidden(density)
        # density = torch.nn.Tanh()(density)
        # density = self.dropout(density)

        parsing = torch.cat((parsing1.unsqueeze(1), parsing2.unsqueeze(1)), 1)
        parsing = self.pooling(parsing).squeeze(1)
        parsing = self.hidden_parsing(parsing)
        parsing = torch.nn.Tanh()(parsing)
        parsing = self.dropout(parsing)

        pooler = torch.cat((pooler.unsqueeze(1), bert_cls.unsqueeze(1)), 1)
        pooler = self.pooling(pooler).squeeze(1)
        pooler = self.hidden_cls(pooler)
        pooler = torch.nn.Tanh()(pooler)
        pooler = self.dropout(pooler)

        visual = self.hidden_vis_pro(visual)
        visual = torch.nn.Tanh()(visual)
        visual = self.dropout(visual)

        visual = torch.cat((visual.unsqueeze(1), visual_feature.unsqueeze(1)), 1)
        visual = self.pooling(visual).squeeze(1)
        visual = self.hidden_vis(visual)
        visual = torch.nn.Tanh()(visual)
        visual = self.dropout(visual)

        pooler = torch.cat((pooler, visual, parsing), 1)
        pooler = self.hidden_all(pooler)
        pooler = torch.nn.Tanh()(pooler)
        pooler = self.dropout(pooler)

        pooler = self.before_classifier(pooler)
        pooler = torch.nn.Tanh()(pooler)
        pooler = self.dropout(pooler)

        output = self.classifier(pooler)
        return output


class SentimentData_test(Dataset):
    def __init__(self, dataframe, tokenizer, max_len):
        self.tokenizer = tokenizer
        self.data = dataframe
        self.text = dataframe.text
        self.max_len = max_len
        self.visual_feature = dataframe.near_visual_feature
        self.gcn_bert_base = dataframe.gcn_bert_predicted
        self.parsing1 = dataframe.level1_parse_emb
        self.parsing2 = dataframe.level2_parse_emb
        self.char_density = dataframe.gcn_near_char_density
        self.char_number = dataframe.gcn_near_char_number
        # self.pos_emb = dataframe.gcn_pos_emb
        self.visual = dataframe.visual_feature

    def __len__(self):
        return len(self.text)

    def __getitem__(self, index):
        text = str(self.text[index])
        text = " ".join(text.split())

        inputs = self.tokenizer.encode_plus(
            text,
            None,
            add_special_tokens=True,
            max_length=self.max_len,
            pad_to_max_length=True,
            return_token_type_ids=True,
        )
        ids = inputs["input_ids"]
        mask = inputs["attention_mask"]
        token_type_ids = inputs["token_type_ids"]

        return {
            "ids": torch.tensor(ids, dtype=torch.long),
            "mask": torch.tensor(mask, dtype=torch.long),
            "token_type_ids": torch.tensor(token_type_ids, dtype=torch.long),
            "gcn_bert_base": torch.tensor(self.gcn_bert_base[index], dtype=torch.float),
            "char_density": torch.tensor(self.char_density[index], dtype=torch.float),
            "char_number": torch.tensor(self.char_number[index], dtype=torch.float),
            "visual_feature": torch.tensor(
                self.visual_feature[index], dtype=torch.float
            ),
            "parsing1": torch.tensor(self.parsing1[index], dtype=torch.float),
            "parsing2": torch.tensor(self.parsing2[index], dtype=torch.float),
            # 'pos_emb': torch.tensor(self.pos_emb[index],dtype=torch.float),
            "visual": torch.tensor(self.visual[index], dtype=torch.float),
        }


def feature_aggregation(root_data_dir):
    # import parent child gcn graphs
    with open(
        root_data_dir + "/pipe_placeholder/docbank_training_parent_child_features.pkl",
        "rb",
    ) as fp:
        train_pc_dict = pickle.load(fp)

    with open(
        root_data_dir + "/pipe_placeholder/docbank_testing_parent_child_features.pkl",
        "rb",
    ) as fp:
        test_pc_dict = pickle.load(fp)

    logging.debug(
        len(
            train_pc_dict["1.tar_1401.0001.gz_infoingames_without_metric_arxiv_0_ori"][
                "objects"
            ]["0"]["bert_large_emb"]
        )
    )

    logging.debug(
        len(
            train_pc_dict["1.tar_1401.0001.gz_infoingames_without_metric_arxiv_0_ori"][
                "objects"
            ]["0"]["parsing_level1"]
        )
    )

    logging.debug(
        len(
            train_pc_dict["1.tar_1401.0001.gz_infoingames_without_metric_arxiv_0_ori"][
                "objects"
            ]["0"]["parsing_level2"]
        )
    )

    # import distance weighted gcn graphs
    with open(
        root_data_dir
        + "/pipe_placeholder/docbank_training_distance_weighted_features.pkl",
        "rb",
    ) as fp:
        train_dw_dict = pickle.load(fp)

    with open(
        root_data_dir
        + "/pipe_placeholder/docbank_testing_distance_weighted_features.pkl",
        "rb",
    ) as fp:
        test_dw_dict = pickle.load(fp)

    # import visual features
    img_ls = sorted(os.listdir(root_data_dir + "/docbank_training_data/images"))
    visual_features_train_list = []
    for i in range(len(img_ls[:tr_size_limit])):
        file_name = img_ls[i][:-4]
        path = (
            root_data_dir + "/visual_features/object_train_pipe/" + file_name + ".json"
        )
        # logging.debug(path)
        with open(path, "r") as file_object:
            visual_features = json.load(file_object)
            visual_features_train_list.append(visual_features)

    # logging.debug(len(visual_features_train_list))
    # logging.debug(len(visual_features_train_list[1][0]))

    img_ls = sorted(os.listdir(root_data_dir + "/docbank_testing_data/images"))
    visual_features_test_list = []
    for i in range(len(img_ls[:te_size_limit])):
        file_name = img_ls[i][:-4]
        path = (
            root_data_dir + "/visual_features/object_test_pipe/" + file_name + ".json"
        )
        # logging.debug(path)
        with open(path, "r") as file_object:
            visual_features = json.load(file_object)
            visual_features_test_list.append(visual_features)

    # logging.debug(len(visual_features_test_list))
    # logging.debug(len(visual_features_test_list[1][0]))

    for k, p in enumerate(train_dw_dict):
        for i, j in enumerate(train_dw_dict[p]["objects"]):
            train_dw_dict[p]["objects"][j][
                "visual_embeddings"
            ] = visual_features_train_list[k][i]

    logging.debug(
        train_dw_dict["1.tar_1401.0001.gz_infoingames_without_metric_arxiv_0_ori"][
            "objects"
        ]["0"].keys()
    )
    len(
        train_dw_dict["1.tar_1401.0001.gz_infoingames_without_metric_arxiv_0_ori"][
            "objects"
        ]["0"]["visual_embeddings"]
    )

    for k, p in enumerate(test_dw_dict):
        for i, j in enumerate(test_dw_dict[p]["objects"]):
            test_dw_dict[p]["objects"][j][
                "visual_embeddings"
            ] = visual_features_test_list[k][i]

    logging.debug(
        test_dw_dict["195.tar_1610.03346.gz_hj_19_ori"]["objects"]["0"].keys()
    )
    logging.debug(
        len(
            test_dw_dict["195.tar_1610.03346.gz_hj_19_ori"]["objects"]["0"][
                "visual_embeddings"
            ]
        )
    )

    training_dw_list = []
    for file in train_dw_dict:
        for x in train_dw_dict[file]["objects"]:
            training_dw_list.append(train_dw_dict[file]["objects"][x])
    logging.debug(len(training_dw_list))

    testing_dw_list = []
    for file in test_dw_dict:
        for x in test_dw_dict[file]["objects"]:
            testing_dw_list.append(test_dw_dict[file]["objects"][x])
    logging.debug(len(testing_dw_list))

    training_pc_list = []
    for file in train_pc_dict:
        for x in train_pc_dict[file]["objects"]:
            training_pc_list.append(train_pc_dict[file]["objects"][x])
    logging.debug(len(training_pc_list))

    testing_pc_list = []
    for file in test_pc_dict:
        for x in test_pc_dict[file]["objects"]:
            testing_pc_list.append(test_pc_dict[file]["objects"][x])
    len(testing_pc_list)

    df_dw_train = DataFrame(training_dw_list)
    df_dw_test = DataFrame(testing_dw_list)
    df_pc_train = DataFrame(training_pc_list)
    df_pc_test = DataFrame(testing_pc_list)

    logging.debug(
        f"Train DW Shape :{df_dw_train.shape}, Train PC Shape : {df_pc_train.shape}"
    )
    logging.debug(
        f"Train DW Shape :{df_dw_test.shape}, Train PC Shape : {df_pc_test.shape}"
    )

    df_train = pd.merge(
        df_dw_train,
        df_pc_train[["id", "bert_large_emb", "parsing_level1", "parsing_level2"]],
        on=["id", "id"],
        how="left",
    )

    df_test = pd.merge(
        df_dw_test,
        df_pc_test[["id", "bert_large_emb", "parsing_level1", "parsing_level2"]],
        on=["id", "id"],
        how="left",
    )

    parsing_paddings = [0] * 1011
    df_train["parsing_level2"] = df_train["parsing_level2"].apply(
        lambda x: np.append(x, [parsing_paddings])
    )
    df_test["parsing_level2"] = df_test["parsing_level2"].apply(
        lambda x: np.append(x, [parsing_paddings])
    )

    labelencoder = LabelEncoder()

    df_train["label"] = labelencoder.fit_transform(df_train["category"])
    df_test["label"] = labelencoder.fit_transform(df_test["category"])

    global integer_mapping
    # integer_mapping = {l: i for i, l in enumerate(labelencoder.classes_)}
    integer_mapping = {
        0: "abstract",
        1: "author",
        2: "caption",
        3: "date",
        4: "equation",
        5: "figure",
        6: "footer",
        7: "paragraph",
        8: "reference",
        9: "section",
        10: "title",
        11: "list",
        12: "table",
    }

    logging.debug(integer_mapping.keys())

    new_df_train = DataFrame()
    new_df_test = DataFrame()

    global cols_left
    global cols_right

    cols_left = [
        "text",
        "label",
        "near_visual_feature",
        "gcn_near_char_density",
        "gcn_near_char_number",
        "level1_parse_emb",
        "level2_parse_emb",
        "density",
        "visual_feature",
        "gcn_bert_predicted",
    ]

    cols_right = [
        "text",
        "label",
        "gcn_token_number",
        "char_density",
        "char_number",
        "parsing_level1",
        "parsing_level2",
        "text_density",
        "visual_embeddings",
        "bert_large_emb",
    ]

    new_df_train[cols_left] = df_train[cols_right]
    new_df_test[cols_left] = df_test[cols_right]

    # df_train.to_csv(root_data_dir + "/pipe_placeholder/df_train_docgcn_final.csv", index=False)
    logging.debug(df_train.shape)
    # df_test.to_csv(root_data_dir + "/pipe_placeholder/df_test_docgcn_final.csv", index=False)
    logging.debug(df_test.shape)

    return new_df_train, new_df_test


def feature_loading(new_df_train, new_df_test):
    train_size = 1
    train_data = new_df_train.sample(frac=train_size, random_state=200)
    # test_data=new_df.drop(train_data.index).reset_index(drop=True)
    train_data = train_data.reset_index(drop=True)

    # Train and Val Data set splits
    new_train_data = train_data[:10000]
    new_eval_data = train_data[10000:].reset_index(drop=True)

    # train, val = train.reset_index(drop=True), val.reset_index(drop=True)

    logging.debug("FULL Dataset: {}".format(new_df_train.shape))
    logging.debug("TRAIN Dataset: {}".format(train_data.shape))
    logging.debug("TEST Dataset: {}".format(new_df_test.shape))

    logging.debug("NEW TRAIN Dataset: {}".format(new_train_data.shape))
    logging.debug("NEW EVAL Dataset: {}".format(new_eval_data.shape))

    training_set = SentimentData(train_data, tokenizer, MAX_LEN)
    new_training_set = SentimentData(new_train_data, tokenizer, MAX_LEN)
    new_eval_set = SentimentData(new_eval_data, tokenizer, MAX_LEN)
    # testing_set = SentimentData(test_data, tokenizer, MAX_LEN)
    test_set = SentimentData_test(new_df_test[cols_left], tokenizer, MAX_LEN)

    # setting batch size of each dataset post splits
    train_params = {"batch_size": TRAIN_BATCH_SIZE, "shuffle": True, "num_workers": 0}
    test_params = {"batch_size": TEST_BATCH_SIZE, "shuffle": False, "num_workers": 0}
    eval_params = {"batch_size": VALID_BATCH_SIZE, "shuffle": False, "num_workers": 0}

    # training_loader = DataLoader(training_set, **train_params)
    new_training_loader = DataLoader(new_training_set, **train_params)
    # testing_loader = DataLoader(testing_set, **test_params)
    vali_loader = DataLoader(test_set, **test_params)
    eval_loader = DataLoader(new_eval_set, **eval_params)

    return new_training_loader, vali_loader, eval_loader


def collate_fn(data):
    zipped = zip(data)
    return list(zipped)


def calcuate_accuracy(preds, targets):
    n_correct = (preds == targets).sum().item()
    return n_correct


# Defining the training function on the 80% of the dataset for tuning the distilbert model


def trainer(epoch, new_model, new_writer):
    tr_loss = 0
    n_correct = 0
    nb_tr_steps = 0
    nb_tr_examples = 0
    # new_model = RobertaClass()
    # new_model.to(device)
    new_model.train()
    for _, data in tqdm(
        enumerate(new_training_loader, 0),
        desc="DocGCN Model Classifer Training on DocBank Train Set",
    ):
        ids = data["ids"].to(device, dtype=torch.long)
        mask = data["mask"].to(device, dtype=torch.long)
        token_type_ids = data["token_type_ids"].to(device, dtype=torch.long)
        targets = data["targets"].to(device, dtype=torch.long)
        visual_feature = data["visual_feature"].to(device, dtype=torch.float)
        gcn_visual_feature = data["gcn_visual_feature"].to(device, dtype=torch.float)
        gcn_bert_base = data["gcn_bert_base"].to(device, dtype=torch.float)
        parsing1 = data["parsing1"].to(device, dtype=torch.float)
        parsing2 = data["parsing2"].to(device, dtype=torch.float)
        char_density = data["char_density"].to(device, dtype=torch.float)
        char_number = data["char_number"].to(device, dtype=torch.float)

        outputs = new_model(
            ids,
            mask,
            token_type_ids,
            char_density,
            char_number,
            gcn_visual_feature,
            gcn_bert_base,
            parsing1,
            parsing2,
            visual_feature,
        )

        loss = loss_function(outputs, targets)
        tr_loss += loss.item()
        # logging.debug(tr_loss)
        big_val, big_idx = torch.max(outputs.data, dim=1)
        n_correct += calcuate_accuracy(big_idx, targets)
        # logging.debug(n_correct)

        nb_tr_steps += 1
        nb_tr_examples += targets.size(0)
        # logging.debug(_)

        if _ % 1000 == 0:
            loss_step = tr_loss / nb_tr_steps
            accu_step = (n_correct * 100) / nb_tr_examples

            # ...log the running loss
            new_writer.add_scalar(
                "Mini Batch training loss",
                loss_step,
                epoch * len(new_training_loader) + _,
            )

            new_writer.add_scalar(
                "Mini Batch training Accuracy",
                accu_step,
                epoch * len(new_training_loader) + _,
            )

        optimizer.zero_grad()
        loss.backward()
        # # When using GPU
        optimizer.step()
        # writer.flush()

    logging.debug(
        f"The Total Accuracy for Epoch {epoch}: {(n_correct*100)/nb_tr_examples}"
    )
    epoch_loss = tr_loss / nb_tr_steps
    epoch_accu = (n_correct * 100) / nb_tr_examples
    logging.debug(f"Training Loss Epoch: {epoch_loss}")
    logging.debug(f"Training Accuracy Epoch: {epoch_accu}")
    new_writer.add_scalar("Epoch Train Loss", epoch_loss, epoch)
    new_writer.add_scalar("Epoch Train Accuracy", epoch_accu, epoch)


def validator(new_model, eval_loader):
    new_model.eval()
    n_correct = 0
    tr_loss = 0
    nb_tr_steps = 0
    nb_tr_examples = 0
    output_list = []
    with torch.no_grad():
        for _, data in tqdm(
            enumerate(eval_loader, 0),
            desc="DocGCN Model Classifer Validation on DocBank Eval Set",
        ):
            ids = data["ids"].to(device, dtype=torch.long)
            mask = data["mask"].to(device, dtype=torch.long)
            token_type_ids = data["token_type_ids"].to(device, dtype=torch.long)
            targets = data["targets"].to(device, dtype=torch.long)
            # char_den = data["char_density"].to(device, dtype=torch.float)
            # density = data["density"].to(device, dtype=torch.float)
            visual_feature = data["visual_feature"].to(device, dtype=torch.float)
            gcn_visual_feature = data["gcn_visual_feature"].to(
                device, dtype=torch.float
            )
            gcn_bert_base = data["gcn_bert_base"].to(device, dtype=torch.float)
            parsing1 = data["parsing1"].to(device, dtype=torch.float)
            parsing2 = data["parsing2"].to(device, dtype=torch.float)
            char_density = data["char_density"].to(device, dtype=torch.float)
            char_number = data["char_number"].to(device, dtype=torch.float)
            # token_density = data['token_density'].to(device, dtype = torch.float)
            # token_number = data['token_number'].to(device, dtype = torch.float)

            outputs = new_model(
                ids,
                mask,
                token_type_ids,
                char_density,
                char_number,
                gcn_visual_feature,
                gcn_bert_base,
                parsing1,
                parsing2,
                visual_feature,
            )
            loss = loss_function(outputs, targets)
            tr_loss += loss.item()
            big_val, big_idx = torch.max(outputs.data, dim=1)
            output_list = output_list + list(big_idx)
            n_correct += calcuate_accuracy(big_idx, targets)

            nb_tr_steps += 1
            nb_tr_examples += targets.size(0)

    epoch_loss = tr_loss / nb_tr_steps
    epoch_accu = (n_correct * 100) / nb_tr_examples
    print(f"Validation Loss Epoch: {epoch_loss}")
    print(f"Validation Accuracy Epoch: {epoch_accu}")

    return epoch_accu, output_list


def batch_predictor(model_docgcn, testing_loader):
    print("Batch Size of Test Data for Inferencing:", len(vali_loader))

    # model_docgcn = RobertaClass()
    # model_docgcn.load_state_dict(torch.load('../models/docbank_docgcn_bert_layout_segment_classifier_v3.pt'))
    # model_docgcn.to(device)

    model_docgcn.eval()

    nb_tr_steps = 0
    output_list = []
    with torch.no_grad():
        for _, data in tqdm(
            enumerate(testing_loader, 0),
            desc="Batch Inferencing with DocGCN Model Classifer on DocBank Test Set",
        ):
            ids = data["ids"].to(device, dtype=torch.long)
            mask = data["mask"].to(device, dtype=torch.long)
            token_type_ids = data["token_type_ids"].to(device, dtype=torch.long)
            visual_feature = data["visual_feature"].to(device, dtype=torch.float)
            gcn_bert_base = data["gcn_bert_base"].to(device, dtype=torch.float)
            parsing1 = data["parsing1"].to(device, dtype=torch.float)
            parsing2 = data["parsing2"].to(device, dtype=torch.float)
            char_density = data["char_density"].to(device, dtype=torch.float)
            char_number = data["char_number"].to(device, dtype=torch.float)
            # pos_emb = data['pos_emb'].to(device, dtype = torch.float)
            visual = data["visual"].to(device, dtype=torch.float)

            # outputs = model(ids, mask, token_type_ids,visual_feature,char_density,char_number,parsing1,parsing2,gcn_bert_base,visual).squeeze()
            outputs = model_docgcn(
                ids,
                mask,
                token_type_ids,
                char_density,
                char_number,
                visual_feature,
                gcn_bert_base,
                parsing1,
                parsing2,
                visual,
            )

            big_val, big_idx = torch.max(outputs.data, dim=1)
            output_list = output_list + list(big_idx)

            nb_tr_steps += 1

    return output_list


def docgcn_clssifier_report(actual_classes, prediction_classes):
    target_names = list(integer_mapping.keys())
    if not os.path.isdir(model_reports_path):
        os.makedirs(model_reports_path)

    report = classification_report(
        actual_classes,
        prediction_classes,
        digits=4,
        target_names=target_names,
        output_dict=True,
    )
    c_matrix = confusion_matrix(actual_classes, prediction_classes)
    plot_confusion_matrix(c_matrix, classes=target_names)
    # multiclass_f1_score(torch.tensor(actual_classes), torch.tensor(prediction_classes), num_classes=13)
    # print(multiclass_f1_score)

    clf_df = pd.DataFrame(report).transpose()
    clf_df.to_csv(model_reports_path + "/docgcn_confusion_matrix.csv")
    print(report)


def plot_confusion_matrix(
    cm, classes, normalize=False, title="Confusion matrix", cmap=plt.cm.Blues
):
    plt.imshow(cm, interpolation="nearest", cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    if normalize:
        cm = cm.astype("float") / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print("Confusion matrix, without normalization")

    thresh = cm.max() / 2.0
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(
            j,
            i,
            cm[i, j],
            horizontalalignment="center",
            color="white" if cm[i, j] > thresh else "black",
        )

    plt.tight_layout()
    plt.ylabel("True label")
    plt.xlabel("Predicted label")
    plt.savefig(model_reports_path + "/clf_cm.png")
    plt.savefig(model_reports_path + "/clf_cm.pdf")


if __name__ == "__main__":
    new_df_train, new_df_test = feature_aggregation(root_data_dir)
    new_training_loader, vali_loader, eval_loader = feature_loading(
        new_df_train, new_df_test
    )

    new_model = RobertaClass()
    new_model.to(device)

    # Creating the loss function and optimizer
    loss_function = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(
        params=new_model.parameters(), lr=1e-05
    )  # change learning rate

    new_writer = SummaryWriter()

    # get some random training images
    dataiter = iter(new_training_loader)
    labels = next(dataiter)["targets"]
    masks = next(dataiter)["ids"]

    # EPOCHS = 2
    for epoch in range(EPOCHS):
        trainer(epoch, new_model, new_writer)

    torch.save(
        new_model.state_dict(),
        "./models/docbank_docgcn_bert_layout_segment_classifier_v4.pt",
    )

    model_to_test = RobertaClass()
    model_to_test.load_state_dict(
        torch.load("./models/docbank_docgcn_bert_layout_segment_classifier_v4.pt")
    )
    # DocGCN model validation
    acc, pre_list = validator(model_to_test, eval_loader)

    # Batch Inferencing on Test data samples
    batch_predictions = batch_predictor(model_to_test, vali_loader)

    print("Mapping of labels:", integer_mapping)

    # Get the predicted category id for selected test dataset.
    prediction_classes = []
    for pred in batch_predictions:
        prediction_classes.append(pred.cpu().numpy().tolist())
    print(prediction_classes)

    # getting the actual labels
    actual_classes = new_df_test["label"].tolist()

    docgcn_clssifier_report(actual_classes, prediction_classes)
