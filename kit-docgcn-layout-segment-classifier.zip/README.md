# Introduction 
At the core, this ADO repo describes the training and inferencing pipelines in detail required for building `Doc-GCN multi-class classsification` model on document layout analysis datasets like [`Docbank`](https://doc-analysis.github.io/docbank-page/index.html) and [`FUNSD`](https://guillaumejaume.github.io/FUNSD/).

Doc-GCN is an acronym for using Heterogeneous Graph Convolutional Networks(GCNs) for Document Layout Analysis (DLA) Tasks. It captures relationships between various Document Layout Components(DLCs) to harmonize and integrate various heterogeneous features aspects such as `syntactic`, `symanctic`, `density` and `appearance` features. It enhances feature representations methodology of DLCs by going beyond conventional `image` and `text` features only when tackling DLA specific problems. Doc-GCN presents itself as a multi-class classifier capable to distinguish and categorize various DLCs into object classes like `abstract`,`author`,`caption`,`date`,`equation`,`figure`,`footer`,`paragraph`,`reference`,`section`,`title`,`list` and `table`.

In particular, the experimental notebooks are developed targeting `FUNSD` dataset, whereas model pipelines are developed targeting `Docbank` dataset as it resembles closely with business scenario to accomodate many classes or categories of DLCs from sample documents.


# Table of contents
1. [Setup training environment](#setup-training-environment)
2. [Download Docbank dataset](#download-docbank-dataset)
3. [Preprocessing and Feature extraction](#preprocessing-and-feature-extraction)
4. [Enhanced feature representations](#enhanced-feature-representations)
5. [Training and Batch Inferencing DocGCN Multi-Classifier on Docbank dataset](#training-and-batch-inferencing-docgcn-multi-classifier-on-docbank-dataset)
6. [Model evaluation with Tensorboard](#model-evaluation-with-tensorboard)
7. [Building Endpoint Inference Pipeline](#building-endpoint-inference-pipeline)
8. [Major Challenges](#major-challenges)
9. [Research Paper](#research-paper)


## Setup training environment

To set the local environment for training of DocGCN Model, follow the below steps in order.


1. Setup `conda` or `venv` as python virtual environment of choice and activate it.
2. Create `.env` file for passing your PAT `AZURE_DEVOPS_PERSONAL_ACCESS_TOKEN=<PAT>` and source it in terminal profile
  ```code
    source .env
  ```
3. Git clone the repo 

  ```code
  git clone "https://kpmgjp-prod-001@dev.azure.com/kpmgjp-prod-001/kpmgjp-audit-independence-check/_git/kit-docgcn-layout-segment-classifier"
  ```

4. Install all the dev dependencies with `requirements_dev.txt`.

  ```code
  pip install -r requirements_dev.txt
  ```

5. Git clone `py-bottom-up-attention` repo while on the root directory of previously cloned ADO repo for config yaml references from airsplay.

  ```code
  git clone "https://github.com/airsplay/py-bottom-up-attention.git"
  ```

6. Install Facebooks's Detectron2 object detection module by executing this command 

  ```code
  python -m pip install 'git+https://github.com/facebookresearch/detectron2.git'
  ```

7. Also all BERT pre-trained models should be pre-downloaded and cached to local `models/` directory beforehand. 
  ```code
  python utils/bert_downloader.py
  ```

## Download Docbank dataset

As of June 2023, the publishers of [Docbank dataset](https://doc-analysis.github.io/docbank-page/index.html) have restricted its public access and it may not be available now to download from internet. Give it a try, you might get lucky!!. It is the most straightforward way to download Dockbank.

Alternatively, for review purposes few samples or subsets of dataset have been placed at this [`Sharedrive`](https://spo-global.kpmg.com/:f:/r/sites/JP-IndependenceCheck/Shared%20Documents/DocBank_sample_dataset?csf=1&web=1&e=Jwbh2R) location which needs to be downloaded separately into `datastore/` directory.

1. Create two empty folders under `datastore` with names `docbank_training_data/` and `docbank_testing_data/` respectively to align with `Sharedrive` downloads.

2. The raw Docbank data from the publishers comes in combination of `.txt` annotation and `.jpg` image files, which has been pre-conditioned and transformed into `.json` already and stored in `Sharedrive`.

3. The converted Docbank data from `Sharedrive` comes in combination of annotation `.json` file and raw `image` file pairs which needs to go under `annotations/` and `images/`. Confirm the files matching the right folder types.

> **_NOTE:_**  Both train and test datasets will traverse together in preprocessing and feature extraction steps of pipeline. All python scripts must be executed from root directory of repo.


## Preprocessing and feature extraction

1. The **image** preprocessing pipeline involves tranforming the bounding boxes `txt` files to `json` files and normalizing the image pytorch tensors by parsing it though `Detectron2` pooler units for image features extraction. The pre-trained model used by Detectron2 is `faster_rcnn_from_caffe`.

2. Run either of the command below for image proprocessing pipelines.

   * For full dataset <br/>
      ```code
      python -W "ignore" training/image_preprocessing.py --dataset_type docbank --dataset_path ./datastore
      ```
   * For partial dataset, use `size_limit` parameter suffix <br/>
      ```code
      python -W "ignore" training/image_preprocessing.py --dataset_type docbank --dataset_path ./datastore --train_size_limit 20000 --test_size_limit 5000
      ```

3. The **text** preprocessing pipeline involves tranforming the identified text fields in `json` files into `768-D` or `1024-D` embedding vectors by parsing it though pretrained `BERT` output of [CLS] units for textual features extraction. The current model is made compatible with `bert-base-uncased` and `bert-large-uncased` BERT variants.

4. Run either of the command below for text proprocessing pipelines.

   * For full dataset <br/>
      ```code
      python -W "ignore" training/text_preprocessing.py --dataset_type docbank --dataset_path ./datastore
      ```
   * For partial dataset, use `size_limit` parameter suffix <br/>
      ```code
      python -W "ignore" training/text_preprocessing.py --dataset_type docbank --dataset_path ./datastore --train_size_limit 20000 --test_size_limit 5000
      ```


## Enhanced feature representations

1. Visual scene graphs are generated using the relationship and gap distance between various layout segment components. Also other feature aspects wrt to `char_number`, `char_density`, `token_number` and `token_density` are represented .

2. Run the below command for relationship based enhanced feature extractions form scene graphs.

    ```code
    python -W "ignore" training/scene_graph_generation.py --dataset_type docbank --dataset_path ./datastore --train_size_limit 20000 --test_size_limit 5000
    ```

3. Visual features are further enhanced using distance based weighted matrix representations and it is extracted using Graph Convolution Network based on normalized gap distance between document layout components. Run the below command for it. It is important to note that generating `gcn_token_number` feature field in both train and test dictionary sets is the main goal of this step.

    ```code
    python -W "ignore" training/distance_weighted_gcn.py --dataset_type docbank --dataset_path ./datastore
    ```

4. Textual features are further enhanced using parent child based hierarchial Graph Network representations of layout components hierarchy. Execute the below command for it. It is important to note that generating `bert_large_emb`,`parsing_level1` and `parsing_level2` embedding feature fields in both train and test dictionary sets is the main goal of this step.

    ```code
    python -W "ignore" training/parent_child_gcn.py --dataset_type docbank --dataset_path ./datastore
    ```

> **_NOTE:_**  `parent_child_gcn` takes more time to converge, we should consider caliberating with extended epochs.

## Training and Batch Inferencing DocGCN Multi-Classifier on Docbank dataset

Make sure the command is executed from the root directory of repo.

  ```code
  python -W "ignore" training/docgcn_multiclassifier.py --dataset_type docbank --dataset_path ./datastore --train_size_limit 20000 --test_size_limit 5000
  ```

It will aggregate all previously generated normal and enhanced versions of textual and visual features and parse it to main DocGCN model for training.
Also during training ,model checkpoints are saved to track and monitor the loss and accuracy trend to prevent overfitting with
tensorboard logging at mini-batches of `size = 1000`.

Also, the same command after training will perform `batch inferencing` at the end on partially hold-out test set and register `classification report` and `confusion metrics` for the trained DocGCN Multi-Classifier in `./models/docgcn_reports` folder.



## Model evaluation with Tensorboard

The checkpoints are saved and loaded from automatically created `run/` folder for Tensorboard plots.
It can be triggered with the below command to see the plots.

`tensorboard --logdir=runs`

All training and validation plots have been statically pushed to `./models/docgcn_reports` for visual reference.
It currently depicts only a partially trained model due to limited data and compute resource access.



## Building Endpoint Inference Pipeline


Doc-GCN model can also be applied to mono-inferencing by send real-world test image data as `POST request payload to Flask` endpoint.
A user can send an `API request` with sample test image to the Flask API endpoint and get resulting image back with OCR overlay of
predicted Goc-GCN classes.


### Steps to setup testing environment for endpoint inferencing

1. Setup `conda` or `venv` as python virtual environment of choice for testing and activate it.
2. Install all the test dependencies with `requirements_test.txt`.

    ```code
    pip install -r requirements_test.txt
    ```
3. Install `detectron2` to perform object detection with tesseract processes image data.

    ```code
    python -m pip install 'git+https://github.com/facebookresearch/detectron2.git'
    ```

4. Download spacy language models for text featurizations.

    ```code
    python -m spacy download en_core_web_sm
    ```

> **_NOTE:_**  For inferencing purposes, the sample test image and model files must be placed at `inferencing/` and `models/` directory of repo respectively. Some trail inferencing image samples can be downloaded from [shared image location](https://spo-global.kpmg.com/:f:/r/sites/JP-IndependenceCheck/Shared%20Documents/DocBank_sample_dataset/inferencing_samples?csf=1&web=1&e=6vwTEE) and models can be access from [shared model location](https://spo-global.kpmg.com/:f:/r/sites/JP-IndependenceCheck/Shared%20Documents/DocBank_sample_dataset/models?csf=1&web=1&e=bMybN8).


### Method 1 : Mono-Inferencing with Flask endpoint

The endpoint inferencing can be invoked by the steps below :

1. Launch the Flask server with `http://127.0.0.1:8001` URL with the below command :

    ```code
    python inferencing/docgcn_app.py
    ```
2. `POST` Trigger the Flask prediction `REST` endpoint with sample image file for fetching results from model.

    ```code
    python -W "ignore" inferencing/docgcn_client_post_request.py --img "inferencing/2.tar_1401.0812.gz_NewversionArXiv_26_ori.jpg"
    ```
3. This docgcn server will extract the image path in JSON request payload and invoke the `docgcn_server.py` script to get
prediction results and will save results in `inferencing/res_data` folder containing raw results data in `json` with `_pred_new.json` suffix and 
an OCR overlayed post-processed image with `_dla_new.png`.

4. Since the preliminary image will have clustered bounding boxes whic are difficult to comprehend, the following script with consolidate and merge few with extra post-processing on image.

    ```code
    python inferencing/bbox_merge.py --img inferencing/2.tar_1401.0812.gz_NewversionArXiv_26_ori.jpg
    ```


### Method 2 : Direct script based inferencing

Alternatively, one can also run the inferencing script directly to fetch results locally.

```code
python -W "ignore" inferencing/docgcn_inference.py --img "inferencing/2.tar_1401.0812.gz_NewversionArXiv_26_ori.jpg"
```

And then post-process it with merging of nearby bounding boxes for enhanced visibility.

```code
python inferencing/bbox_merge.py --img inferencing/2.tar_1401.0812.gz_NewversionArXiv_26_ori.jpg
```




## Major Challenges 

1. No particular existing code work repository with DocBank dataset explicitly, only experimental results available on shared paper with some assumptions and background information.
2. The authors only provided a sample process or workflow with FUNSD (smaller in size with less classes) dataset that is not scalable to adapt and posed serious challenges to make things compatible with Docbank(larger) with extra pre-processing and post-processing steps.
3. GCNs have not evolved much over the years, therefore having Pytorch latest compatibility was bit difficult due to archaic library dependencies. However, overall repo have been made compatible with Pytorch except the GCNs.
4. Some of the major Git issues highlighted were addressed in the pipeline building process which were also reported by other fellow teams(members) using the repo for refactoring.
5. No proper DocGCN inferencing approach provided, so a new inferencing methodology is created from scratch with `pytesseract` and made compatible to work with `detectron2` and `BERT` models.
6. The repo did not had any package dependency `environment.yaml` or `requirements.txt` file causing initial setup issues during installation phase. 
7. The authors predominantly used Google Colab to parse pickle and json file between sequential notebooks , which were inaccessible via git repo. This posed major challenges in reconcilliation of intermediate results during code adaptation. Only the final results from last notebook were published.



## Research Paper

The repository contains the training and inferencing pipeline code that represents refined and refactored version of DLA approach first published in
[Doc-GCN: Heterogeneous Graph Convolutional Networks for Document Layout Analysis Paper](https://aclanthology.org/2022.coling-1.256.pdf).
The paper on Doc-GCN links to a [github](https://github.com/adlnlp/doc_gcn) repo which is not very well-maintained to date and contains lots of missing elements, misrepresentations and non-functional components with respect to DocBank dataset.



# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)