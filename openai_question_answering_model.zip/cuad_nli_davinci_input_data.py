"""Script for preparing OpenAI models input data."""

import json
import openai
import os
import re
import spacy
from transformers import GPT2TokenizerFast

# Load datasets 
nli_data =  json.load(open('qa_data.json', 'r'))
cuad_data = json.load(open('qa_cuad.json', 'r'))

# Load SpaCy
nlp = spacy.load("en_core_web_lg")


def add_sentences_key(contract_data):
    # Add a new key (sentences) to each of the dictionaries of contract_data
    # This key is all senteces of the original contract
    for key in contract_data:
        contract_sentences = []
        contract = key["text"]
        doc = nlp(contract)
        reconstructed_contract = ""
        for sent in doc.sents:
            new_sentence = sent.text
            L = len(reconstructed_contract)
            pos = contract.find(new_sentence, L)
            # This should not happen
            if pos < 0:
                raise Exception("Sentence was not found in the original contract")
            else:
                if pos > L:
                    # We append to the sentence spaces that were removed by SpaCy
                    new_sentence = contract[L:pos]+new_sentence
            reconstructed_contract += new_sentence
            contract_sentences.append(new_sentence)
        key["sentences"] = contract_sentences
        # We check that the contract reconstructed by SpaCy sentences is equal to the original one
        if reconstructed_contract != contract:
            raise Exception("Reconstructed constract is not equal to the original one.")

add_sentences_key(nli_data)
add_sentences_key(cuad_data)


def normalize_whitespace(sentence):
	sentence = sentence.strip()
	sentence = re.sub(r'\n\s*\n', '\n', sentence)
	sentence = re.sub(r'[^\S\r\n]+', ' ', sentence)
	return sentence


def openai_input_data(contract_data):
    # This will be a list of dictionaries, each dictionary having two keys prompt and answer.
    model_input_data = []
    for key in contract_data:
        for question in key["q&a"]:
            # We only consider multiple-choice questions with evidence and answer. 
            if len(question["options"]) > 0 and len(question["evidence"]) > 0 and len(question["answer"]) > 0:
                if question["answer"] not in ["Yes", "No"]:
                    raise Exception("Correct answer to be Yes or No")
                input_data = {}
                # Determine the start and end index of the evidence
                start = question["evidence"][0][0]
                end = question["evidence"][0][1]
                if len(question["evidence"]) > 1:
                    for new_start, new_end in question["evidence"][1:]:
                        if new_start < start:
                            start = new_start
                        if new_end > end:
                            end = new_end
                # Attach the first sentence of the contract to the prompt
                prompt = key["sentences"][0]
                start_indx = len(key["sentences"][0])
                
                # Append to the prompt all sentences that include portions of the evidence
                sent_indx = []
                cnt = 1
                for sentence in key["sentences"][1:]:
                    L = len(sentence)
                    if ( ((start_indx < start) and (start_indx + L > start)) or
                        ((start_indx >= start) and (start_indx < end))):
                        prompt += sentence
                        sent_indx.append(cnt)
                    start_indx += L
                    cnt += 1

                # Checks that there is no hole in the prompt and the evidence is included in the prompt
                if not (( len(sent_indx)==0 or 
                        sent_indx==list(range(min(sent_indx),max(sent_indx)+1))) and
                        key["text"][start:end] in prompt):
                    raise Exception("Invalid prompt")

                # Append to the prompt the question
                input_data["prompt"] = normalize_whitespace(prompt)
                input_data["prompt"] += "\nQuestion: "+question["question"]+"\nA. Yes\nB. No\nAnswer:"
                input_data["answer"] = question["answer"]
                model_input_data.append(input_data)

    return model_input_data


nli_input_data = openai_input_data(nli_data)
with open('nli_input_data.json', 'w') as outfile:
    json.dump(nli_input_data, outfile, indent=4, ensure_ascii=False)

cuad_input_data = openai_input_data(cuad_data)
with open('cuad_input_data.json', 'w') as outfile:
    json.dump(cuad_input_data, outfile, indent=4, ensure_ascii=False)

# Print Estimate API cost
tokenizer = GPT2TokenizerFast.from_pretrained("gpt2")
token_n = 0
for info in nli_input_data+cuad_input_data:
    tk = tokenizer(info["prompt"])
    # Plus 1 because the API will add one token as answer (yes or no)
    token_n += len(tk['input_ids']) + 1

print("Total number of tokens", token_n)
print("Estimated Cost ($)", token_n*0.02/1000)
