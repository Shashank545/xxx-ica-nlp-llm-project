"""Script for evaluating the Da Vinci responses."""

import json
import os

file_names = [file_name for file_name in os.listdir("da_vinci_responses/") if file_name[-5:]=='.json']

print(len(file_names))

predictions = []
for file_name in file_names:
    data =  json.load(open('da_vinci_responses/'+file_name, 'r'))
    predictions.append(data["response"]["choices"][0]["text"].strip().lower())

print(list(set(predictions)))

answer_dict = {'b. no':'No', 'a. yes':'Yes', 'a':'Yes'}

true_yes = 0
true_no = 0
false_yes = 0
false_no = 0

for file_name in file_names:
    data =  json.load(open('da_vinci_responses/'+file_name, 'r'))
    prediction = answer_dict[data["response"]["choices"][0]["text"].strip().lower()]
    actual = data["answer"]
    if prediction=='Yes' and actual == 'Yes':
        true_yes += 1
    elif prediction=='No' and actual == 'No':
        true_no += 1
    elif prediction=='No' and actual == 'Yes':
        false_no += 1
    elif prediction=='Yes' and actual == 'No':
        false_yes += 1

print(true_yes, true_no, false_yes, false_no)
print((true_yes+true_no)/(true_yes+true_no+false_yes+false_no))
print(true_yes/(true_yes+0.5*(false_yes+false_no)))