"""Script for calling Da Vinci API."""

import json
import openai
import os
import time
from transformers import GPT2TokenizerFast

# Load dataset 
nli_data =  json.load(open('nli_input_data.json', 'r'))

print(len(nli_data))

openai.api_key = "--------------------"

tokenizer = GPT2TokenizerFast.from_pretrained("gpt2")

finished = False

# Call the API
while not(finished):
    for count in range(len(nli_data)):
        file_name = 'da_vinci_responses/'+str(count)+'.json'
        if not(os.path.exists(file_name)):
            question = nli_data[count]
            try:
                tokens = tokenizer(question["prompt"])
                L = len(tokens['input_ids'])
                if L <= 4092:
                    prompt = question["prompt"]
                else:
                    prompt = tokenizer.decode(tokens['input_ids'][(L-4092):L])
                response = openai.Completion.create(
                model="text-davinci-003",
                prompt=prompt,
                temperature=0,
                max_tokens=5,
                top_p=1,
                frequency_penalty=0.0,
                presence_penalty=0.0,
                #stop=["\n"]
                )
                time.sleep(3)
                question["response"] = response
                with open(file_name, 'w') as outfile:
                    json.dump(question, outfile, indent=4, ensure_ascii=False)
            except Exception as e:
                print(count)
                print(e)

    finished = True
    for count in range(len(nli_data)):
        file_name = 'da_vinci_responses/'+str(count)+'.json'
        if not(os.path.exists(file_name)):
            finished = False
            break

