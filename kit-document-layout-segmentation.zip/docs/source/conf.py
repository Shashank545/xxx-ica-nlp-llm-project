# Configuration file for the Sphinx documentation builder.

# -- Path setup --------------------------------------------------------------

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.

import os
import sys

sys.path.insert(0, os.path.abspath("../.."))


# -- Project information -----------------------------------------------------

project = "kit-document-layout-segmentation"
copyright = "2022, KPMG Ignition Tokyo"
author = "KIT"

# -- General configuration ---------------------------------------------------

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.autosummary",
    "sphinxcontrib.inkscapeconverter",
    "nbsphinx",
    "myst_parser",  # Markdowns
]

myst_heading_anchors = 3
# Add any paths that contain templates here, relative to this directory.
templates_path = ["_templates"]

# Ignore Patterns: This should include any file or directory that will not be
# used in any step of the build process.
exclude_patterns = [
    "_build",
    "build",
    "Thumbs.db",
    ".DS_Store",
    "**.ipynb_checkpoints",
    "_notebooks",
]


# -- Options for HTML output -------------------------------------------------

html_theme = "pydata_sphinx_theme"
html_static_path = ["_static"]
html_context = {
    "css_files": [
        "_static/theme_overrides.css"  # override wide tables in RTD theme
    ]
}
html_logo = "_static/kpmg.svg"


# -- Docstrings ----------------------------------------------------------------
autodoc_typehints = "description"
napoleon_use_ivar = True  # This is required for Class attributes
autosummary_generate = True  # This is required for generating source code stubs

master_doc = "index"


# -- Options for Latex PDF output ----------------------------------------------
# These settings make latex work with Japanese characters
latex_engine = "platex"
latex_use_xindy = False
# This prevents problems that might occur with the API documentation
# (LaTeX error when lists become too nested)
latex_elements = {
    "preamble": r"""
    \usepackage{enumitem}
    \setlistdepth{99}
    """
}
