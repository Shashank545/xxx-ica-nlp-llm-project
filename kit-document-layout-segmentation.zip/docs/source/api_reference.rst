API Reference
=============

Modules
----------

.. autosummary::
   :toctree: modules

   document_layout_segmentation.word_document_segmentation.docx_segmentation
   document_layout_segmentation.word_document_segmentation.supporting_utils
   document_layout_segmentation.utils.basic_utils
   document_layout_segmentation.pdf_document_segmentation.pdf_doc_segmentation
   document_layout_segmentation.pdf_document_segmentation.helpers