{% if referencefile %}
.. include:: {{ referencefile }}
{% endif %}

{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. auto{{ objtype }}:: {{ objname }}