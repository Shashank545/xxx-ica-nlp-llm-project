.. My Project documentation master file, created by
   sphinx-quickstart on Fri May 29 11:54:02 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

KIT Document Layout Segmentation's documentation
==================================

KIT document layout segmentation library for pdf and word files.

.. toctree::
   :maxdepth: 2

   markdown/README
   markdown/DEVELOPMENT
   api_reference

