# KIT Document Layout Segmentation Development Documentation

## Table of contents

- [Development Environment](#development-environment)
  - [Poetry](#poetry)
  - [Internal Packages](#internal-packages)
  - [Data](#data)
- [Pre-commit hooks](#compulsory-set-up-pre-commit-hooks)
- [Tests](#tests)
- [Examples](#examples)

---

## Development Environment

### Poetry
 * Install Poetry
   * From official website (Recommended)
     ```shell
     curl -sSL https://install.python-poetry.org | python3 -
     ```
   * With PIP
      ```shell
      pip3 install poetry
      ```
   * With Homebrew
     ```shell
      brew install poetry 
     ```
 * If your project has internal dependency, Configuration Poetry to install dependencies from kit-pypi with your username and PAT.
      ```shell
        poetry config http-basic.azure YOUR_USERNAME YOUR_PAT
      ```
 * Install dependencies
    ```shell
    poetry install
    ```
 * To add new dependencies use `poetry add` 
    ```shell
    poetry add dependency_name
    ```
 * Read `Poetry` [documentation](https://python-poetry.org/docs/) for more.
   
### Internal Packages

| ⚠️ Check if your project has internal package dependencies and  make sure your machine is setup to install packages from `kit-pypi`.   |
|----------------------------------------------------------------------------------------------------------------------------------------|

If your project has internal package dependencies setup to install packages from `kit-pypi` as follows. 

- Add the following to pyproject.toml
  ```toml
    [[tool.poetry.source]]
    name = "azure"
    url = "https://pkgs.dev.azure.com/kpmgjp-prod-001/_packaging/kit-pypi/pypi/simple/"
    secondary = true
  ```

- Configuration Poetry to install dependencies from kit-pypi with your username and PAT.
  ```shell
    poetry config http-basic.azure YOUR_USERNAME YOUR_PAT
  ```
- Add internal package.
  ```shell
    poetry add INTERNAL_PACKAGE_NAME
  ```


### Data
- Open Source
- Internal (O-Drive links)

---

## **Compulsory:** Set up pre-commit hooks
| ⛔ ☠️**Never skip this step when developing on this library** ☠️ ⛔ |
|-------------------------------------------------------------------|

The code in this repository is checked and formatted with `flake8`, `isort` and `black`.
This is checked in the Azure pipelines CI. As a handy tool, you can set up
pre-commit hooks which check the code at commit time. The steps are:

- Install the hooks that are defined in the `.pre-commit-config.yaml` file:
  ```shell
    poetry run pre-commit install
  ```
- To update pre-commits, run following command.
  ```shell
    poetry run pre-commit autoupdate
  ```
  
Now, when you do `git commit ...`, you should see that `black`, `isort` and `flake8`
automatically check the code (and edit it, in the case of `black` and `isort`).

---

## Tests
To run tests, simply run the following command from root directory of the repo.

```shell
  poetry run pytest
```

---

## Documentation
To build the documentation `cd` into `docs/` and run
```shell
    poetry run make html
```
The built documentation will be available in `docs/build/html/index.html`

More documentation is available at `docs/README.`

---

## Examples

Refer scripts folder for training and serving examples.