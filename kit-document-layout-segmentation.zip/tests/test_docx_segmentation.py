""" Pytest module for testing the conversion of word to JSON file """
import io
import json
import os

from document_layout_segmentation.word_document_segmentation import (
    word_segmentation,
)


def test_word_segmentation():
    """Executes the function in Docxtojson to convert Word file to JSON"""

    input_file = os.path.join(
        "tests", "resources", "word", "test_word_document.docx"
    )
    out = io.BytesIO()
    with open(input_file, "rb") as file_:
        out.write(file_.read())

    original_dictionary = word_segmentation(out)

    # Opening expected JSON file
    with open(
        os.path.join(
            "tests", "resources", "json", "word_segmentation_output.json"
        )
    ) as json_file:
        expected_dictionary = json.load(json_file)

    assert expected_dictionary == original_dictionary
