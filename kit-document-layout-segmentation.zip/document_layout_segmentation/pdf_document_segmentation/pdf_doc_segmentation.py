import os
import shutil
import tempfile
import time
from io import BytesIO
from typing import Optional

from .helper import (
    initial_engine,
    initial_ocr_engine,
    parsing_text_to_json,
    read_pdf,
    visualization_page,
)


def layout_analysis(
    file_bytes: BytesIO,
    document_lang: str = "en",
    output_path: Optional[str] = None,
    figure_table: bool = False,
    visualization: bool = False,
) -> dict:
    """
    Given an input document in PDF as bytes,
    the function returns a dictionary containing
    layout analysis results for all document pages.

    Args:
        file_bytes BytesIO: The PDF file as bytes.
        document_lang (str): This is language of document.
        Value that can be used are : ['ch', 'en', 'korean', 'japan',
        'chinese_cht', 'ta', 'te', 'ka', 'latin', 'arabic', 'cyrillic',
        'devanagari']
        Default selected language is 'en'
        output_path (str): The output path to save all results.
        figure_table (bool): True if we need to save recognized
        figures (image) and tables (excel).
        visualization (bool): True if we need to draw layout segmentations
        and OCR results on each document page.


    Returns:
        dict: Layout analysis results for all input document pages.
    """

    all_res: dict = {}

    if output_path is not None:
        temp_output_folder = tempfile.TemporaryDirectory()
        temp_output_path = temp_output_folder.name
        img_name = time.strftime("%Y%m%d-%H%M%S")

    try:
        engine = initial_engine()
        ocr_engine = initial_ocr_engine(document_lang)
        imgs = read_pdf(file_bytes.getvalue())
    finally:
        file_bytes.close()

    # Enumerate each page in a document
    for index, img in enumerate(imgs):

        # Engine can take bytes, path and URL.
        result = engine(img, img_idx=index)

        for item in result:
            html_str = None
            if "html" in item["res"]:
                html_str = {"html": item["res"]["html"]}
            pp_x = int(item["bbox"][0]) - 20
            pp_y = int(item["bbox"][1]) - 10
            pp_w = int(item["bbox"][2]) + 10
            pp_h = int(item["bbox"][3]) + 10

            crop_img = img[pp_y:pp_h, pp_x:pp_w]
            result_ocr = ocr_engine.ocr(crop_img, cls=True)
            res = list()

            for ocr_item in result_ocr[0]:
                temp_dict = {}
                temp_dict["text"] = ocr_item[1][0]
                temp_dict["confidence"] = round(ocr_item[1][1], 4)
                ocr_item_region_x = [
                    ocr_item[0][0][0] + pp_x,
                    ocr_item[0][0][1] + pp_y,
                ]
                ocr_item_region_y = [
                    ocr_item[0][1][0] + pp_x,
                    ocr_item[0][1][1] + pp_y,
                ]
                ocr_item_region_w = [
                    ocr_item[0][2][0] + pp_x,
                    ocr_item[0][2][1] + pp_y,
                ]
                ocr_item_region_h = [
                    ocr_item[0][3][0] + pp_x,
                    ocr_item[0][3][1] + pp_y,
                ]
                ocr_item_region = [
                    ocr_item_region_x,
                    ocr_item_region_y,
                    ocr_item_region_w,
                    ocr_item_region_h,
                ]
                temp_dict["text_region"] = ocr_item_region
                res.append(temp_dict)
            if html_str is not None:
                res.append(html_str)
            item["res"] = res

        if output_path is not None:

            parsing_text_to_json(
                result,
                all_res,
                str(index),
                temp_output_path,
                img_name,
                figure_table,
            )
            if visualization:
                output_img_res_path = os.path.join(
                    temp_output_path,
                    img_name,
                    img_name + "_layout_visulization_" + str(index) + ".jpg",
                )
                visualization_page(img, result, output_img_res_path)
        else:
            parsing_text_to_json(result, all_res, str(index))
    if visualization and output_path is not None:
        if output_path:
            # First save document page images, layout analysis results,
            # and visualization results to temp directory.
            # If we need to visualization and all results,
            # we copy all these files to a output path.
            shutil.copytree(
                os.path.join(temp_output_path, img_name),
                os.path.join(output_path, img_name),
                dirs_exist_ok=True,
            )

    return all_res
