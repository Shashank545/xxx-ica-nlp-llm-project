import json
import os
from copy import deepcopy
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from paddleocr import PaddleOCR, PPStructure, draw_structure_result, to_excel
from pdf2image import convert_from_bytes
from PIL import Image


def str2bool(v: str) -> bool:
    """
    Convert string to boolean.

    Args:
        v (str): Input string.

    Returns:
        bool: Return a True if the input string is
        one of "True", "true", "T", "t", "1"
            Otherwise return a Fasle.
    """
    # Normalize argument (--visulization)
    return v.lower() in ("true", "t", "1")


def initial_engine(show_log=False, image_orientation=True) -> PPStructure:
    """
    Initial PPStructure layout analysis engine.

    Returns:
        PPStructure: PPStructure layout analysis engine.
    """
    # return PaddleOCR(use_angle_cls=True, lang='en')
    return PPStructure(show_log=show_log, image_orientation=image_orientation)


def initial_ocr_engine(document_lang: str, use_angle_cls=True) -> PaddleOCR:
    """
    Initial Paddle OCR engine.

    Returns:
        PaddleOCR: PaddleOCR engine.
    """
    return PaddleOCR(lang=document_lang, use_angle_cls=use_angle_cls)


def read_pdf(file_bytes: bytes) -> list:
    """
    Convert the file in bytes to image.

    Args:
        file_bytes: Bytes representation of a PDF file

    Returns:
        imgs: List of images from the PDF file.
    """

    if not isinstance(file_bytes, bytes):
        raise TypeError("This method will only accept bytes as input")

    imgs = []
    images = convert_from_bytes(file_bytes)
    for item in images:
        imgs.append(np.array(item))

    return imgs


def visualization_page(
    image: cv2,
    result: list,
    output_path: Optional[str] = None,
    font_path: str = "pdf_document_segmentation/fonts/simfang.ttf",
) -> bool:
    """
    Visualize layout segmentations and OCR recognition results for a
    document page. This function will draw layout segmentation boxes and
    OCR text bounding boxes on a document page image.

    Args:
        image (cv2): A document page image.
        result (list): Layout analysis and OCR recognition results.
        output_path (str): The output path for saving all results including
        layout analysis visualizations.
        default_font_path (str, optional): The font file for texts drawed
        on the document page image.
        Defaults to
        "document_layout_segmentation/pdf_document_segmentation/fonts/simfang.ttf".

    Returns:
        bool: True is visulization result images saved successful.
        Otherwise return False.
    """

    # Visualize layout segmentations and OCR results
    BASE_PATH = Path(__file__).resolve().parent.parent
    font_path = str(BASE_PATH.joinpath(font_path))
    im_show = draw_structure_result(image, result, font_path=font_path)
    im_show = Image.fromarray(im_show)
    if output_path is not None:
        im_show.save(output_path)
        return os.path.exists(output_path)
    else:
        return False


def parsing_text_to_json(
    res: list,
    all_res: dict,
    img_idx: str,
    save_folder: Optional[str] = None,
    img_name: Optional[str] = None,
    save_fig_table=False,
) -> dict:

    """
    Return layout analysis results for a document page image.
    with option to save recongized figures(image)
    and tables(excels with tabel data)
    from the document page image.

    Args:
        res (list): Layout analysis results from the layout analysis engine.
        all_res (dict): A dictionary aggregates layout analysis
        results for all document pages.
        img_idx (str, optional): document page index.
        save_folder (str): An folder to save all results.
        img_name (str): The name of the input document.
        save_fig_table (bool, optional): Whether to save recognized
        figures and tables. Defaults to False.


    Returns:
         dict: Return layout analysis results
         for all currently prcoessed document pages.
    """
    # Save layout analysis results for each document page into JSON
    res_cp = deepcopy(res)
    all_res[img_idx] = []

    if save_folder is not None and img_name is not None:
        excel_save_folder = os.path.join(save_folder, img_name)

        with open(
            os.path.join(excel_save_folder, "res_{}.json".format(img_idx)),
            "w",
            encoding="utf8",
        ) as f:
            # Save recognized tables and figures
            for i, region in enumerate(res_cp):
                roi_img = region.pop("img")
                # Save layout analysis results in JSON format
                region_json = json.dumps(region, indent=4)
                all_res[img_idx].append(region)

                if save_fig_table:
                    f.write("{}\n".format(region_json))
                    if (
                        region["type"].lower() == "table"
                        and len(region["res"]) > 0
                        and [k for k, v in region["res"][-1].items()][0]
                        == "html"
                    ):

                        excel_path = os.path.join(
                            excel_save_folder,
                            "{}_{}.xlsx".format(
                                str(region["bbox"]).replace(" ", ""), img_idx
                            ),
                        )
                        to_excel(region["res"][-1]["html"], excel_path)

                    elif region["type"].lower() == "figure":
                        img_path = os.path.join(
                            excel_save_folder,
                            "{}_{}.jpg".format(
                                str(region["bbox"]).replace(" ", ""), img_idx
                            ),
                        )
                        cv2.imwrite(img_path, roi_img)
    else:

        for i, region in enumerate(res_cp):
            region.pop("img")
            # Save layout analysis results in JSON format
            all_res[img_idx].append(region)

    return all_res
