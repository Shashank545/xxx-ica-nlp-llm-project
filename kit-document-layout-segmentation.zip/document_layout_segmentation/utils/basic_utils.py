""" Utilities functions """
import json
import os


def save_json(data: dict, save_path: str, filename: str) -> bool:
    """
    Function to Save the JSON as a file

    Args:
            data: The JSON dictionary
            save_path: The path where the JSON file is to
                       be saved.
            filename: The name of the file
    Returns:
        The return value. True for success, False otherwise.
    """
    with open(
        os.path.join(save_path, "{}.json".format(filename)), "w"
    ) as outfile:
        json.dump(data, outfile, indent=2)
    return True
