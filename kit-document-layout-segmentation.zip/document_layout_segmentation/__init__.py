from importlib.metadata import version

__version__ = version("kit-document-layout-segmentation")

__all__: list = [
    "pdf_document_segmentation",
    "word_document_segmentation",
    "utils",
]

from .pdf_document_segmentation import *
from .utils.basic_utils import *
from .word_document_segmentation import *
