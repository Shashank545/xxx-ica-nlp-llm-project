from .docx_segmentation import word_segmentation
from .supporting_utils import *
