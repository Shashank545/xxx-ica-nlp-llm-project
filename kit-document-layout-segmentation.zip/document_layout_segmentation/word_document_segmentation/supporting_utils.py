""" Utility file for word document segmentation """
import re
import xml.dom.minidom
import xml.etree.ElementTree
import zipfile


def pretty_xml(name: str, document: zipfile.ZipFile) -> str:
    """
    Function to prettyfy the XML from Word

    Args:
        name: name of the input document namelist Example: "word/document.xml"
        document: The zipfile.Zipfile object

    Returns:
        str: The xml data for the particular document variable
    """

    ugly_xml = xml.dom.minidom.parseString(
        document.read(name=name)
    ).toprettyxml(indent="  ")

    text_re = re.compile(r">\n\s+([^<>\s].*?)\n\s+", re.DOTALL)
    pretty_xml_data = text_re.sub(r">\g<1>", ugly_xml)

    return pretty_xml_data


def hf_parser_one(
    dict_: xml.etree.ElementTree.Element,
    hf: str,
    header_dict: dict,
    footer_dict: dict,
    h_count: int,
    f_count: int,
) -> tuple:
    """
    Header Footer parser helper

    Args:
        dict_: Dictionary part for parsing xml data and convertin
         it in dictionary
        hf: The datalist from the xml. eg: "word/document.xml"
        header_dict: Dictionary for storing header items.
        footer_dict: Dictionary for storing footer items.
        h_count: The integer count for the header items.
        f_count: The integer count for the footer items.

    Returns:
        dict: The combined dictionary for header and footer

    """

    for tabl_para in dict_:
        if tabl_para.tag.endswith("}ins"):
            for tabl_para_subtext in tabl_para:
                if tabl_para_subtext.tag.endswith("}r"):
                    for para_item in tabl_para_subtext:
                        if para_item.tag.endswith(
                            "}t"
                        ) or para_item.tag.endswith("}instrText"):
                            if (
                                len(para_item.attrib) != 0
                                and para_item.text is not None
                            ):
                                if hf.startswith("word/footer"):
                                    footer_dict[
                                        "footer_{}".format(f_count)
                                    ] = para_item.text
                                    f_count += 1
                                elif hf.startswith("word/header"):
                                    header_dict[
                                        "header_{}".format(h_count)
                                    ] = para_item.text
                                    h_count += 1
        elif tabl_para.tag.endswith("}r"):
            for para_item in tabl_para:
                if para_item.tag.endswith("}t") or para_item.tag.endswith(
                    "}instrText"
                ):
                    if hf.startswith("word/footer"):
                        footer_dict[
                            "footer_{}".format(f_count)
                        ] = para_item.text
                        f_count += 1
                    elif hf.startswith("word/header"):
                        header_dict[
                            "header_{}".format(h_count)
                        ] = para_item.text
                        h_count += 1

    return header_dict, footer_dict, h_count, f_count


def table_parser(
    main_dict: dict,
    dict_: xml.etree.ElementTree.Element,
    table_count: int,
):
    """
    Table parser helper

    Args:
        main_dict: Main updated dictionary
        dict_: Dictionary part for parsing xml data and convertin
         it in dictionary
        table_count: Integer table count to define table number

    Returns:
        dict: The updated dictionary for tables

    """
    main_dict["Table_{}".format(table_count)] = {}

    row_count = 0
    for table_ in dict_:
        if table_.tag.endswith("}tr"):
            main_dict["Table_{}".format(table_count)][
                "row_{}".format(row_count)
            ] = {}
            column_count = 0

            for table_info in table_:
                table_text = ""
                for table_sub_info in table_info:
                    if table_sub_info.tag.endswith("}p"):
                        for table_value_tag in table_sub_info:
                            if table_value_tag.tag.endswith("}ins"):
                                for ins in table_value_tag:
                                    if ins.tag.endswith("}r"):
                                        for ins_text in ins:
                                            if ins_text.tag.endswith("}t"):
                                                if ins_text.text is not None:
                                                    table_text = (
                                                        table_text
                                                        + ins_text.text
                                                    )

                            elif table_value_tag.tag.endswith("}r"):
                                for table_text_tag in table_value_tag:
                                    if table_text_tag.tag.endswith("}t"):
                                        if table_text_tag.text is not None:
                                            table_text = (
                                                table_text + table_text_tag.text
                                            )

                            main_dict["Table_{}".format(table_count)][
                                "row_{}".format(row_count)
                            ]["column_{}".format(column_count)] = table_text
                    elif table_sub_info.tag.endswith("}tbl"):
                        main_dict = table_parser(
                            main_dict, table_sub_info, table_count
                        )
                if table_info.tag.endswith("}tc"):
                    column_count += 1
            row_count += 1
    return main_dict
