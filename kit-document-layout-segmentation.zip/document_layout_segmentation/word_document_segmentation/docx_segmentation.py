""" Module to convert Word file to JSON """
import xml.etree.ElementTree as ET
import zipfile
from io import BytesIO
from typing import Optional

from .supporting_utils import hf_parser_one, pretty_xml, table_parser


def word_segmentation(file_bytes: BytesIO) -> dict:  # noqa: C901
    """
    Function to extract information from Word file
    and converting that to JSON

    Args:
        file_bytes: Input docx file as bytes.

    Returns:
        dict: Final JSON data which is converted from a docx file
    """
    document = None

    try:
        document = zipfile.ZipFile(file_bytes)

        root = ET.fromstring(pretty_xml("word/document.xml", document))
        header_dict: dict = {}
        footer_dict: dict = {}
        data_dict = {}
        main_dict: dict = {}
        header_count, footer_count, count, drawing_count, table_count = (
            0,
            0,
            0,
            0,
            0,
        )
        font_, fontsize_, fontcolor_ = None, None, None
        paragraph_text: Optional[str]

        # For header and footer
        for hf in document.namelist():
            if hf.startswith("word/footer") or hf.startswith("word/header"):
                xml_data = pretty_xml(hf, document)
                root_hf = ET.fromstring(xml_data)
                for item in root_hf:
                    if item.tag.endswith("}tbl"):
                        for item_tbl in item:
                            if item_tbl.tag.endswith("}tr"):
                                for tabl_text in item_tbl:
                                    if tabl_text.tag.endswith("}tc"):
                                        for tabl_subtext in tabl_text:
                                            if tabl_subtext.tag.endswith("}p"):
                                                (
                                                    header_dict,
                                                    footer_dict,
                                                    header_count,
                                                    footer_count,
                                                ) = hf_parser_one(
                                                    tabl_subtext,
                                                    hf,
                                                    header_dict,
                                                    footer_dict,
                                                    header_count,
                                                    footer_count,
                                                )

                    elif item.tag.endswith("}p"):
                        for sub_item in item:
                            if sub_item.tag.endswith("}r"):
                                for hf_para in sub_item:
                                    if (
                                        len(hf_para.attrib) != 0
                                        and hf_para.text is not None
                                    ):
                                        if hf.startswith("word/footer"):
                                            footer_dict[
                                                "footer_{}".format(footer_count)
                                            ] = hf_para.text
                                            footer_count += 1
                                        elif hf.startswith("word/header"):
                                            header_dict[
                                                "header_{}".format(header_count)
                                            ] = hf_para.text
                                            header_count += 1
        header_footer_dict = {"header": header_dict, "footer": footer_dict}

        # For paragraph
        for child in root:
            for sub_child in child:
                if sub_child.tag.endswith("}p"):
                    paragraph_text = ""
                    for para in sub_child:
                        if para.tag.endswith("}ins"):
                            for ins in para:
                                for subtext in ins:
                                    if subtext.tag.endswith("}t"):
                                        if subtext.text is not None:
                                            paragraph_text = (
                                                paragraph_text + subtext.text
                                            )

                        elif para.tag.endswith("}r"):
                            for sub_para in para:
                                if sub_para.tag.endswith(
                                    "}drawing"
                                ) or sub_para.tag.endswith("}AlternateContent"):
                                    main_dict[
                                        "Drawing_{}".format(str(drawing_count))
                                    ] = "Picture/SmartArt"
                                    drawing_count += 1
                                for font in sub_para:
                                    if font.tag.endswith("}rFonts"):
                                        for item_ in font.attrib.items():
                                            font_ = item_[1]
                                    if font.tag.endswith("}sz"):
                                        for item_ in font.attrib.items():
                                            fontsize_ = str(int(item_[1]) / 2)
                                    if font.tag.endswith("}color"):
                                        for item_ in font.attrib.items():
                                            if item_[0].endswith("}val"):
                                                fontcolor_ = item_[1]
                                if (
                                    sub_para.tag.endswith("}t")
                                    and sub_para.text is not None
                                ):
                                    paragraph_text = paragraph_text + sub_para.text

                    if len(paragraph_text) > 1:
                        paradict = {
                            "Text": paragraph_text,
                            "Font": font_,
                            "Font-size": fontsize_,
                            "Font-color": fontcolor_,
                        }
                        main_dict["Paragraph_{}".format(count)] = paradict
                        count += 1

                # For tables
                elif sub_child.tag.endswith("}tbl"):
                    main_dict = table_parser(main_dict, sub_child, table_count)
                    table_count += 1
        main_dict["Header_Footer"] = header_footer_dict
        data_dict["data"] = main_dict

        return data_dict
    finally:
        file_bytes.close()
        if document:
            document.close()

