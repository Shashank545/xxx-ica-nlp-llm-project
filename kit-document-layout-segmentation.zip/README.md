# KIT Document Layout Segmentation

| ⚡ Developers, Please refer to [DEVELOPMENT.md](./DEVELOPMENT.md) |
|------------------------------------------------------------------|
## Table of contents

- [Introduction](#introduction)
- [Installation](#installation)
    - [Poetry](#poetry)
    - [Conda](#conda)
- [Usage](#usage)
  - [Quick Start](#quick-start)
- [Known Issues](#known-issues)

---


## Introduction
KIT document layout segmentation library for PDF and word files.

### KIT Word Document Segmentation

- This library is used for the conversion of word to JSON.
- All the elements (paragraphs, art, drwaings, tables, headers and footers) will be converted to JSON.

### KIT PDF Document Segmentation

Given an input document in PDF, the PDF document segmentation returns a JSON file containing 
layout analysis results for all document pages. The PDF document segmentation first divides the input 
PDF document into four segments: image, text, title and table. Then OCR detection performs text detections on 
image, text and title segments, and table recognition extract data from table segments.

## Installation

### Poetry

- Add the following to `pyproject.toml`
  ```toml
    [[tool.poetry.source]]
    name = "azure"
    url = "https://pkgs.dev.azure.com/kpmgjp-prod-001/_packaging/kit-pypi/pypi/simple/"
    secondary = true
  ```

- Configuration Poetry to install dependencies from kit-pypi with your username and PAT. You have to do this only first time.
  ```shell
    poetry config http-basic.azure YOUR_USERNAME YOUR_PAT
  ```
- Add internal package.
  ```shell
    poetry add kit-document-layout-segmentation
  ```
  
### Conda
**Note:** It is recommended to have an alias `pipkit` to install azure
artifacts packages for convenience. This alias will simply instruct `pip` to
look for packages in our `kit-pypi` Azure Artifacts.

- Add followings to `~/.bashrc` or `./zshrc`
  ```shell
    alias pipkit="PIP_EXTRA_INDEX_URL=https://pkgs.dev.azure.com/kpmgjp-prod-001/_packaging/kit-pypi/pypi/simple/ pip"
  ```

- Reload the modified file or restart your terminal.
  ```shell
    source ~/.bashrc
    or
    source ~/.zshrc
  ```
- Create a virtual environment of your choice, `conda` or `virtualenv`
- Install `artifacts-keyring`
  ```shell
    pip install artifacts-keyring
  ```

- Install package from Azure Artifacts
  ```shell
    pipkit install kit-document-layout-segmentation
  ```


---

## Usage


### Word Document Segmentation
- Use the following command to import the module
```shell
  from document_layout_segmentation.word_document_segmentation import word_segmentation
```

- Call the module with following parameters:
  - file_bytes (BytesIO) --> BytesIO object of the word file.

```shell
  final_json = word_segmentation(file_bytes)
```
- This `final_json` will be the JSON data converted from the word file.

### PDF Document Segmentation

- Use the following command to import the module
  ```python
  from document_layout_segmentation.pdf_document_segmentation import layout_analysis
  ```
- Call the module with following parameters:
  - file_bytes (BytesIO): BytesIO object of the PDF file.
  - document_lang (str): This is language of document. Value that can be used are : ['ch', 'en', 'korean', 'japan', 'chinese_cht', 'ta', 'te', 'ka', 'latin', 'arabic', 'cyrillic', 'devanagari']. Default selected language is 'en'

  ```python
  result_json = layout_analysis(file_bytes, document_lang)
  ``` 
- Return
  - result_json contains layout segmentation results.

  - result_json description
  ```json
  [

      "type": "table",
      "bbox": [
          196,
          424,
          868,
          518
      ],
      "res": {
          "cell_bbox": [
              [
                  60.90325164794922,
                  8.019875526428223,
                  235.10848999023438,
                  9.24345874786377,
                  217.78700256347656,
                  35.9761848449707,
                  52.25051498413086,
                  33.63316345214844
              ],
          ......
          ],
          "html": "<html><body><table><tr><td>\u5f53\u671f\u5937</td><td>\u524d\u5e74\u5ea6\u540c\u671f</td><td>\u524d\u5e74\u5ea6\u540c\u671f\u4ea1\u306e\u6bd4\u8f83</td></tr><tr><td>5. 35%</td><td>1. 96%</td><td>3.39\u672f\u535c\u589e\u52a0</td></tr><tr><td colspan=\"3\">\u203b\u300c\u66b9\u5ef6\u4fbf\u300d\u3001 \u51fa\u4e88\u5b9a\u6642\u523b15\u5206\u8d85\u51fa\u4fbf\u3002</td></tr></table></body></html>"
      },
      "img_idx": 0
  }
  ]
  ```
  Each field in the JSON file is described as follows:

  | field | description  |
  | --- |---|
  |type| Type of image area. |
  |bbox| The coordinates of the image area in the original image, respectively [upper left corner x, upper left corner y, lower right corner x, lower right corner y]. |
  |res| OCR or table recognition result of the image area. <br> table: a dict with field descriptions as follows: <br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; `html`: html str of table.<br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; In the code usage mode, set return_ocr_result_in_table=True when call can get the detection and recognition results of each text in the table area, corresponding to the following fields: <br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; `boxes`: text detection boxes.<br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; `rec_res`: text recognition results.<br> OCR: A tuple containing the detection boxes and recognition results of each single text. |

  After the recognition is completed, each image will have a directory with the same name under the directory specified by the `output_path` field. Each table in the image will be stored as an excel, and the picture area will be cropped and saved. The filename of  excel and picture is their coordinates in the image.
    

  * Input: BytesIO object of the PDF file.
  * Output: Result JSON which would contain the layout and infromation in the file.


### Quick Start

---

### API Reference

---

## Known Issues

---