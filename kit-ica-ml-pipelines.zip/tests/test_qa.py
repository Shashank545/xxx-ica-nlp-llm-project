import asyncio
import copy
import io
import json

import openai
import pytest
from decouple import config

from ica_inference import question_answering
from tests import get_openai_client, test_config


def test_qa_pipeline():
    if config("OPENAI_API_KEY", None) is None:
        with pytest.raises(openai.APIConnectionError) as excinfo:
            qa_pipeline()
        assert "Connection error" in str(excinfo.value)
    else:
        qa_pipeline()


def qa_pipeline():
    with open("tests/resources/dummy_EL.pdf", mode="rb") as fin:
        file_buffer = io.BytesIO(fin.read())
    check_items = json.load(open("tests/resources/configs/input_v2.json", "r"))

    tokenizer_config_dict = test_config.get_tokenizer_config()
    search_config_dict = test_config.get_search_config_dict()
    qa_config_dict = test_config.get_qa_config_dict()
    openai_completion_type_config = test_config.completion_type_config
    answers = asyncio.run(
        question_answering.answer_with_evidence(
            pdf_file=file_buffer,
            check_items=copy.deepcopy(check_items),
            search_config_dict=search_config_dict,
            qa_config_dict=qa_config_dict,
            tokenizer_config_dict=tokenizer_config_dict,
            min_sent_length=15,
            min_semantic_score=0.85,
            openai_client=get_openai_client,
            openai_completion_type_config=openai_completion_type_config,
            return_token_usage=True,
        )
    )

    assert len(answers["results"]) == len(check_items)

    for answer_cnt, answer in enumerate(answers["results"]):
        # Check that the answer is valid.
        ev_req_ans = check_items[answer_cnt]["ml_config"][
            "evidence_required_answers"
        ]
        assert answer["answer"] in ev_req_ans
        retrieve = ev_req_ans[answer["answer"]]
        if retrieve:
            assert len(answer["evidences"]) > 0
        else:
            assert len(answer["evidences"]) == 0
