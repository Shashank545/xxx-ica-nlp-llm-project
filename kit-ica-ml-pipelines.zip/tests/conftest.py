import pytest


@pytest.fixture()
def el_data_paths():
    dummy_el_file = "tests/resources/dummy_EL.pdf"
    contract_nli_file = "tests/resources/contract_nli.pdf"

    return dummy_el_file, contract_nli_file


@pytest.fixture()
def evidence_results_path():
    evidence_file_path = (
        "tests/resources/expected_results/evidence_results.json"
    )

    return evidence_file_path


@pytest.fixture()
def bbox_plot_paths():
    expected_results_dir = "tests/resources/correct_annotated_images/test_2/"
    results_save_dir = "tests/resources/annotated_images/test_2/"

    return expected_results_dir, results_save_dir
