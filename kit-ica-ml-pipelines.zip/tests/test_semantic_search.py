from ica_inference import semantic_search
from tests import get_openai_client, test_config


def test_qa_search():
    documents = [
        "I play the piano.",
        "I study mathematics.",
        "I travel to India.",
    ]
    queries = ["I study physics.", "I play the violin. I love India."]

    search = {1: (0, 3, queries[0]), 2: (0, 2, queries[1])}
    min_char_len = 1

    search_config_dict = test_config.get_search_config_dict()

    search_result = semantic_search.retrieve_relevant_documents(
        search,
        search_config_dict,
        documents,
        min_char_len,
        openai_client=get_openai_client(),
    )
    assert search_result[1] == [1]
    assert search_result[2] == [0]

    # A test with document and query instructions
    query_instr = "Represent the sentence for retrieving duplicate sentences:"
    doc_instr = "Represent the sentence for retrieving duplicate sentences:"

    search_result = semantic_search.retrieve_relevant_documents(
        search,
        search_config_dict,
        documents,
        min_char_len,
        min_score=0,
        query_instruction=query_instr,
        document_instruction=doc_instr,
        openai_client=get_openai_client(),
    )

    assert search_result[1] == [1]
    assert search_result[2] == [0]
