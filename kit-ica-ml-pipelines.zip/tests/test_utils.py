import io
import json
import random
import shutil
from datetime import date

import cv2

from ica_inference import postprocessing
from ica_inference.utils import sentence_splitter
from ica_inference.utils.bbox_plotting import plot_bbox
from ica_inference.utils.common_utils import (
    layout_filter,
    pdf_char_extractor,
    two_rectangles_distance,
    windowing,
)


def test_get_evidence_coordinates(
    el_data_paths, evidence_results_path, bbox_plot_paths
):
    dummy_el_file, contract_nli_file = el_data_paths
    evidence_file_path = evidence_results_path
    expected_results_dir, results_save_dir = bbox_plot_paths
    with open(contract_nli_file, mode="rb") as fin:
        file_buffer = io.BytesIO(fin.read())
    layout = pdf_char_extractor(file_buffer)

    char_data = []
    for text_area in layout:
        char_data.extend(text_area["character-info"])

    range_tests = [
        [[11, 60]],
        [[11, 13], [15, 90]],
        [[11, 90]],
        [[11, 12]],
        [[12, 13]],
    ]

    expected_results = json.load(open(evidence_file_path))

    for count, range_test in enumerate(range_tests):
        result = postprocessing.get_evidence_coordinates(range_test, char_data)
        if len(expected_results[count]) == 0:
            assert result == []
        else:
            assert [e["locations"][0]["pagenum"] for e in result] == [
                e["locations"][0]["pagenum"] for e in expected_results[count]
            ]
            assert len(result) == len(expected_results[count])
            for idx, evidence in enumerate(result):
                result_bbox = evidence["locations"][0]["bbox"]
                expected_bbox = expected_results[count][idx]["locations"][0][
                    "bbox"
                ]
                assert (
                    max(
                        [
                            abs(expected_bbox[j] - result_bbox[j])
                            for j in range(4)
                        ]
                    )
                    < 0.01
                )

    with open(dummy_el_file, mode="rb") as fin:
        file_buffer = io.BytesIO(fin.read())
    layout = pdf_char_extractor(file_buffer)
    char_data = []
    for text_area in layout:
        char_data.extend(text_area["character-info"])

    ranges = [[0, char_data[-1][1]]]

    result = postprocessing.get_evidence_coordinates(ranges, char_data)

    # 23 annotations on the first page and
    # 15 annotations on the second page are expected.
    assert len(result[0]["locations"]) == 23
    assert len(result[1]["locations"]) == 15
    prefix = "range_0_"
    plot_bbox(
        file_buffer,
        result,
        results_save_dir,
        annotation="Check Item 1",
        prefix=prefix,
    )

    img_file_name = prefix + "page_1.jpg"
    test_image = cv2.imread(results_save_dir + img_file_name)
    correct_image = cv2.imread(expected_results_dir + img_file_name)
    assert cv2.absdiff(test_image, correct_image).max() == 0

    img_file_name = prefix + "page_2.jpg"
    test_image = cv2.imread(results_save_dir + img_file_name)
    correct_image = cv2.imread(expected_results_dir + img_file_name)
    assert cv2.absdiff(test_image, correct_image).max() == 0
    shutil.rmtree("tests/resources/annotated_images")


def test_extract_layout():
    with open("tests/resources/contract_nli.pdf", mode="rb") as fin:
        file_buffer = io.BytesIO(fin.read())
    layout = pdf_char_extractor(file_buffer)
    start = 0
    char_data = []
    for text_box in layout:
        text_range = text_box["range"]
        assert start == text_range[0]
        # The following will be the next expected start:
        start = text_range[1]
        # All boxes have the same page:
        pages = list(set(x[0] for x in text_box["character-info"]))
        assert len(pages) == 1
        assert pages[0] == text_box["pagenum"]
        # Check that we have all characters and
        # that they all have length one:
        indices = list(range(text_range[0], text_range[1]))
        for i, indx in enumerate(indices):
            assert text_box["character-info"][i][1] == indx
            assert len(text_box["character-info"][i][2]) == 1
        char_data.extend(text_box["character-info"])

    text = "".join([char[2] for char in char_data])
    # The first word is ContractNLI
    assert "ContractNLI" == "".join([i[2] for i in char_data[0:11]])
    # The last word is "label."
    assert "label.\n" == "".join([i[2] for i in char_data[-7:]])

    footnote = "5https://github.com/\nhuggingface/transformers/blob/"
    indx = text.find(footnote)
    # Footnote is on page 12
    assert char_data[indx][0] == 12

    # Test for the font information in the PDF char dict
    assert (
        char_data[20][5]["Font-Information"]["font-name"]
        == "TCJZPT+NimbusRomNo9L-Medi"
    )
    assert abs(char_data[33][5]["Font-Information"]["font-size"] - 14) < 0.5


def test_two_rectangle_distance():
    rect1 = [0, 0, 3, 5]
    rect2 = [1, 2, 1.5, 2.5]
    rect3 = [1, 2, 10, 15]
    rect4 = [3, 5, 7, 9]
    rect5 = [4, 4, 5, 7]
    rect6 = [6, 9, 100, 12]
    rect7 = [2, 7, 58.5, 7.98]
    rect8 = [-2, 6, -1, 10.234]

    # Test all if statements of two_rectangles_distance
    assert two_rectangles_distance(rect1, rect2) == 0
    assert two_rectangles_distance(rect1, rect3) == 0
    assert two_rectangles_distance(rect1, rect4) == 0
    assert two_rectangles_distance(rect1, rect5) == 1
    assert two_rectangles_distance(rect1, rect6) == 5
    assert two_rectangles_distance(rect1, rect7) == 2
    assert two_rectangles_distance(rect7, rect1) == 2
    assert two_rectangles_distance(rect6, rect1) == 5
    assert two_rectangles_distance(rect5, rect1) == 1
    assert abs(two_rectangles_distance(rect1, rect8) - 2**0.5) < 0.001
    assert abs(two_rectangles_distance(rect8, rect1) - 2**0.5) < 0.001


def test_filter():
    with open("tests/resources/contract_nli.pdf", mode="rb") as fin:
        file_buffer = io.BytesIO(fin.read())
    layout = pdf_char_extractor(file_buffer)

    #####################################
    # Header Tests
    # If the header bound is too low all boxes will be filtered out.
    norm_upper_bound = 0.0001
    indices = layout_filter(layout=layout, norm_upper_bound=norm_upper_bound)
    assert indices == []
    indices = layout_filter(
        layout=layout, norm_upper_bound=norm_upper_bound, apply_all=True
    )
    assert indices == []
    # If the header bound is too high no boxes will be filtered out.
    norm_upper_bound = 0.9999
    indices = layout_filter(layout=layout, norm_upper_bound=norm_upper_bound)
    assert indices == list(range(len(layout)))
    indices = layout_filter(
        layout=layout, norm_upper_bound=norm_upper_bound, apply_all=True
    )
    assert indices == list(range(len(layout)))

    #####################################
    # Footnote Tests
    # If the footnote bound is too high all boxes will be filtered out.
    norm_lower_bound = 0.9999
    indices = layout_filter(layout=layout, norm_lower_bound=norm_lower_bound)
    assert indices == []
    indices = layout_filter(
        layout=layout, norm_lower_bound=norm_lower_bound, apply_all=True
    )
    assert indices == []
    # If the footnote bound is too low no boxes will be filtered out.
    norm_lower_bound = 0.0001
    indices = layout_filter(layout=layout, norm_lower_bound=norm_lower_bound)
    assert indices == list(range(len(layout)))
    indices = layout_filter(
        layout=layout, norm_lower_bound=norm_lower_bound, apply_all=True
    )
    assert indices == list(range(len(layout)))

    #####################################
    # Font Size Tests
    # If the size is too high all boxes will be filtered out.
    font_size = 100
    indices = layout_filter(layout=layout, font_size=font_size)
    assert indices == []
    indices = layout_filter(layout=layout, font_size=font_size, apply_all=True)
    assert indices == []
    # If the size is too low no boxes will be filtered out.
    font_size = 0.001
    indices = layout_filter(layout=layout, font_size=font_size)
    assert indices == list(range(len(layout)))
    indices = layout_filter(layout=layout, font_size=font_size, apply_all=True)
    assert indices == list(range(len(layout)))

    #####################################
    # Font Percentile Tests
    # If the percentile is maximum only boxes
    # with font size closed to the maximum font
    # size will not be filtered out.
    font_perc = 100
    indices1 = layout_filter(layout=layout, font_perc=font_perc)
    indices2 = layout_filter(layout=layout, font_perc=font_perc, apply_all=True)
    assert indices1 == indices2
    pages_n = layout[-1]["pagenum"]
    for page in range(1, pages_n + 1):
        same_page_items = [
            x for x in enumerate(layout) if x[1]["pagenum"] == page
        ]
        large_fonts = []
        small_fonts = []
        for indx, item in same_page_items:
            char_font_sizes = [
                char[5]["Font-Information"]["font-size"]
                for char in item["character-info"]
                if char[5]["Font-Information"]["font-size"] is not None
            ]
            if indx in indices1:
                large_fonts.append(max(char_font_sizes))
            else:
                small_fonts.append(max(char_font_sizes))

        assert max(small_fonts) <= min(large_fonts)
        assert max(large_fonts) - min(large_fonts) < 1
    # If the percentile is too low no boxes will be filtered out.
    font_perc = 0.0001
    indices = layout_filter(layout=layout, font_perc=font_perc)
    assert indices == list(range(len(layout)))
    indices = layout_filter(layout=layout, font_perc=font_perc, apply_all=True)
    assert indices == list(range(len(layout)))

    #####################################
    # Distace Tests
    # If the distance threshold is too low,
    # only contiguous boxes will not be filtered out.
    dist_diag_coeff = 0.000001
    indices1 = layout_filter(layout=layout, dist_diag_coeff=dist_diag_coeff)
    indices2 = layout_filter(
        layout=layout, dist_diag_coeff=dist_diag_coeff, apply_all=True
    )
    assert indices1 == indices2
    for indx1 in indices1:
        diag_x = layout[indx1]["page-dimension"][2]
        diag_y = layout[indx1]["page-dimension"][3]
        distance = dist_diag_coeff * (diag_x**2 + diag_y**2) ** 0.5
        distances = []
        for indx2 in indices2:
            if (
                indx1 != indx2
                and layout[indx2]["pagenum"] == layout[indx1]["pagenum"]
            ):
                rect1 = layout[indx1]["bbox"]
                rect2 = layout[indx2]["bbox"]
                distances.append(two_rectangles_distance(rect1, rect2))
        assert min(distances) < distance

    # If the distance threshold is too high no boxes will be filtered out.
    dist_diag_coeff = 0.9999
    indices = layout_filter(layout=layout, dist_diag_coeff=dist_diag_coeff)
    assert indices == list(range(len(layout)))
    indices = layout_filter(
        layout=layout, dist_diag_coeff=dist_diag_coeff, apply_all=True
    )
    assert indices == list(range(len(layout)))

    #####################################
    # Horizontal Tests
    # If only_horizontal is False, then no
    # box is filtered out
    only_horizontal = False
    indices = layout_filter(layout=layout, only_horizontal=only_horizontal)
    assert indices == list(range(len(layout)))
    indices = layout_filter(
        layout=layout, only_horizontal=only_horizontal, apply_all=True
    )
    assert indices == list(range(len(layout)))
    # If only_horizontal is True, let's
    # extract manually the boxes that have at least
    # one horizontal character.
    only_horizontal = True
    expected_indices = []
    for indx, item in enumerate(layout):
        for char in item["character-info"]:
            char_matrix = char[5]["Font-Information"]["rotation-matrix"]
            if char_matrix is not None and char_matrix == [1, 0, 0, 1]:
                expected_indices.append(indx)
                break
    indices = layout_filter(layout=layout, only_horizontal=only_horizontal)
    assert indices == expected_indices
    indices = layout_filter(
        layout=layout, only_horizontal=only_horizontal, apply_all=True
    )
    assert indices == expected_indices


def test_sentence_splitter():
    # Test Trankit sentence segmentation
    text = "I am a data scientist. I am working in Japan."
    sentences = sentence_splitter.trankit_sentence_splitting(text)
    assert len(sentences) == 2
    assert sentences[0] == "I am a data scientist."
    assert sentences[1] == "I am working in Japan."
    with open("tests/resources/sample_text.txt", mode="r") as f:
        text = f.read()
    sentences = sentence_splitter.trankit_sentence_splitting(text)
    assert len(sentences) == 1

    # Text Sentence Alignment to Text
    text = "I am a data scientist.\n  \n   \nI am working in Japan."
    sentences = sentence_splitter.trankit_sentence_splitting(text)
    assert len(sentences) == 2
    assert sentences[0] == "I am a data scientist."
    assert sentences[1] == "I am working in Japan."
    adjusted_sentences = sentence_splitter.align_sentences_to_text(
        text, sentences
    )
    assert sentences[0] in adjusted_sentences[0]
    assert sentences[1] in adjusted_sentences[1]
    assert text == "".join(adjusted_sentences)


def test_windowing():
    window_max_sum = 50
    overlap_max_sum = 20
    seed = int(
        str(date.today().year) + str(date.today().month) + str(date.today().day)
    )
    random.seed(seed)
    for L in range(1, 500):
        integers = [random.randint(1, 501) for i in range(L)]
        r = windowing(integers, window_max_sum, overlap_max_sum)
        assert r[0][0] == 0
        assert r[-1][1] == L
        for i in range(len(r) - 1):
            assert r[i][0] < r[i + 1][0]
            assert r[i + 1][0] <= r[i][1]
            assert r[i][1] < r[i + 1][1]
            if r[i][1] - r[i][0] > 1:
                sum(integers[r[i][0] : r[i][1]]) <= window_max_sum
                if r[i][1] < L:
                    sum(integers[r[i][0] : r[i][1] + 1]) > window_max_sum
            else:
                sum(integers[r[i][0] : r[i][1] + 1]) > window_max_sum
            if r[i][1] - r[i + 1][0] > 1:
                assert sum(integers[r[i + 1][0] : r[i][1]]) <= overlap_max_sum
