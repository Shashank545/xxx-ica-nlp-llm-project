import asyncio

import openai
import pytest

# import torch
from decouple import config

from ica_inference import model_call
from tests import get_openai_client

# from ica_inference.model_call import call_completion
# from tests import test_config


def test_openai_calls():
    if config("OPENAI_API_KEY", None) is None:
        with pytest.raises(openai.APIConnectionError) as excinfo:
            openai_call()
        assert "Connection error" in str(excinfo.value)
    else:
        openai_call()


def openai_call():
    model = {
        "type": "OpenAI / Embeddings",
        "inference_batch_size": 10,
        "ada_deployment_name": "text-embedding-ada-002",
    }
    params = {
        "documents": [
            "I love to eat chocolate.",
            "I do not want to go hiking.",
            "I play basketball.",
        ],
        "queries": ["What do I love?", "What do you play?"],
    }
    output = asyncio.run(
        model_call.call_openai_search(get_openai_client(), model, params)
    )
    scores = output["scores"]
    assert output["token_usage"] == 28
    assert scores.shape == (3, 2)
    assert output["scores"][0, 0] > output["scores"][0, 1]

    model = {
        "name": "azure openai",
        "type": "OpenAI / Completion",
        "call_method": "azure_resource",
        "completion_batch_size": 20,
        "chat_completion_batch_size": 100,
        "max_output_tokens": 200,
        "chat_batch_size": 1,
        "temperature": 0,
        "top_p": 0.95,
        "frequency_penalty": 0,
        "presence_penalty": 0,
    }
    sys_message = "You are an AI assistant that helps people find information."
    sys_dict = {"role": "system", "content": sys_message}
    prompts = [
        "I am tired beacuse",
        [sys_dict, {"role": "user", "content": "10*20"}],
        [sys_dict, {"role": "user", "content": "Hello"}],
        [sys_dict, {"role": "user", "content": "(n+1)/n for n large"}],
        [sys_dict, {"role": "user", "content": "(n+1)/n for n large"}],
        "What does cool mean?",
    ]
    model_deployments = [
        "gpt-35-turbo-instruct",
        "gpt-4",
        "gpt-35-turbo-0613",
        "gpt-35-turbo-0613",
        "gpt-4",
        "gpt-35-turbo-instruct",
    ]
    completion_type_dict = {
        "gpt-35-turbo-0613": "openai_chat_completion",
        "gpt-35-turbo-instruct": "openai_completion",
        "gpt-4": "openai_chat_completion",
    }
    params = {
        "model_deployment": model_deployments,
        "max_tokens": 7,
        "prompts": prompts,
    }
    output = asyncio.run(
        model_call.call_openai_completion(
            get_openai_client(), model, params, completion_type_dict
        )
    )
    expected_answers = [
        " I am not getting enough sleep\n\n",
        "10 multiplied by 20 equals ",
        "Hello! How can I assist you",
        "As n approaches infinity, the expression",
        "As n approaches infinity (i.e",
        "\n\nCool can have several meanings,",
    ]
    assert len(output["completions"]) == 6
    for count in range(6):
        assert output["completions"][count] == expected_answers[count]

    assert output["completions"][5] == expected_answers[5]


# def test_flan_t5_call():
#     params = {
#         "prompts": [
#             "Are you fine?",
#             "Read this and answer the question. If the question is "
#             + 'unanswerable, say "unanswerable". How old am I?',
#         ],
#         "max_tokens": 2,
#         "tokens_n": 32128,
#         # Keep only "yes" (4273), "no" (150), "Yes" (2163), "No" (465),
#         # and "un"(answerable) (73).
#         "suppress_tokens": [
#             x for x in range(32128) if x not in [0, 73, 150, 2163, 4273]
#         ],
#     }
#
#     qa_config_dict = test_config.get_qa_config_dict()
#
#     output = call_completion(qa_config_dict, params)
#     assert output["completions"][0] == "no"
#     assert output["completions"][1] == "un"
#     assert output["probs"].shape == (2, 5)
#     probs_sum = torch.sum(output["probs"], dim=1)
#     assert probs_sum.shape == torch.Size([2])
#     assert abs(probs_sum[0].item() - 1) < 0.0001
#     assert abs(probs_sum[1].item() - 1) < 0.0001
