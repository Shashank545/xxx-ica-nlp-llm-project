import httpx
from decouple import config
from openai import AsyncAzureOpenAI

from ica_inference.model_call import load_models_for_inference_service
from ica_inference.model_config import ModelsConfig

test_config = ModelsConfig.load_config_from_yaml(
    "tests/resources/configs/model_configs.yaml"
)
load_models_for_inference_service(test_config)

OPENAI_API_KEY = config("OPENAI_API_KEY", "test-fake-key")
OPENAI_API_BASE = config(
    "OPENAI_API_BASE", "https://fake_test.openai.azure.com/"
)
OPENAI_API_VERSION = config("OPENAI_API_VERSION", "2023-07-01-preview")


def get_openai_client() -> AsyncAzureOpenAI:
    """
    Create Azure OpenAI Async Client.

    Returns:
        AsyncAzureOpenAI: Azure OpenAI Async Client.

    """
    openai_client = AsyncAzureOpenAI(
        api_key=OPENAI_API_KEY,
        api_version=OPENAI_API_VERSION,
        azure_endpoint=OPENAI_API_BASE,
        timeout=httpx.Timeout(600.0, read=10.0, write=10.0, connect=10.0),
        max_retries=3,
    )
    return openai_client
