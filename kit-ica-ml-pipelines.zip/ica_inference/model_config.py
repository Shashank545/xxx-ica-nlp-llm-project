import json
import os

import torch
import yaml

from . import utils_logger_log_level
from .utils.logger import Logger

logger = Logger("UtilsLogger", utils_logger_log_level)

# Define the file path relative to the current directory
DEFAULT_CONFIG_FILE_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "model_configs.yaml"
)


class CudaUnavailableException(Exception):
    pass


class ModelsConfig:
    class ModelConfigObj:
        """
        Class to hold all possible parameters for a model.
        """

        def __init__(self, config_dict: dict, running_mode: str):
            self.running_mode = running_mode
            self.name = config_dict.get("name")
            self.model_type = config_dict.get("type")
            self.model_class = config_dict.get("class")
            self.call_method = config_dict.get("call_method")
            self.device = config_dict.get("device")
            self.type = config_dict.get("type")
            self.inference_batch_size = config_dict.get("inference_batch_size")
            self.path = config_dict.get("path")

        def model(self):
            """
            This class passes whatever is needed for the model to load in the
            ML-framework load_model methods.
            """
            if self.running_mode == "cloud":
                return self.path
            else:
                return self.name

    def __init__(self):
        self.model_zoo = None
        self.model_config = None
        self.prompt_tokenization_config = None
        self.question_answering_config = None
        self.search_model_config = None
        self.trankit_model_config = None
        self.mode = None
        self.completion_type_config = None

    @classmethod
    def load_config_from_yaml(
        cls, model_configs_yaml_path: str = DEFAULT_CONFIG_FILE_PATH
    ):
        """
        Since this class is a singleton, calling this method on a new YAML-file
        will overwrite the default settings.

        Raises:
            CudaUnavailableException: If cuda is not available &
            EXIT_IF_CUDA_NOT_AVAILABLE is set to true.

        Args:
            model_configs_yaml_path: Path to model settings YAML-file.
        """
        models_config_obj = cls()

        with open(model_configs_yaml_path, "r") as file:
            model_configs = yaml.safe_load(file)["modelConfig"]

        device = "cuda" if torch.cuda.is_available() else "cpu"
        mode = model_configs["mode"]
        force_use = model_configs["forceUse"]
        force_use_mode = model_configs["forceUseMode"]
        cpu_models_selection = model_configs["cpu"]
        gpu_models_selection = model_configs["gpu"]
        model_zoo = model_configs["modelZoo"]
        completion_type_config = model_configs["CompletionTypeDict"]
        raise_exc_if_cuda_not_available_env = os.getenv(
            "EXIT_IF_CUDA_NOT_AVAILABLE"
        )

        if (
            raise_exc_if_cuda_not_available_env is not None
            and raise_exc_if_cuda_not_available_env not in ["true", "false"]
        ):
            raise TypeError(
                "Env-variable EXIT_IF_CUDA_NOT_AVAILABLE "
                "can only be true or false"
            )
        if not isinstance(force_use, bool):
            raise TypeError(
                "Force use option in config file must be false or true"
            )

        raise_exc = (
            True if raise_exc_if_cuda_not_available_env == "true" else False
        )

        logger.info("Starting config loading process")
        logger.info(f"Running mode of " f"setting file: {mode}")
        logger.info(
            f"Will raise exception if " f"cuda is not available: {raise_exc}"
        )
        logger.info(
            f"Cuda is available: {torch.cuda.is_available()} - "
            f"Will run with device: {device}"
        )
        logger.info(
            f"CPU model selection from loaded "
            f"settings: {json.dumps(cpu_models_selection, indent=4)}"
        )
        logger.info(
            f"GPU model selection from loaded "
            f"settings: {json.dumps(gpu_models_selection, indent=4)}"
        )

        models_selection = {}

        if raise_exc and device != "cuda":
            raise CudaUnavailableException(
                "Cuda is not available - No settings were set"
            )

        # Force usage of model selection
        # or go after whether GPU is available or not.
        if force_use and force_use_mode == "cpu":
            logger.info("Model selection - Will force usage of CPU models")
            models_selection = cpu_models_selection
        elif force_use and force_use_mode == "gpu":
            logger.info("Model selection - Will force usage of GPU models")
            models_selection = gpu_models_selection
        elif device == "cuda":
            logger.info(
                "Model selection - "
                "Will use GPU models since cuda is available"
            )
            models_selection = gpu_models_selection
        elif device == "cpu":
            logger.info(
                "Model selection - "
                "Will use CPU models since cuda is not available"
            )
            models_selection = cpu_models_selection

        logger.info(
            f"Will use the following "
            f"model selection: {json.dumps(models_selection, indent=4)}"
        )

        models_config_obj.model_config = models_selection
        models_config_obj.model_zoo = model_zoo
        # Completion Type config for Azure OpenAI completion models
        models_config_obj.completion_type_config = completion_type_config
        # Get config dict of each model.
        trankit_model_config = model_zoo[models_selection["trankit"]]
        search_model_config = model_zoo[models_selection["search"]]
        prompt_tokenization_model_config = model_zoo[
            models_selection["prompt_tokenization"]
        ]
        question_answering_model_config = model_zoo[
            models_selection["question_answering"]
        ]

        # Create config object of all models.
        models_config_obj.trankit_model_config = ModelsConfig.ModelConfigObj(
            trankit_model_config, mode
        )
        models_config_obj.search_model_config = ModelsConfig.ModelConfigObj(
            search_model_config, mode
        )
        models_config_obj.prompt_tokenization_config = (
            ModelsConfig.ModelConfigObj(prompt_tokenization_model_config, mode)
        )
        models_config_obj.question_answering_config = (
            ModelsConfig.ModelConfigObj(question_answering_model_config, mode)
        )
        models_config_obj.mode = mode

        return models_config_obj

    def get_tokenizer_config(self):
        """
        Get the dict with the specific model settings
        from the config YAML-file.

        Returns: dict
        """
        model_zoo_id_num = self.model_config["prompt_tokenization"]
        return self.model_zoo[model_zoo_id_num]

    def get_search_config_dict(self):
        """
        Get the dict with the specific model settings
        from the config YAML-file.

        Returns: dict
        """
        model_zoo_id_num = self.model_config["search"]
        return self.model_zoo[model_zoo_id_num]

    def get_qa_config_dict(self):
        """
        Get the dict with the specific model settings
        from the config YAML-file.

        Returns: dict
        """
        model_zoo_id_num = self.model_config["question_answering"]
        return self.model_zoo[model_zoo_id_num]

    def get_prompt_builder_name(self):
        """
        Get the name from the specific model settings
        in the config YAML-file.

        Returns: str
        """
        model_zoo_id_num = self.model_config["question_answering"]
        return self.model_zoo[model_zoo_id_num]["name"]

    def override_trankit_model_config(self, config_dict: dict):
        """
        Method to just override the Trankit model config.

        See the class of ModelConfigObj for what fields model configs can have,
        and just pass a dict with the matching key/val of your new config.

        Args:
            config_dict: Dict with model settings.
        """
        self.trankit_model_config = ModelsConfig.ModelConfigObj(
            config_dict, self.mode
        )

    def override_search_model_config(self, config_dict: dict):
        """
        Method to just override the Search model config.

        See the class of ModelConfigObj for what fields model configs can have,
        and just pass a dict with the matching key/val of your new config.

        Args:
            config_dict: Dict with model settings.
        """
        self.search_model_config = ModelsConfig.ModelConfigObj(
            config_dict, self.mode
        )

    def override_prompt_tokenization_config(self, config_dict: dict):
        """
        Method to just override the Prompt Tokenization model config.

        See the class of ModelConfigObj for what fields model configs can have,
        and just pass a dict with the matching key/val of your new config.

        Args:
            config_dict: Dict with model settings.
        """
        self.search_model_config = ModelsConfig.ModelConfigObj(
            config_dict, self.mode
        )

    def override_question_answering_config(self, config_dict: dict):
        """
        Method to just override the QA model config.

        See the class of ModelConfigObj for what fields model configs can have,
        and just pass a dict with the matching key/val of your new config.

        Args:
            config_dict: Dict with model settings.
        """
        self.question_answering_config = ModelsConfig.ModelConfigObj(
            config_dict, self.mode
        )

    def override_completion_type_config(self, config: dict):
        """
        Override model config with new completion type config
        Args:
            config(dict): Full model config with new completion type config key
                    and values.

        Returns:
            None

        """
        self.completion_type_config = ModelsConfig.ModelConfigObj(
            config, self.mode
        )
