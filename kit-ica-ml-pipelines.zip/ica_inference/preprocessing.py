import logging
from io import BytesIO

import numpy as np

from . import utils_logger_log_level
from .model_call import call_tokenizer
from .utils.common_utils import (
    layout_filter,
    normalize_whitespaces,
    pdf_char_extractor,
    windowing,
)
from .utils.logger import Logger
from .utils.sentence_splitter import (
    align_sentences_to_text,
    trankit_sentence_splitting,
)

logger = Logger("UtilsLogger", utils_logger_log_level)


def process_sentences(sentences: list) -> list:
    """
    Function for processing (i.e. cleaning) sentences.

    Args:
        sentences: List of sentences (str).

    Returns:
        list: List of processed sentences.
    """
    try:
        return [normalize_whitespaces(s) for s in sentences]
    except Exception as ex:
        logging.exception(ex)
        raise ex


def preprocess(file_bytes: BytesIO, tokenizer_config_dict: dict) -> dict:
    """
    Function to preprocess the text of a machine readable PDF.

    Args:
        file_bytes: Input PDF file as bytes.

    Returns:
        dict: Characters coordinates and ranges of filtered text.

    """
    try:
        logger.info("Preprocessing the machine readable PDF text")
        layout = pdf_char_extractor(file_bytes)
        filtered_boxes_indices = layout_filter(
            layout,
            norm_upper_bound=0.90,
            norm_lower_bound=0.10,
            font_perc=10,
            only_horizontal=True,
            apply_all=True,
        )
        char_data: list = []
        text: str = ""
        if filtered_boxes_indices is not None:
            for indx in filtered_boxes_indices:
                char_data.extend(layout[indx]["character-info"])
                text += "".join([x[2] for x in layout[indx]["character-info"]])

        sentences = trankit_sentence_splitting(text)
        sentences = align_sentences_to_text(text, sentences)
        cum_text_length = np.cumsum([len(s) for s in sentences])
        processed_sentences = process_sentences(sentences)
        params: dict = {"texts": processed_sentences}

        output = call_tokenizer(tokenizer_config_dict, params)

        token_lengths = [len(s) for s in output["token_ids"]]
        windows = windowing(token_lengths, 50, 0)

        preprocessed_text_info = {
            "layout": layout,
            "filtered_boxes_indices": filtered_boxes_indices,
            "char_data": char_data,
            "text": text,
            "sentences": sentences,
            "cum_text_length": cum_text_length,
            "processed_sentences": processed_sentences,
            "windows": windows,
        }
        return preprocessed_text_info

    except Exception as ex:
        logger.exception(ex)
        raise ex
