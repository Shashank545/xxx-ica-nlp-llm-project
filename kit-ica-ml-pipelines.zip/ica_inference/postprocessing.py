from . import utils_logger_log_level
from .utils.common_utils import get_plotting_bbox, group_by_line
from .utils.data_structures import Evidence, Location
from .utils.logger import Logger

logger = Logger("UtilsLogger", utils_logger_log_level)


def group_evidences(evidences: list) -> list:
    """
    Group evidences by locations.

    Args:
        evidences: List of dictionaries of evidence locations.

    Returns: List of dictionaries of evidence locations grouped by locations.
    """
    # If no evidences, return empty list
    if not evidences:
        return evidences
    # If there is single evidence location, no need to group.
    if len(evidences) == 1:
        return [Location([evidences[0]]).__dict__]

    # Sort evidences by pagenum and line_id
    evidences = sorted(evidences, key=lambda x: (x["pagenum"], x["line_id"]))
    grouped_evidences = []
    current_evidence_group: list = []

    for evidence_location in evidences:
        # If current evidence group list is empty, add evidence_location
        if not current_evidence_group:
            current_evidence_group.append(evidence_location)
        else:
            # Get previous evidence location
            prev_item = current_evidence_group[-1]
            # Check if page number is same and line ids are continuous
            if (
                evidence_location["pagenum"] == prev_item["pagenum"]
                and evidence_location["line_id"] == prev_item["line_id"] + 1
            ):
                current_evidence_group.append(evidence_location)
            else:
                grouped_evidences.append(
                    Location(current_evidence_group).__dict__
                )
                current_evidence_group = [evidence_location]

    # Add the last group
    if current_evidence_group:
        grouped_evidences.append(Location(current_evidence_group).__dict__)

    return grouped_evidences


def get_evidence_coordinates(
    ranges: list, char_data: list, strip: bool = False
) -> list[dict]:
    """
    Function to find the coordinates of the evidence in the PDF file.

    Args:
        ranges: List of ranges in PDF where the evidence is present.
        char_data: List with coordinates values for each character of the
            text extracted from the PDF.
        strip: Whether to start and the evidence on a character or not.

    Returns:
        list[dict]: List of dictionary with key-value pairs for the page number,
        the text and the coordinates of evidence.
    """
    try:
        logger.info("Getting coordinates of evidence in PDF file")
        ranged_list = list()
        for i in ranges:
            if strip:
                text_piece = "".join(
                    [char_data[i][2] for i in range(i[0], i[1])]
                )
                start = i[0] + len(text_piece) - len(text_piece.lstrip())
                end = i[1] - len(text_piece) + len(text_piece.rstrip())
                if end - start > 0:
                    ranged_list.append(
                        [char_data[i] for i in range(start, end)]
                    )
            else:
                ranged_list.append([char_data[i] for i in range(i[0], i[1])])

        final_result_list: list[dict] = []
        for item in ranged_list:
            line_groups = group_by_line(item)
            if line_groups is None:
                continue
            for line_id in line_groups:
                char_bbox_list = [(x[2], x[3]) for x in line_groups[line_id]]
                char_list, bbox_list = map(list, zip(*char_bbox_list))
                bbox, text_str = get_plotting_bbox(bbox_list, char_list)
                text_str = "".join(
                    [x[2] for x in line_groups[line_id] if x[3][0] is not None]
                )
                if bbox is not None:
                    page_n = line_groups[line_id][0][0]
                    final_result_list.append(
                        Evidence(page_n, bbox, text_str, line_id).__dict__
                    )
        return group_evidences(final_result_list)
    except Exception as ex:
        logger.exception(ex)
        raise ex
