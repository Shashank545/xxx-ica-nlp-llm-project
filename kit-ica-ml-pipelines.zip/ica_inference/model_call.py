from __future__ import annotations

import os
from operator import itemgetter

import tiktoken
import torch
from InstructorEmbedding import INSTRUCTOR
from openai import AsyncAzureOpenAI
from sentence_transformers import SentenceTransformer, util
from trankit import Pipeline
from transformers import (
    AutoModelForSeq2SeqLM,
    AutoTokenizer,
    T5ForConditionalGeneration,
)

from . import utils_logger_log_level
from .model_config import ModelsConfig
from .utils.logger import Logger
from .utils.openai_utils import (
    create_embedding_with_openai,
    openai_chat_completion,
)

logger = Logger("UtilsLogger", utils_logger_log_level)

os.environ["TOKENIZERS_PARALLELISM"] = "true"
ModelClassDict = {
    "AutoModelForSeq2SeqLM": AutoModelForSeq2SeqLM,
    "INSTRUCTOR": INSTRUCTOR,
    "SentenceTransformer": SentenceTransformer,
    "T5ForConditionalGeneration": T5ForConditionalGeneration,
}

# Define the file path relative to the current directory
DEFAULT_CONFIG_FILE_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "model_configs.yaml"
)
TRANKIT_CACHE_PATH = os.getenv("TRANKIT_CACHE", "./cache")

tokenizer, st_model, t2t_model, trankit_pipeline = (
    None,
    None,
    None,
    None,
)


def load_tokenizer(models_config: ModelsConfig):
    global tokenizer

    call_method = models_config.prompt_tokenization_config.call_method
    tokenizer_type = models_config.prompt_tokenization_config.type

    if call_method == "local" and tokenizer_type == "Hugging Face / Tokenizer":
        tokenizer_name = models_config.question_answering_config.name
        logger.info(f"Tokenizer - Loading: {tokenizer_name}")

        tokenizer = AutoTokenizer.from_pretrained(
            models_config.prompt_tokenization_config.model(),
            local_files_only=True,
        )


def load_trankit(models_config: ModelsConfig):
    global trankit_pipeline

    logger.info(f"Trankit - loading: {models_config.trankit_model_config.name}")

    if models_config.mode != "cloud":
        models_config.trankit_model_config.name = TRANKIT_CACHE_PATH
    # Trankit environment variable must be overwritten with path if it's cloud
    # mode.
    os.environ["TRANKIT_CACHE"] = models_config.trankit_model_config.model()

    trankit_pipeline = Pipeline(
        lang="english", cache_dir=models_config.trankit_model_config.model()
    )


def load_st_model(models_config: ModelsConfig):
    global st_model

    logger.info(
        f"Search model - Loading: {models_config.search_model_config.name}"
    )

    STModelClass = ModelClassDict[models_config.search_model_config.model_class]
    st_model = STModelClass(
        models_config.search_model_config.model(),
        device=models_config.search_model_config.device,
    )


def load_t2t_model(models_config: ModelsConfig):
    global t2t_model

    logger.info(f"QA - Loading: {models_config.question_answering_config.name}")
    logger.info(
        f"QA - Device config: {models_config.question_answering_config.device}"
    )

    T2TModelClass = ModelClassDict[
        models_config.question_answering_config.model_class
    ]
    if models_config.question_answering_config.device == "cuda":
        t2t_model = T2TModelClass.from_pretrained(
            models_config.question_answering_config.model(),
            device_map="auto",
            local_files_only=True,
        )
    else:
        t2t_model = T2TModelClass.from_pretrained(
            models_config.question_answering_config.model(),
            device_map={"": "cpu"},
            local_files_only=True,
        )


def load_models_for_inference_service(models_config: ModelsConfig):
    """
    Load models for inference service.
    """
    logger.info("Starting model loading process for inference service...")
    load_tokenizer(models_config)
    load_trankit(models_config)
    if models_config.search_model_config.call_method == "local":
        load_st_model(models_config)
    if models_config.question_answering_config.call_method == "local":
        load_t2t_model(models_config)
    logger.info("All models loaded successfully")


def batch(iterable: list, n: int = 1):
    """
    Function for creating batches from iterables

    Args:
        iterable: Iterable that needs to be chunked.
        n: Batch size

    Returns:
        iterable: Chunks of the input.
    """
    iter_l = len(iterable)
    for ndx in range(0, iter_l, n):
        yield iterable[ndx : min(ndx + n, iter_l)], (ndx, min(ndx + n, iter_l))


def call_tokenizer(model: dict, params: dict) -> dict:
    """
    Interface to call sentence tokenizers.

    Args:
        model: Dictionary of information of the model to be used.
        params: Dictionary with parameters to call the model.

    Returns:
        dict: Output of the model call.

    """
    output: dict = {}

    call_method = model["call_method"]
    tokenizer_type = model["type"]

    if tokenizer_type == "OpenAI / Tokenizer":
        encoding = tiktoken.get_encoding(model["name"])
        output["token_ids"] = [encoding.encode(s) for s in params["texts"]]
    elif call_method == "local" and tokenizer is not None:
        tokens = tokenizer(params["texts"], padding=False, truncation=False)
        output["token_ids"] = tokens["input_ids"]

    return output


def call_local_search(model: dict, params: dict) -> dict:
    """
    Interface to call local embedding models.

    Args:
        model: Dictionary of information of the model to be used.
        params: Dictionary with parameters to call the model.

    Returns:
        dict: Output of the model call.
    """
    output: dict = {}
    call_method = model["call_method"]

    if call_method == "local" and st_model is not None:
        L = len(params["documents"])
        if params["query_instruction"] is not None:
            search_inputs = [
                [params["document_instruction"], x] for x in params["documents"]
            ]
            search_inputs.extend(
                [[params["query_instruction"], x] for x in params["queries"]]
            )
        else:
            search_inputs = params["documents"]
            search_inputs.extend(params["queries"])
        embeddings = st_model.encode(
            search_inputs,
            convert_to_tensor=True,
            batch_size=model["inference_batch_size"],
        )
        scores = util.pytorch_cos_sim(embeddings[0:L], embeddings[L:])
        output["scores"] = scores

    return output


async def call_openai_search(
    openai_client: AsyncAzureOpenAI, model: dict, params: dict
) -> dict:
    """
    Interface to call OpenAI embeddings models.

    Args:
        openai_client (AsyncAzureOpenAI): OpenAI AsyncAzureOpenAI client
        model: Dictionary of information of the model to be used.
        params: Dictionary with parameters to call the model.

    Returns:
        dict: Output of the model call and total token count.
    """
    try:
        output: dict = {}
        logger.debug("Calling Azure OpenAI to get embedding")
        L = len(params["documents"])
        params["documents"].extend(params["queries"])
        embeddings = []
        total_token_count = 0
        openai_ada_deployment_name = model["ada_deployment_name"]
        for chunk_data, _ in batch(
            params["documents"], model["inference_batch_size"]
        ):
            response, tokens_count = await create_embedding_with_openai(
                openai_client, openai_ada_deployment_name, chunk_data
            )
            embeddings.extend(response)
            total_token_count += tokens_count
        scores = util.pytorch_cos_sim(embeddings[0:L], embeddings[L:])

        output["scores"] = scores
        output["token_usage"] = total_token_count
        return output
    except Exception as ex:
        logger.exception(ex)
        raise ex


async def call_search(
    model: dict, params: dict, openai_client: AsyncAzureOpenAI | None = None
) -> dict:
    """
    Interface to call semantic search models.

    Args:
        openai_client (AsyncAzureOpenAI): OpenAI AsyncAzureOpenAI client
        model: Dictionary of information of the model to be used.
        params: Dictionary with parameters to call the model.

    Returns:
        dict: Output of the model call and token usages.
    """
    output: dict = {}
    call_method = model["call_method"]
    if call_method == "azure_resource":
        assert isinstance(openai_client, AsyncAzureOpenAI)
        output = await call_openai_search(openai_client, model, params)
    elif call_method == "local":
        output = call_local_search(model, params)
    return output


async def call_openai_completion(
    openai_client: AsyncAzureOpenAI,
    model: dict,
    params: dict,
    completion_type_config: dict,
) -> dict:
    """
    Interface to call OpenAI completion models.

    Args:
        openai_client (AsyncAzureOpenAI): OpenAI AsyncAzureOpenAI client
        model: Dictionary of information of the model to be used.
        params: Dictionary with parameters to call the model.
        completion_type_config (dict): Config to map GPT model to chat
                completion or completion.

    Returns:
        dict: Output of the model call and token usages.
    """
    output: dict = {}
    completions = [None] * len(params["prompts"])
    try:
        # Make sure model deployment names in check items match to model
        # deployment names in CompletionTypeDict
        assert (
            all(
                [
                    name in completion_type_config
                    for name in params["model_deployment"]
                ]
            )
            is True
        ), (
            "Model deployment names in check items don't match to model "
            "deployment names in CompletionTypeDict. "
        )
        logger.debug("Calling Azure OpenAI to get answers and evidences.")
        token_counts: dict = {}
        for engine in completion_type_config:
            token_counts[engine] = []
            indices = [
                idx
                for idx, value in enumerate(params["model_deployment"])
                if value == engine
            ]
            if len(indices) > 0:
                partial_completions = []
                call_params = {
                    "model": engine,
                    "temperature": model.get("temperature", 0),
                    "max_tokens": params.get("max_tokens", 15),
                    "top_p": model.get("top_p", 1),
                    "frequency_penalty": model.get("frequency_penalty", 0.0),
                    "presence_penalty": model.get("presence_penalty", 0.0),
                }
                prompts = [params["prompts"][idx] for idx in indices]
                completion_function = completion_type_config[engine]
                if completion_function == "openai_completion":
                    batch_size = model["completion_batch_size"]
                    for chunk_data, _ in batch(prompts, batch_size):
                        call_params["prompt"] = chunk_data
                        response = await openai_client.completions.create(
                            **call_params
                        )
                        response_dict = response.model_dump()
                        token_counts[engine].append(response_dict["usage"])
                        # Sorted output by index as output might not be in order
                        # of prompts
                        choices = sorted(
                            response_dict["choices"], key=itemgetter("index")
                        )
                        partial_completions.extend(
                            [choice["text"] for choice in choices]
                        )
                elif completion_function == "openai_chat_completion":
                    # Only submitted number of prompts equal to
                    # chat_completion_batch_size in one batch.
                    batch_size = model["chat_completion_batch_size"]
                    for chunk_data, _ in batch(prompts, batch_size):
                        response = await openai_chat_completion(
                            openai_client=openai_client,
                            prompts_list=chunk_data,
                            model_params=call_params,
                        )
                        tokens = [res["usage"] for res in response]
                        token_counts[engine].extend(tokens)

                        partial_completions.extend(
                            [
                                res["choices"][0]["message"]["content"]
                                for res in response
                            ]
                        )
                for i, idx in enumerate(indices):
                    completions[idx] = partial_completions[i]
        output["completions"] = completions
        output["token_usage"] = token_counts
        return output
    except Exception as ex:
        logger.exception(ex)
        raise ex


def call_local_completion(model: dict, params: dict) -> dict:
    """
    Interface to call local Text2Text generation models.

    Args:
        model: Dictionary of information of the model to be used.
        params: Dictionary with parameters to call the model.

    Returns:
        dict: Output of the model call.
    """
    device = "cuda" if torch.cuda.is_available() else "cpu"
    output: dict = {}

    call_method = model["call_method"]
    allowed_token_ids = list(
        set(range(params["tokens_n"])).difference(params["suppress_tokens"])
    )
    allowed_token_ids.sort()
    decoded_outputs = []
    probs = torch.zeros((len(params["prompts"]), len(allowed_token_ids)))
    if (
        call_method == "local"
        and tokenizer is not None
        and t2t_model is not None
    ):
        for chunk_data, (start, end) in batch(
            params["prompts"], model["inference_batch_size"]
        ):
            input_ids = tokenizer(
                chunk_data, padding=True, return_tensors="pt"
            ).input_ids.to(device)
            outputs = t2t_model.generate(
                input_ids,
                max_length=params["max_tokens"],
                suppress_tokens=params["suppress_tokens"],
                output_scores=True,
                return_dict_in_generate=True,
            )
            decoded_outputs.extend(
                tokenizer.batch_decode(
                    outputs.sequences, skip_special_tokens=True
                )
            )
            # Scores of the first generated token
            scores = outputs.scores[0]
            probs[start:end, :] = torch.softmax(scores, dim=1)[
                :, allowed_token_ids
            ]

    output["completions"] = decoded_outputs
    output["probs"] = probs
    return output


async def call_completion(
    model: dict,
    params: dict,
    openai_client: AsyncAzureOpenAI | None = None,
    openai_completion_type_config: dict | None = None,
) -> dict:
    """
    Interface to call completion models.

    Args:
        model: Dictionary of information of the model to be used.
        params: Dictionary with parameters to call the model.
        openai_client (AsyncAzureOpenAI): OpenAI AsyncAzureOpenAI client
        openai_completion_type_config (dict): Config to map GPT model to chat
                completion or completion.

    Returns:
        dict: Output of the model call.
    """
    output: dict = {}
    call_method = model["call_method"]

    if call_method == "azure_resource":
        assert isinstance(openai_completion_type_config, dict)
        assert isinstance(openai_client, AsyncAzureOpenAI)
        output = await call_openai_completion(
            openai_client, model, params, openai_completion_type_config
        )
    elif call_method == "local":
        output = call_local_completion(model, params)
    return output
