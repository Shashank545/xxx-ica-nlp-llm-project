import asyncio

from openai import AsyncAzureOpenAI


async def create_chat_completion(
    openai_client: AsyncAzureOpenAI, **kwargs
) -> dict:
    """
    Call Azure OpenAI ChatCompletion API

    Args:
        openai_client (AsyncAzureOpenAI): OpenAI AsyncAzureOpenAI client
        **kwargs: Input parameters to Azure OpenAI ChatCompletion API .

    Returns:
        dict: OpenAI Response dictionary

    """
    chat_completion_resp = await openai_client.chat.completions.create(**kwargs)
    output = chat_completion_resp.model_dump()
    assert isinstance(output, dict)
    return output


async def openai_chat_completion(
    openai_client: AsyncAzureOpenAI, prompts_list: list, model_params: dict
) -> list:
    """
    Call Azure OpenAI ChatCompletion API asynchronously

    Args:
        openai_client (AsyncAzureOpenAI): OpenAI AsyncAzureOpenAI client
        prompts_list: List of messages to ChatCompletion API
        model_params: Model parameters

    Returns:
        list: List of OpenAIObject

    """
    # Gather results from all asynchronous api calls
    results = await asyncio.gather(
        *(
            create_chat_completion(
                openai_client, **model_params | {"messages": prompt}
            )
            for prompt in prompts_list
        )
    )
    # Respect mypy
    assert isinstance(results, list)
    return results


def split_data_list(data_list: list, n: int) -> list:
    """
    Split a list into sub lists of length n.

    Args:
        data_list (list): A data list input.
        n (int) : Data list split length

    Returns:
        List: List of lists.

    """
    data_len = len(data_list)
    return [
        data_list[ndx : min(ndx + n, data_len)] for ndx in range(0, data_len, n)
    ]


async def create_embedding(
    openai_client: AsyncAzureOpenAI,
    openai_ada_deployment_name: str,
    chunk_data: list,
):
    """
    Get embedding of chunked documents with retry.

    Args:
        openai_client (AsyncAzureOpenAI): OpenAI AsyncAzureOpenAI client
        openai_ada_deployment_name (str): OpenAI ADA model deployment name
        chunk_data (list): List of documents

    Returns:
        dict: A dictionary with embeddings and other information.

    """
    embd = await openai_client.embeddings.create(
        model=openai_ada_deployment_name, input=chunk_data
    )
    return embd.model_dump()


async def create_embedding_with_openai(
    openai_client: AsyncAzureOpenAI,
    openai_ada_deployment_name: str,
    data_list: list,
) -> tuple:
    """
    Get embedding of documents by splitting documents into sublist (max length
    of allowed number of input per request)

    Args:
        openai_client (AsyncAzureOpenAI): OpenAI AsyncAzureOpenAI client
        openai_ada_deployment_name (str): OpenAI ADA model deployment name
        data_list (list):  Documents list

    Returns:
        tuple: (List of documents embeddings in same order as input documents,
            Total token count)

    """
    # Split input data list in lists of 16 inputs
    data_lists = split_data_list(data_list, 16)
    # Gather results from all asynchronous api calls
    results = await asyncio.gather(
        *(
            create_embedding(openai_client, openai_ada_deployment_name, chunks)
            for chunks in data_lists
        )
    )
    # Merge results input single list again
    output = [r["embedding"] for result in results for r in result["data"]]
    tokens_count = sum([r["usage"]["total_tokens"] for r in results])
    return output, tokens_count
