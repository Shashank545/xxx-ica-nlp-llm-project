from ica_inference.model_call import trankit_pipeline

from .. import utils_logger_log_level
from .logger import Logger

logger = Logger("UtilsLogger", utils_logger_log_level)


def align_sentences_to_text(text: str, sentences: list) -> list:
    """
    Function for ensuring that after a certain text is split in sentences,
    the concatenation of those are equal to the original text:
    text == "".join(adjusted_sentences)

    Args:
        text: Input text as string.
        sentences: List of strings obtained by a sentence splitter

    Returns:
        list: List of the adjusted sentences.
    """
    try:
        logger.debug(
            "Ensuring that after a certain text is split in sentences, the "
            "concatenation of those are equal to the original text."
        )
        adjusted_sentences = []
        reconstructed_text = ""
        for sent in sentences:
            new_sentence = sent
            L = len(reconstructed_text)
            pos = text.find(new_sentence, L)
            # This should not happen
            if pos < 0:
                raise Exception(
                    "Sentence was not found in the original contract"
                )
            else:
                if pos > L:
                    # We append to the sentence spaces that
                    # were removed by SpaCy
                    new_sentence = text[L:pos] + new_sentence
            reconstructed_text += new_sentence
            adjusted_sentences.append(new_sentence)

        return adjusted_sentences

    except Exception as ex:
        logger.exception(ex)
        raise ex


def trankit_sentence_splitting(text: str) -> list:
    """
    Function for splitting text into sentences according
    to Trankit.

    Args:
        text: Input text as string.

    Returns:
        list: List of sentences.

    """
    try:
        logger.debug("Splitting text into sentences according to Trankit")
        assert trankit_pipeline is not None
        sent_dict = trankit_pipeline.ssplit(text)
        # TO DO: Make sure that "".join(sentences) == text is True
        return [sent["text"] for sent in sent_dict["sentences"]]

    except Exception as ex:
        logger.exception(ex)
        raise ex
