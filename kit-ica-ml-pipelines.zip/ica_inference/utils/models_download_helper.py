import logging
import os

from InstructorEmbedding import INSTRUCTOR
from trankit import Pipeline
from transformers import AutoTokenizer, T5ForConditionalGeneration
from .logger import Logger
from .. import utils_logger_log_level

logger = Logger("UtilsLogger", utils_logger_log_level)

TRANKIT_CACHE_PATH = os.getenv("TRANKIT_CACHE", "./cache")


def download_trankit_models(lang="english", cache_dir=TRANKIT_CACHE_PATH):
    """
    Download trankit English models.
    Args:
        lang: English option. Eg. "english" for English language models.
        cache_dir: Model cache directory.

    Returns:

    """
    try:
        logger.info("Downloading trankit models")
        Pipeline(lang=lang, cache_dir=cache_dir)

    except Exception as ex:
        logger.exception(ex)
        raise ex


def download_huggingface_small_models():
    """
    Download huggingface small models
    """
    try:
        logging.info("Downloading hugging-face small models")
        _ = AutoTokenizer.from_pretrained("google/flan-t5-large")
        _ = T5ForConditionalGeneration.from_pretrained("google/flan-t5-large")

        _ = AutoTokenizer.from_pretrained("google/flan-t5-xxl")
        _ = AutoTokenizer.from_pretrained("google/flan-ul2")

        _ = INSTRUCTOR("hkunlp/instructor-base")

    except Exception as ex:
        logger.exception(ex)
        raise ex


def download_huggingface_large_models():
    """
    Download huggingface Large models
    """
    try:
        logger.info("Downloading hugging-face large models")
        _ = AutoTokenizer.from_pretrained("google/flan-t5-xxl")
        _ = T5ForConditionalGeneration.from_pretrained("google/flan-t5-xxl")

        _ = INSTRUCTOR("hkunlp/instructor-large")

    except Exception as ex:
        logger.exception(ex)
        raise ex
