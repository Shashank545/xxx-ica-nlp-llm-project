import io
import os

import cv2
import numpy as np
from pdf2image import convert_from_bytes
from pdfminer.pdfpage import PDFPage

from .. import utils_logger_log_level
from .common_utils import translate_point
from .logger import Logger

logger = Logger("UtilsLogger", utils_logger_log_level)


def plot_bbox(
    file_bytes: io.BytesIO,
    evidence_property: dict,
    output_path: str,
    color: tuple = (0, 255, 0),
    annotation: str = "",
    prefix: str = "",
    shift: int = 10,
):
    """
    Function to plot the bounding box on the image and save
    it in output location.

    Args:
        file_bytes: PDF file in bytes.
        evidence_property: Evidence dictionary with
            bounding boxes. For example:

            .. code-block:: text

                ([{"pageno": <>, "text": <>, "bbox": <>}])

        output_path: Output folder path where the images are to be saved.
        color: BGR values.
        annotation: Text that is going to be written above
            the bounding box.
        prefix: Prefix of the image file names.
        shift: Vertical shift of the text with respect to
            the corresponding bounding box.

    Returns:
        bool: True in case when the image is saved successfully.
    """
    try:
        images_ = []
        logger.info("Converting file bytes to images")
        images = convert_from_bytes(file_bytes.getvalue())
        for item in images:
            images_.append(np.array(item))

        pages = PDFPage.get_pages(file_bytes)
        mediabox = [i.mediabox for i in pages]

        for evidences in evidence_property:
            for item in evidences["locations"]:
                pg_no = item["pagenum"] - 1
                bbox = item["bbox"]
                annotation = item.get("annotation", annotation)
                color = item.get("color", color)
                pdf_x = mediabox[pg_no][3]
                pdf_y = mediabox[pg_no][2]
                xc = images_[pg_no].shape[0]
                yc = images_[pg_no].shape[1]
                t_point = translate_point(xc, yc, pdf_x, pdf_y, bbox)
                if t_point is None:
                    return False

                start_point = (int(t_point[0]), int(t_point[1]))
                end_point = (int(t_point[2]), int(t_point[3]))
                cv2.rectangle(
                    images_[pg_no],
                    start_point,
                    end_point,
                    color=color,
                    thickness=2,
                )
                cv2.putText(
                    images_[pg_no],
                    annotation,
                    (int(t_point[0]), int(t_point[3]) - shift),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    color,
                    2,
                    cv2.LINE_AA,
                )

        if not os.path.exists(output_path):
            os.makedirs(output_path)

        logger.info("Writing output in file")
        for pg_no in range(len(mediabox)):
            cv2.imwrite(
                os.path.join(
                    output_path,
                    "{}.jpg".format(prefix + "page_" + str(pg_no + 1)),
                ),
                images_[pg_no],
                [cv2.IMWRITE_JPEG_QUALITY, 100],
            )

        return True

    except Exception as ex:
        logger.exception(ex)
        raise ex
