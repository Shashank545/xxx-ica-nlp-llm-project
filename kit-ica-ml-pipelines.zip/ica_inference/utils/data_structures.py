from dataclasses import dataclass


@dataclass
class Evidence:
    pagenum: int
    bbox: list[float]
    text: str
    line_id: int


@dataclass
class Location:
    locations: list[Evidence]


@dataclass
class Answer:
    code: str
    answer: str
    evidences: list[Location]
