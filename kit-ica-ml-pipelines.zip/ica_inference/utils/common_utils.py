import re
from io import BytesIO
from typing import List, Optional

import numpy as np
from pdfminer.converter import PDFPageAggregator
from pdfminer.layout import (
    LAParams,
    LTAnno,
    LTChar,
    LTTextBox,
    LTTextLineHorizontal,
)
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage

from .. import utils_logger_log_level
from .logger import Logger

logger = Logger("UtilsLogger", utils_logger_log_level)

global rarechar
rarechar = "⸮"

PATTERN = re.compile(r"(?<!^)\n(?=[a-z])", re.MULTILINE)


def get_plotting_bbox(
    bbox_list: list, char_list: list
) -> tuple[Optional[list], Optional[str]]:
    """
    Utility function to get the coordinates of a line of the
    evidence using coordinates of the first and last character.

    Args:
        bbox_list: List of coordinates of all characters of the line
            such as [[x00, x01, x02, x03], [x10, x11, x12, x13], ...].
        char_list: List of characters.
    Returns:
        list: Coordinates of the line of the evidence.
        str: string built by concatenating the characters of the evidence.
    """
    try:
        logger.debug(
            "Getting coordinates of a line of the evidence using coordinates of"
            " the first and last character."
        )
        while len(bbox_list) >= 1 and bbox_list[0][0] is None:
            bbox_list.pop(0)
            char_list.pop(0)
        while len(bbox_list) >= 1 and bbox_list[-1][0] is None:
            bbox_list.pop(-1)
            char_list.pop(-1)

        if len(bbox_list) >= 1:
            x0 = bbox_list[0][0]  # type: ignore
            y0 = bbox_list[0][1]
            x1 = bbox_list[-1][2]
            y1 = bbox_list[0][3]
            text = "".join(char_list)
            return ([x0, y0, x1, y1], text)
        else:
            return (None, None)

    except Exception as ex:
        logger.exception(ex)
        raise ex


def group_by_line(coordinates: list) -> dict:
    """
    Utility function to group characters by the line they belong to.

    Args:
        coordinates: List of tuples For example:

            .. code-block:: text

                [(1, 1, [10,20,30,40], 1,
                {"Font-Information": {"font-name": None,
                                      "font-size": None}})]

            The last element of the tuple is the line id.

    Returns:
        dict: Dictionary whose keys are line ids and values
        are characters of the piece of the evidence that belongs to the same
        (page and) line.

    """
    try:
        logger.debug("Group characters by the line they belong to")
        group_dict: dict = {}
        for item in coordinates:
            line_id = item[4]
            if line_id in group_dict:
                group_dict[line_id].append(item)
            else:
                group_dict[line_id] = [item]
        return group_dict

    except Exception as ex:
        logger.exception(ex)
        raise ex


def pdf_char_extractor(file_bytes: BytesIO) -> list:
    """
    Function to extract text from PDF file (bytes)
    and calculate coordinates of each character and return
    them in the form of dictionary and also extract
    the layout information from the file.

    Args:
        file_bytes: Input PDF file as bytes.

    Returns:
        list: List of dictionaries with layout information in
        pdf file with information about each character
        in the PDF file, their coordinates.
    """
    try:
        logger.debug("Extracting text from file bytes")
        manager = PDFResourceManager()
        laparams = LAParams()
        dev = PDFPageAggregator(manager, laparams=laparams)
        interpreter = PDFPageInterpreter(manager, dev)
        pages = PDFPage.get_pages(file_bytes)
        page_count = 0
        char_count = 0
        line_count = 0
        char_list: list = list()
        info: dict = dict()
        start = 0
        end = 0
        layout_list = []
        for page in pages:
            page_count += 1
            interpreter.process_page(page)
            layout = dev.get_result()
            for textbox in layout:
                if isinstance(textbox, LTTextBox):
                    charcount = 0
                    for line in textbox:
                        if isinstance(line, LTTextLineHorizontal):
                            line_count += 1
                            for char in line:
                                if len(char.get_text()) > 1:
                                    character = rarechar
                                    charcount += 1
                                else:
                                    character = char.get_text()
                                    charcount += 1
                                if isinstance(char, LTAnno):
                                    info = {
                                        "Font-Information": {
                                            "font-name": None,
                                            "font-size": None,
                                            "rotation-matrix": None,
                                        }
                                    }
                                    char_ = character
                                    x_0 = None
                                    y_0 = None
                                    x_1 = None
                                    y_1 = None
                                    if False:
                                        pass
                                    else:
                                        char_list.append(
                                            (
                                                page_count,
                                                char_count,
                                                char_,
                                                [x_0, y_0, x_1, y_1],
                                                line_count,
                                                info,
                                            )
                                        )
                                    char_count += 1
                                elif isinstance(char, LTChar):
                                    matrix_ = [
                                        char.matrix[0],
                                        char.matrix[1],
                                        char.matrix[2],
                                        char.matrix[3],
                                    ]
                                    info = {
                                        "Font-Information": {
                                            "font-name": char.fontname,
                                            "font-size": char.size,
                                            "rotation-matrix": matrix_,
                                        }
                                    }
                                    x_0 = char.bbox[0]
                                    y_0 = char.bbox[1]
                                    x_1 = char.bbox[2]
                                    y_1 = char.bbox[3]
                                    char_list.append(
                                        (
                                            page_count,
                                            char_count,
                                            character,
                                            [x_0, y_0, x_1, y_1],
                                            line_count,
                                            info,
                                        )
                                    )
                                    char_count += 1
                    end = start + charcount

                    layout_list.append(
                        {
                            "pagenum": page_count,
                            "page-dimension": page.mediabox,
                            "bbox": textbox.bbox,
                            "range": [start, end],
                            "character-info": char_list,
                        }
                    )
                    start = end
                    char_list = []

        logger.debug("Finished layout extraction")
        return layout_list

    except Exception as ex:
        logger.exception(ex)
        raise ex


def translate_point(
    xc: int, yc: int, pdf_x: float, pdf_y: float, point: list
) -> tuple:
    """
    Function to convert the bbox coordinates
    in a format which can be plotted after
    converting the PDF to image.

    Args:
        xc: X coordinate of the image file.
        yc: Y coordinate of the image file.
        pdf_x: X coordinate of the PDF file.
        pdf_y: Y coordinate of the PDF file.
        point: Coordinates to be converted.

    Returns:
        tuple: Tuple containing values of the
        converted coordinates.
    """
    try:
        logger.debug("Converting bbox coordinates to appropriate format")
        a, b, c, d = point

        x0 = (yc / pdf_y) * a
        y0 = xc - (xc / pdf_x) * b
        x1 = (yc / pdf_y) * c
        y1 = xc - (xc / pdf_x) * d

        return (x0, y0, x1, y1)

    except Exception as ex:
        logger.exception(ex)
        raise ex


def two_points_distance(l1: tuple, l2: tuple) -> float:
    """
    Utility function to find the distance between two points.

    Args:
        l1: The first point.
        l2: The second point.

    Returns:
        float: The distance between two points in units.
    """
    try:
        logger.debug("Finding distance between two points")
        x1 = l1[0]
        y1 = l1[1]
        x2 = l2[0]
        y2 = l2[1]
        distance: float = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        return distance

    except Exception as ex:
        logger.exception(ex)
        raise ex


def two_rectangles_distance(c1: list, c2: list) -> float:
    """
    Utility function to find the distance between two bounding boxes

    Args:
        c1: Bounding box coordinates of first rectangle.
        c2: Bounding box coordinates of second rectangle.

    Returns:
        float: The distance between two bounding boxes in units.
    """
    try:
        logger.debug("Calculating distance between two bounding boxes")
        x_top1 = c1[2]
        y_top1 = c1[3]
        x_bottom1 = c1[0]
        y_bottom1 = c1[1]
        x_top2 = c2[2]
        y_top2 = c2[3]
        x_bottom2 = c2[0]
        y_bottom2 = c2[1]

        # Position of the second rectangle w.r.t to the first
        left = x_top2 < x_bottom1
        right = x_top1 < x_bottom2
        top = y_top1 < y_bottom2
        bottom = y_top2 < y_bottom1
        # The initialization handles the case of intersecting rectangles.
        distance: float = 0
        if top and left:
            distance = two_points_distance(
                (x_bottom1, y_top1), (x_top2, y_bottom2)
            )
        elif bottom and left:
            distance = two_points_distance(
                (x_bottom1, y_bottom1), (x_top2, y_top2)
            )
        elif bottom and right:
            distance = two_points_distance(
                (x_top1, y_bottom1), (x_bottom2, y_top2)
            )
        elif top and right:
            distance = two_points_distance(
                (x_top1, y_top1), (x_bottom2, y_bottom2)
            )
        elif left:
            distance = x_bottom1 - x_top2
        elif right:
            distance = x_bottom2 - x_top1
        elif bottom:
            distance = y_bottom1 - y_top2
        elif top:
            distance = y_bottom2 - y_top1
        return distance

    except Exception as ex:
        logger.exception(ex)
        raise ex


def header_filter(items: list, norm_upper_bound: float) -> list:
    """
    Function that filters out all text boxes whose bottom
    vertical coordinate is higher than a certain threshold:
    norm_upper_bound * page_vertical_dimension.

    Args:
        items: List of dictionaries containing information
            about text boxes. For example

            .. code-block:: text

                {'pagenum': 1,
                'page-dimension': [0, 0, 595.276, 841.89],
                'bbox': [[74.413, 733.201, 520.867, 763.487]],
                'range': [0, 83],
                'character-info': [(1,0,...),...]
                }

        norm_upper_bound: The normalized upper threshold above
            which all text boxes will be filtered out
            (0 <= norm_upper_bound <= 1).

    Returns:
        list: Indices of items that are not filtered out.
    """
    try:
        logger.debug("Applying header filter")
        indices: list = []
        upper_bound = norm_upper_bound * items[0]["page-dimension"][3]
        for indx, item in enumerate(items):
            y1 = item["bbox"][1]
            # If following condition is satisfied
            # then we keep the item
            if y1 < upper_bound:
                indices.append(indx)
        return indices

    except Exception as ex:
        logger.exception(ex)
        raise ex


def footnote_filter(items: list, norm_lower_bound: float) -> list:
    """
    Function that filters out all text boxes whose top
    vertical coordinate is lower than a certain threshold:
    norm_lower_bound * page_vertical_dimension.

    Args:
        items: List of dictionaries containing information
            about text boxes. For example

            .. code-block:: text

                {'pagenum': 1,
                'page-dimension': [0, 0, 595.276, 841.89],
                'bbox': [[74.413, 733.201, 520.867, 763.487]],
                'range': [0, 83],
                'character-info': [(1,0,...),...]
                }

        norm_lower_bound: The normalized lower threshold below
            which all text boxes will be filtered out
            (0 <= norm_lower_bound <= 1).

    Returns:
        list: Indices of items that are not filtered out.
    """
    try:
        logger.debug("Applying footenote filter")
        indices: list = []
        lower_bound = norm_lower_bound * items[0]["page-dimension"][3]
        for indx, item in enumerate(items):
            y1 = item["bbox"][3]
            # If following condition is satisfied
            # then we keep the item
            if y1 > lower_bound:
                indices.append(indx)
        return indices

    except Exception as ex:
        logger.exception(ex)
        raise ex


def font_filter(
    items: list, font_size: Optional[float], font_perc: Optional[float]
) -> list:
    """
    Function that filters out all text boxes whose characters have all font
    size smaller than a certain threshold given either by font_size or
    calculated by using the percentile value font_perc.

    Args:
        items: List of dictionaries containing information about text boxes.
            For example

            .. code-block:: text

                {'pagenum': 1,
                'page-dimension': [0, 0, 595.276, 841.89],
                'bbox': [[74.413, 733.201, 520.867, 763.487]],
                'range': [0, 83],
                'character-info': [(1,0,...),...]
                }

        font_size: Font size threshold.
        font_perc: Percentile which must be between 0 and 100 inclusive; used if
         font_size is None.

    Returns:
        list: Indices of items that are not filtered out.
    """
    try:
        logger.debug("Applying font filter")
        indices: list = []
        if font_size is None:
            char_font_sizes = []
            for item in items:
                char_font_sizes.extend(
                    [
                        char[5]["Font-Information"]["font-size"]
                        for char in item["character-info"]
                        if char[5]["Font-Information"]["font-size"] is not None
                    ]
                )
            font_size = np.percentile(
                char_font_sizes, font_perc, method="lower"
            )  # type: ignore

        for indx, item in enumerate(items):
            for char in item["character-info"]:
                char_font_size = char[5]["Font-Information"]["font-size"]
                # The equality in >= is essential if font_size is
                # calculated from font_perc.
                if char_font_size is not None and char_font_size >= font_size:
                    indices.append(indx)
                    break
        return indices

    except Exception as ex:
        logger.exception(ex)
        raise ex


def horizontal_filter(items: list) -> list:
    """
    Function that filters out all text boxes whose characters are all rotated.

    Args:
        items: List of dictionaries containing information
            about text boxes. For example

            .. code-block:: text

                {'pagenum': 1,
                'page-dimension': [0, 0, 595.276, 841.89],
                'bbox': [[74.413, 733.201, 520.867, 763.487]],
                'range': [0, 83],
                'character-info': [(1,0,...),...]
                }

    Returns:
        list: Indices of items that are not filtered out.
    """
    try:
        logger.debug("Applying character rotation filter")
        indices: list = []
        for indx, item in enumerate(items):
            for char in item["character-info"]:
                char_matrix = char[5]["Font-Information"]["rotation-matrix"]
                if char_matrix is not None and char_matrix == [1, 0, 0, 1]:
                    indices.append(indx)
                    break
        return indices

    except Exception as ex:
        logger.exception(ex)
        raise ex


def distance_filter(items: list, dist_diag_coeff: float) -> list:
    """
    Function that filters out all text boxes that are
    isolated, i.e. have distance to all other text
    boxes bigger than a distance threshold.

    Args:
        items: List of dictionaries containing information
            about text boxes. For example

            .. code-block:: text

                {'pagenum': 1,
                'page-dimension': [0, 0, 595.276, 841.89],
                'bbox': [[74.413, 733.201, 520.867, 763.487]],
                'range': [0, 83],
                'character-info': [(1,0,...),...]}

        dist_diag_coeff: The distance threshold is calculated by
            dist_diag_coeff x diagonal of the page.

    Returns:
        list: Indices of items that are not filtered out.
    """
    try:
        logger.debug("Applying distance filter")
        items_n = len(items)
        if items_n > 1:
            indices: list = []
            diag_x = items[0]["page-dimension"][2]
            diag_y = items[0]["page-dimension"][3]
            distance = dist_diag_coeff * (diag_x**2 + diag_y**2) ** 0.5
            for first_item_count in range(items_n):
                add = False
                for second_item_count in range(items_n):
                    if second_item_count != first_item_count:
                        dist = two_rectangles_distance(
                            items[first_item_count]["bbox"],
                            items[second_item_count]["bbox"],
                        )
                        if dist < distance:
                            add = True
                            break
                if add:
                    indices.append(first_item_count)
        else:
            indices = list(range(items_n))

        return indices

    except Exception as ex:
        logger.exception(ex)
        raise ex


def same_page_bbox_filter(
    same_page_boxes: list,
    norm_upper_bound: Optional[float] = None,
    norm_lower_bound: Optional[float] = None,
    font_size: Optional[float] = None,
    font_perc: Optional[float] = None,
    dist_diag_coeff: Optional[float] = None,
    only_horizontal: Optional[bool] = None,
    apply_all: bool = False,
) -> list:
    """
    Function that filters out all text boxes on the same page that
    match at least one of (if apply_all is false) or all
    (if apply_all is true) conditions:

        - The bottom vertical coordinate is higher than a threshold;
        - The top vertical coordinate is lower than a threshold;
        - Its characters have all font size smaller than a threshold;
        - Its characters are all rotated;
        - Have distance to all other text boxes bigger than a threshold.

    Args:
        same_page_boxes: List of dictionaries containing information
            about text boxes. For example

            .. code-block:: text

                {'pagenum': 1,
                'page-dimension': [0, 0, 595.276, 841.89],
                'bbox': [[74.413, 733.201, 520.867, 763.487]],
                'range': [0, 83],
                'character-info': [(1,0,...),...]}

            It is assumed that they will all have the same pagenum.
        norm_upper_bound: The normalized upper threshold above
            which all text boxes will be filtered out
            (0 <= norm_upper_bound <= 1).
        norm_lower_bound: The normalized lower threshold below
            which all text boxes will be filtered out
            (0 <= norm_lower_bound <= 1).
        font_size: Font size threshold.
        font_perc: Percentile which must be between 0 and 100 inclusive;
            used if font_size is None.
        dist_diag_coeff: The distance threshold is calculated by
            dist_diag_coeff x diagonal of the page.
        only_horizontal: Whether or not to exclude text boxes
            that have all characters rotated.
        apply_all: If true, a box is filtered out if it is filtered out
            by all filters whose parameters are not None;
            if false, a box is filtered out if it is filtered out
            at least by one filter whose parameter is not None.

    Returns:
        list: Indices of items that are not filtered out.
    """
    try:
        all_indices = list(range(len(same_page_boxes)))

        if norm_upper_bound is not None:
            upper_ok_indices = header_filter(same_page_boxes, norm_upper_bound)
        elif apply_all:
            upper_ok_indices = []
        else:
            upper_ok_indices = all_indices

        if norm_lower_bound is not None:
            lower_ok_indices = footnote_filter(
                same_page_boxes, norm_lower_bound
            )
        elif apply_all:
            lower_ok_indices = []
        else:
            lower_ok_indices = all_indices

        if not (font_size is None and font_perc is None):
            font_ok_indices = font_filter(same_page_boxes, font_size, font_perc)
        elif apply_all:
            font_ok_indices = []
        else:
            font_ok_indices = all_indices

        if dist_diag_coeff is not None:
            distance_ok_indices = distance_filter(
                same_page_boxes, dist_diag_coeff
            )
        elif apply_all:
            distance_ok_indices = []
        else:
            distance_ok_indices = all_indices

        if only_horizontal:
            horizontal_ok_indices = horizontal_filter(same_page_boxes)
        elif only_horizontal is not None:
            horizontal_ok_indices = all_indices
        elif apply_all:
            horizontal_ok_indices = []
        else:
            horizontal_ok_indices = all_indices

        if apply_all:
            ok_indices = list(
                set.union(
                    set(upper_ok_indices),
                    set(lower_ok_indices),
                    set(font_ok_indices),
                    set(distance_ok_indices),
                    set(horizontal_ok_indices),
                )
            )
        else:
            ok_indices = list(
                set.intersection(
                    set(upper_ok_indices),
                    set(lower_ok_indices),
                    set(font_ok_indices),
                    set(distance_ok_indices),
                    set(horizontal_ok_indices),
                )
            )
        ok_indices.sort()
        return ok_indices

    except Exception as ex:
        logger.exception(ex)
        raise ex


def layout_filter(
    layout: list,
    norm_upper_bound: Optional[float] = None,
    norm_lower_bound: Optional[float] = None,
    font_size: Optional[float] = None,
    font_perc: Optional[float] = None,
    dist_diag_coeff: Optional[float] = None,
    only_horizontal: Optional[bool] = None,
    apply_all: bool = False,
) -> list:
    """
    Function that filters out all text boxes that match at least
    one of (if apply_all is false) or all (if apply_all is true)
    conditions:

        - The bottom vertical coordinate is higher than a threshold;
        - The top vertical coordinate is lower than a threshold;
        - Its characters have all font size smaller than a threshold;
        - Its characters are all rotated;
        - Have distance to all other text boxes bigger than a threshold.

    Args:
        layout: List of dictionaries containing information
            about text boxes. For example

            .. code-block:: text

                {'pagenum': 1,
                'page-dimension': [0, 0, 595.276, 841.89],
                'bbox': [[74.413, 733.201, 520.867, 763.487]],
                'range': [0, 83],
                'character-info': [(1,0,...),...]
                }

            It is assumed that they will all have the same pagenum.
        norm_upper_bound: The normalized upper threshold above
            which all text boxes will be filtered out:
            0 <= norm_upper_bound <= 1.
        norm_lower_bound: The normalized lower threshold below
            which all text boxes will be filtered out:
            0 <= norm_lower_bound <= 1.
        font_size: Font size threshold.
        font_perc: Percentile which must be between 0 and 100 inclusive;
            used if font_size is None.
        dist_diag_coeff: The distance threshold is calculated by
            dist_diag_coeff x diagonal of the page.
        only_horizontal: Whether or not to exclude text boxes
            that have all characters rotated.
        apply_all: if true, a box is filtered out if it is filtered out
            by all filters whose parameters are not None;
            if false, a box is filtered out if it is filtered out
            at least by one filter whose parameter is not None.

    Returns:
        list: Indices of items that are not filtered out.
    """
    try:
        logger.debug(
            "Applying multiple filter on bounding boxes if any given condition "
            "is true"
        )
        indices: list = []

        page_lst = [d["pagenum"] for d in layout]
        # filter only unique pages
        val = set(page_lst)
        # This will be a list of lists,
        # each list being the indices of layout elements
        # with the same page
        page_indices = []
        num = 0
        for i in val:
            temp = []
            # loop till number of occurrence of each page
            for j in range(page_lst.count(i)):
                temp.append(num)
                num += 1
            page_indices.append(temp)

        for indices_lst in page_indices:
            same_page_boxes = [layout[i] for i in indices_lst]
            to_be_added_indices = same_page_bbox_filter(
                same_page_boxes,
                norm_upper_bound,
                norm_lower_bound,
                font_size,
                font_perc,
                dist_diag_coeff,
                only_horizontal,
                apply_all,
            )
            if to_be_added_indices is None:
                pass
            else:
                indices.extend([indices_lst[j] for j in to_be_added_indices])

        return indices

    except Exception as ex:
        logger.exception(ex)
        raise ex


def windowing(
    integers: List[int], window_max_sum: int = 50, overlap_max_sum: int = 20
) -> list:
    """
    Function for calculating overlapping ranges

        .. code-block:: text

                r = [(start1, end1), ...., (startN, endN)]

                Satisfying the following conditions:
                - The first range starts at the beginning: r[0][0] = 0;
                - The last range ends at the end of the list of integers:
                  r[-1][1] = len(integers)+1;
                - We progressively go forward without missing any elements:
                  r[i][0] < r[i+1][0] <= r[i][1] < r[i+1][1];
                - The length of each window is not bigger than window_max_sum:
                  sum(integers[r[i][0]: r[i][1]]) <= window_max_sum;
                - The length of each overlap between two contiguous windows
                  is not bigger than overlap_max_sum:
                  sum(integers[r[i+1][0]: r[i][1]]) <= overlap_max_sum.

    Args:
        integers: List of integers.
        window_max_sum: Integer.
        overlap_max_sum: Integer.

    Returns:
        list: List of two element lists representing the start and
        the non-inclusive end.
    """
    try:
        logger.debug("Calculating overlapping ranges in the list of bboxes")
        windows = []
        L = len(integers)
        cursor = 0
        start = -1
        end = 0
        while cursor < L:
            previous_start = start
            previous_end = end
            back_accumulated_length = 0
            go_back = True
            while go_back:
                if (
                    cursor > previous_start + 1
                    and back_accumulated_length + integers[cursor - 1]
                    <= overlap_max_sum
                ):
                    back_accumulated_length += integers[cursor - 1]
                    cursor -= 1
                else:
                    go_back = False
            start = cursor
            cursor = max(cursor, previous_end)
            forward_accumulated_length = sum(integers[start : cursor + 1])
            go_forward = True
            while go_forward:
                if (
                    cursor < L - 1
                    and forward_accumulated_length + integers[cursor + 1]
                    <= window_max_sum
                ):
                    forward_accumulated_length += integers[cursor + 1]
                else:
                    go_forward = False
                cursor += 1
            end = cursor
            windows.append((start, end))

        return windows

    except Exception as ex:
        logger.exception(ex)
        raise ex


def normalize_whitespaces(sentence: str) -> str:
    """
    Function for normalizing multiple consecutive whitespace or newline
    characters.

    Args:
        sentence: a string of text
    Returns:
        str: the string of text after normalizing the whitespaces.
    """
    try:
        logger.debug("Normalizing whitespaces and newline characters")
        sentence = sentence.strip()
        # Consolidate multiple new lines to one.
        sentence = re.sub(r"\n\s*\n", "\n", sentence)
        # Replace newline char with empty space if is
        # followed by a not capital letter.
        sentence = re.sub(PATTERN, " ", sentence)
        # Consolidate multiple spaces to one.
        sentence = re.sub(r"[^\S\r\n]+", " ", sentence)
        return sentence

    except Exception as ex:
        logger.exception(ex)
        raise ex
