from __future__ import annotations

from typing import Callable, Union

from .. import utils_logger_log_level
from .common_utils import normalize_whitespaces
from .logger import Logger

logger = Logger("UtilsLogger", utils_logger_log_level)


def build_flan_prompt(question: dict, passage: str) -> str:
    """
    Function for building prompts for the google flan models.

    Args:
        question: A dictionary including information about the question.
        passage: The text against which the question is made.

    Returns:
        str: Prompt.
    """
    try:
        logger.debug("Building prompts for the google flan models")
        # Open prompt:
        prompt = "Read this and answer the question."
        prompt += ' If the question is unanswerable, say "unanswerable".'
        prompt += "\n\nWe are KPMG and wrote this Engagement Letter. "
        passage_normalized = normalize_whitespaces(passage)
        prompt += passage_normalized.strip() + "\n\n"
        prompt += question["question"]

        return prompt

    except Exception as ex:
        logger.exception(ex)
        raise ex


def build_prompt_gpt_chat_completion(question: dict, passage: str) -> list:
    """
    Interface to dispatch calls for Azure OpenAI GPT models for chat completion

    Args:
        question (dict) : Question dictionary with question information.
        passage (str): The text against which the question is made.

    Returns:
        list: Message list for GPTx for ChatCompletion API.
    """
    sys_dict = {"role": "system", "content": question["system_message"]}

    messages = [
        sys_dict,
        {
            "role": "assistant",
            "content": f"""{question["user_message_start"]}
{passage}
{question["user_message_end"]}
    """,
        },
    ]

    return messages


def build_prompt_gpt_completion(question: dict, passage: str) -> str:
    """
    Interface to dispatch calls for Azure OpenAI GPT models for completion

    Args:
        question (dict) : Question dictionary .
        passage (str): The text against which the question is made.

    Returns:
        str: prompt for GPT-35-turbo-instruct for Completion API .
    """
    prompt: str = question["system_message"]
    prompt += f"""{question["user_message_start"]}
{passage}
{question["user_message_end"]}
    """

    return prompt


def build_prompt(
    question: dict,
    passage: str,
    openai_completion_type_config: dict | None = None,
) -> Union[str, list]:
    """
    Interface to dispatch calls for building text2text model dependent
    prompts: GPT models, Flan-T5-xxl, Flan-Ul2, etc.

    Args:
        question: Dictionary with question related information.
        passage: The text against which the question is made.
        openai_completion_type_config (dict): Config to map GPT model to chat
                completion or completion.

    Returns:
        Union[str, list]: Output of the prompt build function.
    """
    try:
        logger.debug("Building text2text model dependent prompts")
        model_deployment_name = question["model_deployment"]
        completion_type = None
        if isinstance(openai_completion_type_config, dict):
            completion_type = openai_completion_type_config[
                model_deployment_name
            ]
        if completion_type == "openai_completion":
            prompt_function: Callable = build_prompt_gpt_completion
        elif completion_type == "openai_chat_completion":
            prompt_function = build_prompt_gpt_chat_completion
        else:
            prompt_function = build_flan_prompt
        output: Union[str, list] = prompt_function(question, passage)

        return output

    except Exception as ex:
        logger.exception(ex)
        raise ex
