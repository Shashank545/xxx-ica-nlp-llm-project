from __future__ import annotations

import io
import logging
from itertools import groupby
from operator import itemgetter
from typing import Callable, Optional

from ica_inference import utils_logger_log_level
from ica_inference.model_call import call_completion, call_search
from ica_inference.postprocessing import get_evidence_coordinates
from ica_inference.preprocessing import preprocess
from ica_inference.utils.data_structures import Answer
from ica_inference.utils.logger import Logger
from ica_inference.utils.parse_answers import (
    get_evidence_indices,
    gptx_output_parsing,
)
from ica_inference.utils.prompt_building import build_prompt

logger = Logger("UtilsLogger", utils_logger_log_level)


# This function is used below in
# groupby(enumerate(all_evidence_lst), first_minus_second)
# I could not pass mypy if it is defined as
# a lambda function.
def first_minus_second(sequence):
    """
    Function to calculate the difference between
    the first and second element of a sequence.

    Args:
        sequence: A numerical list or tuple.

    Returns:
        The difference between the first and
        second element.
    """
    try:
        return sequence[0] - sequence[1]
    except Exception as ex:
        logging.exception(ex)
        raise ex


async def answer_with_evidence(  # noqa: C901
    pdf_file: io.BytesIO,
    check_items: list,
    search_config_dict: dict,
    qa_config_dict: dict,
    tokenizer_config_dict: dict,
    min_sent_length: int = 15,
    min_semantic_score: float = 0.85,
    openai_client: Optional[Callable] = None,
    openai_completion_type_config: dict | None = None,
    return_token_usage: bool = False,
) -> dict:
    """
    Function to answer questions relative to a document.

    Args:
        pdf_file: Engagement letter pdf file.
        check_items: It's a list of dictionaries with information relative to
            the questions.
        tokenizer_config_dict: Config dict.
        qa_config_dict: Config dict.
        search_config_dict: Config dict.
        min_sent_length: Minimum length of a sentence to be used
            for semantic search.
        min_semantic_score: minimum semantic score that a passage needs to
            have with a question to be admitted as prompt.
        openai_client(Callable): Azure OpenAI client function which create Azure
            OpenAI Async client on call.
        openai_completion_type_config (dict): Config to map GPT model to chat
                completion or completion.
        return_token_usage(bool): If output should also have token usages for
                Azure OpenAI models.
    Returns:
        dict: Answers of the questions with bounding boxes of the words
        from the document that support the answer and token usages for
        Azure OpenAI.

    """
    try:
        logger.info("Answering questions relative to the document")
        prepr_contract: dict = preprocess(pdf_file, tokenizer_config_dict)
        # Search for relevant documents
        queries: list = []
        for check_item in check_items:
            for question in check_item["ml_config"]["questions"]:
                queries.append(
                    question["user_message_end"].replace("Question: ", "")
                )

        search_params = {
            "queries": queries,
            "documents": prepr_contract["processed_sentences"].copy(),
            "query_instruction": "Represent the question for "
            + "retrieving supporting documents: ",
            "document_instruction": "Represent the document for retrieval: ",
        }
        result = await call_search(
            model=search_config_dict,
            params=search_params,
            openai_client=openai_client()
            if openai_client is not None
            else None,
        )
        search_scores = result["scores"]
        short_sent_mask = [
            len(s) <= min_sent_length
            for s in prepr_contract["processed_sentences"]
        ]
        # Set score to a negative number for short sentences
        search_scores[short_sent_mask, :] = -1
        # Prepare prompts
        passages: list = []
        prompt_id = 0
        question_cnt = 0
        prompts: dict = {}
        model_deployments = []
        for k, check_item in enumerate(check_items):
            check_item["found_answers"] = {}
            for j, question in enumerate(check_item["ml_config"]["questions"]):
                for i, (start, end) in enumerate(prepr_contract["windows"]):
                    # Prepare contract passages
                    passages.append(
                        "".join(
                            # Notice tha we use the sentences
                            # and not the processed sentences
                            prepr_contract["sentences"][start:end]
                        )
                    )
                    # Prompt is included if there is enough semantic similarity
                    pass_score = (
                        search_scores[start:end, question_cnt].max().item()
                    )
                    if pass_score > min_semantic_score:
                        model_deployment = question["model_deployment"]
                        model_deployments.append(model_deployment)
                        prompts[prompt_id] = {
                            "prompt": build_prompt(
                                question,
                                passages[i],
                                openai_completion_type_config,
                            ),
                            "check_item_id": k,
                            "question_id": j,
                            "question_cnt": question_cnt,
                            "start": start,
                            "end": end,
                        }
                    prompt_id += 1
                question_cnt += 1

        params = {
            "model_deployment": model_deployments,
            "max_tokens": qa_config_dict.get("max_output_tokens", 200),
            "prompts": [prompts[key]["prompt"] for key in prompts],
        }
        logger.info("Number of prompts prepared: " + str(len(prompts)))
        output = await call_completion(
            model=qa_config_dict,
            params=params,
            openai_client=openai_client()
            if openai_client is not None
            else None,
            openai_completion_type_config=openai_completion_type_config,
        )

        # Collect the evidence for the questions positively answered
        evidence: dict = {}

        for i, prompt_id in enumerate(prompts):
            check_item_id = prompts[prompt_id]["check_item_id"]
            check_item = check_items[check_item_id]
            # question_id = prompts[prompt_id]["question_id"]
            # question = check_item["ml_config"]["questions"][question_id]
            # question_cnt = prompts[prompt_id]["question_cnt"]
            start = prompts[prompt_id]["start"]
            end = prompts[prompt_id]["end"]
            window_sents = prepr_contract["processed_sentences"][start:end]
            parsed_output = gptx_output_parsing(output["completions"][i])
            answer = parsed_output["answer"].capitalize()
            # Find relevant text indices
            window_sents_striped = [sent.strip() for sent in window_sents]
            sentences_indices = get_evidence_indices(
                window_sents_striped, parsed_output["evidences"], start
            )
            evidence[prompt_id] = sentences_indices
            if answer in check_item["found_answers"]:
                check_item["found_answers"][answer].append(prompt_id)
            else:
                check_item["found_answers"][answer] = [prompt_id]
        # Attach answer & evidence
        answers: list = []
        cum_text_length = prepr_contract["cum_text_length"]
        for check_item in check_items:
            # Dictionary that will include evidence ids
            # for each answer that was found.
            # Evidence ids for across all answers.
            all_evidence: set = set()
            answer_keys = list(check_item["found_answers"].keys())
            # TODO: Make this part generic once check items for phase-II
            #  are ready.
            # Should attach by answers ?? Check if answer is Yes?No?
            if "Yes" in answer_keys:
                for prompt_id in check_item["found_answers"]["Yes"]:
                    all_evidence.update(evidence[prompt_id])
                answer_string = check_item["ml_config"]["questions"][0][
                    "answer_mapping"
                ]["yes"]
            elif "No" in answer_keys:
                for prompt_id in check_item["found_answers"]["No"]:
                    all_evidence.update(evidence[prompt_id])
                answer_string = check_item["ml_config"]["questions"][0][
                    "answer_mapping"
                ]["no"]
            else:
                answer_string = check_item["ml_config"]["questions"][0][
                    "answer_mapping"
                ]["no"]
            if (
                len(all_evidence) > 0
                and check_item["ml_config"]["evidence_required_answers"].get(
                    answer_string
                )
                is True
            ):
                # Attach evidence
                all_evidence_lst: list = list(all_evidence)
                all_evidence_lst.sort()
                # Build ranges of characters for the evidence.
                evid_char_ranges: list = []
                for k, g in groupby(
                    enumerate(all_evidence_lst), first_minus_second
                ):
                    z = list(map(itemgetter(1), g))
                    evid_start_indx = (
                        cum_text_length[z[0] - 1] if z[0] > 0 else 0
                    )
                    evid_end_indx = cum_text_length[z[-1]]
                    evid_char_ranges.append([evid_start_indx, evid_end_indx])
                answer_evidence: list = get_evidence_coordinates(
                    evid_char_ranges, prepr_contract["char_data"], True
                )
            else:
                answer_evidence = []
            answers.append(
                Answer(
                    check_item["code"], answer_string, answer_evidence
                ).__dict__
            )
            del check_item["found_answers"]
            del check_item["ml_config"]["evidence_required_answers"]
            del check_item["ml_config"]["questions"]
        out: dict = {"results": answers}
        if return_token_usage is True:
            token_usages = {}
            # Get token usages for Azure OpenAI
            if "token_usage" in result:
                token_usages["search"] = result["token_usage"]
            else:
                token_usages["search"] = 0
            # Get token usages for Azure OpenAI for completions
            if "token_usage" in output:
                token_usages["completions"] = output["token_usage"]
            for key in token_usages["completions"]:
                token_usages["completions"][key] = {
                    "completion_tokens": sum(
                        map(
                            itemgetter("completion_tokens"),
                            token_usages["completions"][key],
                        )
                    ),
                    "prompt_tokens": sum(
                        map(
                            itemgetter("prompt_tokens"),
                            token_usages["completions"][key],
                        )
                    ),
                }
            out["token_usage"] = token_usages

        return out

    except Exception as ex:
        logger.exception(ex)
        raise ex
