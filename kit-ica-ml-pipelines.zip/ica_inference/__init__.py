import logging
from importlib.metadata import version

__version__ = version("kit-ica-ml-pipelines")

__all__: list = ["utils"]

utils_logger_log_level = logging.DEBUG


def set_utils_logger_log_level(log_level):
    global utils_logger_log_level
    utils_logger_log_level = log_level
