# KIT ICA Inference

| ⚡ Developers, Please refer to [DEVELOPMENT.md](./DEVELOPMENT.md) |
|------------------------------------------------------------------|
## Table of contents

- [Introduction](#introduction)
- [Installation](#installation)
    - [Poetry](#poetry)
    - [Conda](#conda)
- [Usage](#usage)
  - [Quick Start](#quick-start)
- [Known Issues](#known-issues)

---


## Introduction
Repository for the ICA machine learning pipelines.

### KIT Word Document Segmentation

- This library is used for ICA inference.


## Installation

### Poetry

- Add the following to `pyproject.toml`
  ```toml
    [[tool.poetry.source]]
    name = "azure"
    url = "https://pkgs.dev.azure.com/kpmgjp-prod-001/_packaging/kit-pypi/pypi/simple/"
    priority = "supplemental"
  ```

- Configuration Poetry to install dependencies from kit-pypi with your username and PAT. You have to do this only first time.
  ```shell
    poetry config http-basic.azure YOUR_USERNAME YOUR_PAT
  ```
- Add internal package.
  ```shell
    poetry add kit-ica-ml-pipelines
  ```
  
### Conda
**Note:** It is recommended to have an alias `pipkit` to install azure
artifacts packages for convenience. This alias will simply instruct `pip` to
look for packages in our `kit-pypi` Azure Artifacts.

- Add followings to `~/.bashrc` or `./zshrc`
  ```shell
    alias pipkit="PIP_EXTRA_INDEX_URL=https://pkgs.dev.azure.com/kpmgjp-prod-001/_packaging/kit-pypi/pypi/simple/ pip"
  ```

- Reload the modified file or restart your terminal.
  ```shell
    source ~/.bashrc
    or
    source ~/.zshrc
  ```
- Create a virtual environment of your choice, `conda` or `virtualenv`
- Install `artifacts-keyring`
  ```shell
    pip install artifacts-keyring
  ```

- Install package from Azure Artifacts
  ```shell
    pipkit install kit-ica-ml-pipelines
  ```
---

## Usage

### Quick Start

#### Question Answering
```python
import json
from ica_inference import question_answering

with open("tests/resources/dummy_EL.pdf", mode="rb") as fin:
    file_buffer = io.BytesIO(fin.read())
config = {"pdf_binary_object": file_buffer}
questions = json.load(open("tests/resources/configs/input.json", "r"))

config["check_items"] = questions
answers = question_answering.answer_with_evidence(
    config.copy()
)
```

#### Layout Analysis
```python
import io
from ica_inference.utils.common_utils import pdf_char_extractor

out = io.BytesIO()
with open("tests/resources/dummy_EL.pdf", mode="rb") as fin:
  out.write(fin.read())

layout = pdf_char_extractor(out)
```

##### High level of the inference flow

1. Extract text from the PDF file, segment it in text areas, and filter out irrelevant parts
2. For each question:
    * Search the relevant paragraph to answer the question;
    * Prepare the prompt and answer to the question;
    * Indentify relevant sentences to support the answer


##### Configuration files 
1. input.json: Questions for Engagement Letters. Example:
    ```python
    [{
        "code": "D-1",
        "answer_evidence_mapping": {
            "auto_renewal": true,
            "contract_until": true,
            "no_renewal_clause": false
        },
        "questions": [
            {
                "explanation": "",
                "question": "How are the engagement terms applied for subsequent periods?",
                "choices": {
                    "a": "Engagement terms apply for subsequent periods unless agreed otherwise",
                    "b": "Engagement terms apply till a fixed date",
                    "c": "Don't know"
                },
                "answer_mapping": {
                    "a": "auto_renewal",
                    "b": "contract_until",
                    "c": "no_renewal_clause"
                }
            }
        ]
    },]
    ```
2. model_configs.yaml: A file which has model configs and model settings. 

    ```yaml
    specVersion: v1
    
    modelConfig:
      # Mode can be: cloud local vm
      mode: local
      # If we want to force the use of a set models, even if GPU is available.
      forceUse: False
      forceUseMode: cpu
    
      cpu:
        search: 2
        prompt_tokenization: 1
        question_answering: 1
        trankit: 5
      gpu:
        search: 4
        prompt_tokenization: 3
        question_answering: 3
        trankit: 5
    
      modelZoo:
        1:
          "name": "google/flan-t5-large"
          "type": "Hugging Face / Text2Text Generation"
          "class": "T5ForConditionalGeneration"
          "call_method": "local"
          "device": "cpu"
          "inference_batch_size": 20
        2:
          "name": "hkunlp/instructor-base"
          "type": "Hugging Face / Sentence Similarity"
          "class": "INSTRUCTOR"
          "call_method": "local"
          "device": "cpu"
          "inference_batch_size": 20
        3:
          "name": "google/flan-t5-xxl"
          "type": "Hugging Face / Text2Text Generation"
          "class": "T5ForConditionalGeneration"
          "call_method": "local"
          "device": "cuda"
          "inference_batch_size": 100
        4:
          "name": "hkunlp/instructor-large"
          "type": "Hugging Face / Sentence Similarity"
          "class": "INSTRUCTOR"
          "call_method": "local"
          "device": "cuda"
          "inference_batch_size": 500
      5:
          "name": "xlm-roberta-base"
          "type": "Trankit"
    ```
Note: It is possible to override default model configs as below.
```python
from ica_inference.model_call import models_config
from ica_inference.model_call import load_models

# Override default config
models_config.load_config_from_yaml(YOUR_MODEL_CONFIG_FILE_PATH)

# Load models
load_models()
```

### Known Issues
TBD