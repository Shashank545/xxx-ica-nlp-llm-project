API Reference
=============

Modules
----------

.. autosummary::
   :toctree: modules

   ica_inference.preprocessing
   ica_inference.model_call
   ica_inference.model_config
   ica_inference.postprocessing
   ica_inference.semantic_search
   ica_inference.utils.common_utils
   ica_inference.utils.bbox_plotting
   ica_inference.utils.prompt_building
   ica_inference.utils.sentence_splitter
   ica_inference.utils.models_download_helper
   ica_inference.utils.openai_utils
   ica_inference.utils.Evidence
   ica_inference.utils.Answer
   ica_inference.utils.Location