.. My Project documentation master file, created by
   sphinx-quickstart on Fri May 29 11:54:02 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

KIT ICA inference library's documentation
==========================================

KIT ICA inference library.

.. toctree::
   :maxdepth: 2

   markdown/README
   markdown/DEVELOPMENT
   api_reference

