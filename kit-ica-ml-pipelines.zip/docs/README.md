# Sphinx-powered documentation

This is the documentation folder, which enables building a html documentation with Sphinx (https://www.sphinx-doc.org/).

- To build the documentation, execute
  ```bash
  poetry run make html
  ```

- To build a PDF of the documentation (without the examples), you first need to install [LaTeX](https://www.tug.org/mactex/) and [inkscape](https://inkscape.org/) (follow the installation instructions on the website) and then execute:

  ```bash
  poetry run make latexpdf
  ```

- To clean the build files
  ```bash
  poetry run make clean
  ```
- The generated documents will be found within `./docs/build/html`
  ```bash
  open build/html/index.html
  ```

### Sphinx Documentation Structure

```bash
docs
├── build             # Automatically generated
├── source            # Source files to be used by Sphinx
│   ├── _static                   # Assets and CSS files
│   │   ├── kpmg.svg
│   │   └── theme_overrides.css
│   ├── _templates                # Templates to be used by autosummary
│   │   └── autosummary
│   │       ├── base.rst          #
│   │       ├── class.rst         # Files here can be modified but require
│   │       ├── function.rst      # Jinja and reST knowledge.
│   │       └── module.rst        #
││   ├── api_reference.rst        # API Reference
│   ├── conf.py                   # Configuration file
│   └── index.rst                 # Landing page
└── Makefile
```
